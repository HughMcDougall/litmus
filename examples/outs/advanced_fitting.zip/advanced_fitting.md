# Advanced Tutorial - Fitting Messy Posteriors
`LITMUS`'s default settings are tuned to balance speed and robustness, aiming to quickly fit lags for as many signals as possible. However, it's easy to run across seamingly similar problems where more user-driven fine-tuning is required. The hessian and SVI scans rely on them having a good sample of "test lags" to form their Gaussian slices at. By default, they generate these automatically via the "grid smoothing" algorithm (see the original paper) encoded in the `hessian_scan.make_grid()` method, but in this tutorial we'll show when, and how, to nominate these slices ourselves.

_note:This tutorial using the `hessian_scan` for demonstration, but all steps here are equally applicable with the `SVI_scan` as well. Consider using that if you plan on doing model comparison._  


```python
import litmus.models
from litmus import *
import matplotlib.pyplot as plt
import numpy as np
from litmus._utils import dict_extend
```

    An NVIDIA GPU may be present on this machine, but a CUDA-enabled jaxlib is not installed. Falling back to cpu.


In this tutorial we'll be using the pre-made `mock_B` from the `litmus.mocks` module. This is a high SNR source with extremely low error on the response signal. Ideally this means that the lag will be well constrained, but it also makes the posterior function sharp and difficult to navigate. In the following, the true underlying lag is $\Delta t = 256 \mathrm(d)$ and the timescale is $\tau = 400 \mathrm{d}$:


```python
mock = mocks.mock_B
mock.plot()
model_1 = models.GP_simple(verbose=False, debug=False, warn=0)
data = model_1.lc_to_data(mock.lc_1, mock.lc_2)
```


    
![png](output_3_0.png)
    


First lets fit this how we normally would: a smattering of lags with some simple preconditioning to improve the efficiency of the slice solver. In this case I've also made some tweaks to `init_samples` and `grid_bunching` to make the initial posteior estimation closer to a dense grid, and lowered `optimizer_args["maxiter"]`, i.e. shortened the slice optimization regime to make the solver run a bit faster:


```python
fitter = litmus.fitting_methods.hessian_scan(model_1, precondition="diag",
                                             verbose=0, debug=False, warn=0,
                                             Nlags=128,
                                             grid_bunching=0.5,
                                             init_samples=10_000,
                                             optimizer_args={"maxiter": 128, "increase_factor": 1.2}
                                             )
fitter.prefit(mock.lc_1, mock.lc_2)
```


    ---------------------------------------------------------------------------

    TypeError                                 Traceback (most recent call last)

    Cell In[3], line 8
          1 fitter = litmus.fitting_methods.hessian_scan(model_1, precondition="diag",
          2                                              verbose=0, debug=False, warn=0,
          3                                              Nlags=128,
       (...)
          6                                              optimizer_args={"maxiter": 128, "increase_factor": 1.2}
          7                                              )
    ----> 8 fitter.prefit(mock.lc_1, mock.lc_2)


    File /mnt/c/Work/litmus/litmus/fitting_methods.py:1197, in hessian_scan.prefit(self, lc_1, lc_2, seed)
       1193 data = self.stat_model.lc_to_data(lc_1, lc_2)
       1195 # ----------------------------------
       1196 # Estimate the MAP
    -> 1197 self.estmap_params = self.estimate_MAP(lc_1, lc_2, seed)
       1198 estmap_tol = self.stat_model.opt_tol(self.estmap_params, data,
       1199                                      integrate_axes=self.stat_model.free_params())
       1201 et1 = self.stat_model.opt_tol(self.estmap_params, data,
       1202                               integrate_axes=[key for key in self.stat_model.free_params() if
       1203                                               key != "lag"]
       1204                               )


    File /mnt/c/Work/litmus/litmus/fitting_methods.py:1048, in hessian_scan.estimate_MAP(self, lc_1, lc_2, seed)
       1046 # Do Lag in Isolation
       1047 self.msg_run("Doing lag Optimization in isolation...", lvl=2)
    -> 1048 lagopt_params = do_scan(start=estmap_params | {'lag': bestlag},
       1049                         keys=["lag"],
       1050                         solver="GradientDescent",
       1051                         addtl_kwargs={'decrease_factor': 0.25}
       1052                         )
       1053 ll_lagopt = self.stat_model.log_density(lagopt_params, data)
       1054 self.msg_run("Lag-only opt settled at new lag %.2f..." % lagopt_params['lag'], lvl=3)


    File /mnt/c/Work/litmus/litmus/fitting_methods.py:986, in hessian_scan.estimate_MAP.<locals>.<lambda>(start, keys, solver, addtl_kwargs)
        980 # ----------------------------------
        981 # SCANNING FOR OPT
        982 
        983 # ------------------------------
        984 # Get Best Non-Lag Params
        985 self.msg_run("Moving non-lag params to new location...", lvl=2)
    --> 986 do_scan = lambda start, keys, solver, addtl_kwargs={}: self.stat_model.scan(start_params=start,
        987                                                                             optim_params=keys,
        988                                                                             data=data,
        989                                                                             optim_kwargs=self.optimizer_args_init | addtl_kwargs,
        990                                                                             precondition=self.precondition,
        991                                                                             solver=solver,
        992                                                                             )
        993 seed_params = {key: jnp.float64(val) for key, val in zip(seed_params.keys(), seed_params.values())}
        995 estmap_params = do_scan(start=seed_params,
        996                         keys=[key for key in self.stat_model.free_params() if key != 'lag'],
        997                         solver="BFGS"
        998                         )


    File /mnt/c/Work/litmus/litmus/models.py:858, in stats_model.scan(self, start_params, data, optim_params, use_vmap, optim_kwargs, precondition, solver)
        856 # Overwrite only the keys that work for that jaxopt solver
        857 for key in optim_kwargs.keys():
    --> 858     if key in optimizer_args.keys(): optim_params[key] = optimizer_args[key]
        860 # Convert to unconstrained domain
        861 start_params_uncon = self.to_uncon(start_params)


    TypeError: list indices must be integers or slices, not str


Right away we can see something a little concerning. When estimaing the peak for generating the grid, the solver has landed about $1.3$ standard deviations from the local peak and there's some very strange behaviour along the lag axis. If we converge on one but not the other, it usually suggests that there's some odd geometry on the lag axis. Still: let's fire this off and see how it goes:


```python
fitter.fit(mock.lc_1, mock.lc_2)
fitter.diagnostics(show=False)
plt.show()
```

    Starting Hessian Scan 
    :::::::::::::::::::::::
    Scanning at lag=188.79 ...
    
    Seems to have converged at iteration 0 / 128 with tolerance 2.75e-05 
    :::::::::::::::::::::::
    Scanning at lag=188.67 ...
    
    Seems to have converged at iteration 1 / 128 with tolerance 1.02e-05 
    :::::::::::::::::::::::
    Scanning at lag=188.55 ...
    
    Seems to have converged at iteration 2 / 128 with tolerance 4.26e-06 
    :::::::::::::::::::::::
    Scanning at lag=188.42 ...
    
    Seems to have converged at iteration 3 / 128 with tolerance 1.79e-05 
    :::::::::::::::::::::::
    Scanning at lag=188.30 ...
    
    Seems to have converged at iteration 4 / 128 with tolerance 2.15e-05 
    :::::::::::::::::::::::
    Scanning at lag=188.18 ...
    
    Seems to have converged at iteration 5 / 128 with tolerance 1.84e-05 
    :::::::::::::::::::::::
    Scanning at lag=188.05 ...
    
    Seems to have converged at iteration 6 / 128 with tolerance 1.89e-05 
    :::::::::::::::::::::::
    Scanning at lag=187.93 ...
    
    Seems to have converged at iteration 7 / 128 with tolerance 6.58e-06 
    :::::::::::::::::::::::
    Scanning at lag=187.81 ...
    
    Seems to have converged at iteration 8 / 128 with tolerance 9.65e-06 
    :::::::::::::::::::::::
    Scanning at lag=187.68 ...
    
    Seems to have converged at iteration 9 / 128 with tolerance 2.11e-05 
    :::::::::::::::::::::::
    Scanning at lag=187.56 ...
    
    Seems to have converged at iteration 10 / 128 with tolerance 2.90e-06 
    :::::::::::::::::::::::
    Scanning at lag=187.44 ...
    
    Seems to have converged at iteration 11 / 128 with tolerance 3.22e-06 
    :::::::::::::::::::::::
    Scanning at lag=187.32 ...
    
    Seems to have converged at iteration 12 / 128 with tolerance 2.98e-06 
    :::::::::::::::::::::::
    Scanning at lag=187.19 ...
    
    Seems to have converged at iteration 13 / 128 with tolerance 4.86e-06 
    :::::::::::::::::::::::
    Scanning at lag=187.07 ...
    
    Seems to have converged at iteration 14 / 128 with tolerance 2.28e-05 
    :::::::::::::::::::::::
    Scanning at lag=186.95 ...
    
    Seems to have converged at iteration 15 / 128 with tolerance 3.87e-05 
    :::::::::::::::::::::::
    Scanning at lag=186.82 ...
    
    Seems to have converged at iteration 16 / 128 with tolerance 8.38e-06 
    :::::::::::::::::::::::
    Scanning at lag=186.70 ...
    
    Seems to have converged at iteration 17 / 128 with tolerance 1.17e-05 
    :::::::::::::::::::::::
    Scanning at lag=186.58 ...
    
    Seems to have converged at iteration 18 / 128 with tolerance 9.27e-06 
    :::::::::::::::::::::::
    Scanning at lag=186.45 ...
    
    Seems to have converged at iteration 19 / 128 with tolerance 3.41e-05 
    :::::::::::::::::::::::
    Scanning at lag=186.33 ...
    
    Seems to have converged at iteration 20 / 128 with tolerance 5.29e-07 
    :::::::::::::::::::::::
    Scanning at lag=186.21 ...
    
    Seems to have converged at iteration 21 / 128 with tolerance 2.43e-06 
    :::::::::::::::::::::::
    Scanning at lag=186.09 ...
    
    Seems to have converged at iteration 22 / 128 with tolerance 9.37e-06 
    :::::::::::::::::::::::
    Scanning at lag=185.96 ...
    
    Seems to have converged at iteration 23 / 128 with tolerance 7.81e-07 
    :::::::::::::::::::::::
    Scanning at lag=185.84 ...
    
    Seems to have converged at iteration 24 / 128 with tolerance 2.37e-05 
    :::::::::::::::::::::::
    Scanning at lag=185.72 ...
    
    Seems to have converged at iteration 25 / 128 with tolerance 4.61e-06 
    :::::::::::::::::::::::
    Scanning at lag=185.59 ...
    
    Seems to have converged at iteration 26 / 128 with tolerance 1.05e-06 
    :::::::::::::::::::::::
    Scanning at lag=185.47 ...
    
    Seems to have converged at iteration 27 / 128 with tolerance 1.13e-06 
    :::::::::::::::::::::::
    Scanning at lag=185.35 ...
    
    Seems to have converged at iteration 28 / 128 with tolerance 5.12e-06 
    :::::::::::::::::::::::
    Scanning at lag=185.22 ...
    
    Seems to have converged at iteration 29 / 128 with tolerance 5.18e-06 
    :::::::::::::::::::::::
    Scanning at lag=185.10 ...
    
    Seems to have converged at iteration 30 / 128 with tolerance 1.88e-05 
    :::::::::::::::::::::::
    Scanning at lag=184.98 ...
    
    Seems to have converged at iteration 31 / 128 with tolerance 2.38e-06 
    :::::::::::::::::::::::
    Scanning at lag=184.85 ...
    
    Seems to have converged at iteration 32 / 128 with tolerance 1.08e-06 
    :::::::::::::::::::::::
    Scanning at lag=184.73 ...
    
    Seems to have converged at iteration 33 / 128 with tolerance 5.76e-07 
    :::::::::::::::::::::::
    Scanning at lag=184.61 ...
    
    Seems to have converged at iteration 34 / 128 with tolerance 2.74e-05 
    :::::::::::::::::::::::
    Scanning at lag=184.49 ...
    
    Seems to have converged at iteration 35 / 128 with tolerance 3.89e-05 
    :::::::::::::::::::::::
    Scanning at lag=184.36 ...
    
    Seems to have converged at iteration 36 / 128 with tolerance 4.88e-06 
    :::::::::::::::::::::::
    Scanning at lag=184.24 ...
    
    Seems to have converged at iteration 37 / 128 with tolerance 8.52e-07 
    :::::::::::::::::::::::
    Scanning at lag=184.12 ...
    
    Seems to have converged at iteration 38 / 128 with tolerance 3.46e-06 
    :::::::::::::::::::::::
    Scanning at lag=183.99 ...
    
    Seems to have converged at iteration 39 / 128 with tolerance 5.81e-06 
    :::::::::::::::::::::::
    Scanning at lag=183.87 ...
    
    Seems to have converged at iteration 40 / 128 with tolerance 3.80e-06 
    :::::::::::::::::::::::
    Scanning at lag=183.75 ...
    
    Seems to have converged at iteration 41 / 128 with tolerance 1.07e-05 
    :::::::::::::::::::::::
    Scanning at lag=183.62 ...
    
    Seems to have converged at iteration 42 / 128 with tolerance 9.84e-07 
    :::::::::::::::::::::::
    Scanning at lag=183.50 ...
    
    Seems to have converged at iteration 43 / 128 with tolerance 5.45e-05 
    :::::::::::::::::::::::
    Scanning at lag=183.38 ...
    
    Seems to have converged at iteration 44 / 128 with tolerance 1.56e-06 
    :::::::::::::::::::::::
    Scanning at lag=183.26 ...
    
    Seems to have converged at iteration 45 / 128 with tolerance 4.87e-06 
    :::::::::::::::::::::::
    Scanning at lag=183.13 ...
    
    Seems to have converged at iteration 46 / 128 with tolerance 2.46e-06 
    :::::::::::::::::::::::
    Scanning at lag=183.01 ...
    
    Seems to have converged at iteration 47 / 128 with tolerance 8.22e-05 
    :::::::::::::::::::::::
    Scanning at lag=182.89 ...
    
    Seems to have converged at iteration 48 / 128 with tolerance 3.46e-05 
    :::::::::::::::::::::::
    Scanning at lag=182.76 ...
    
    Seems to have converged at iteration 49 / 128 with tolerance 2.02e-05 
    :::::::::::::::::::::::
    Scanning at lag=182.64 ...
    
    Seems to have converged at iteration 50 / 128 with tolerance 2.60e-05 
    :::::::::::::::::::::::
    Scanning at lag=182.52 ...
    
    Seems to have converged at iteration 51 / 128 with tolerance 2.01e-05 
    :::::::::::::::::::::::
    Scanning at lag=182.39 ...
    
    Seems to have converged at iteration 52 / 128 with tolerance 3.35e-05 
    :::::::::::::::::::::::
    Scanning at lag=182.27 ...
    
    Seems to have converged at iteration 53 / 128 with tolerance 7.45e-07 
    :::::::::::::::::::::::
    Scanning at lag=182.15 ...
    
    Seems to have converged at iteration 54 / 128 with tolerance 9.82e-07 
    :::::::::::::::::::::::
    Scanning at lag=182.02 ...
    
    Seems to have converged at iteration 55 / 128 with tolerance 8.83e-06 
    :::::::::::::::::::::::
    Scanning at lag=181.90 ...
    
    Seems to have converged at iteration 56 / 128 with tolerance 1.47e-05 
    :::::::::::::::::::::::
    Scanning at lag=181.78 ...
    
    Seems to have converged at iteration 57 / 128 with tolerance 4.80e-06 
    :::::::::::::::::::::::
    Scanning at lag=181.66 ...
    
    Seems to have converged at iteration 58 / 128 with tolerance 1.87e-06 
    :::::::::::::::::::::::
    Scanning at lag=181.53 ...
    
    Seems to have converged at iteration 59 / 128 with tolerance 2.81e-06 
    :::::::::::::::::::::::
    Scanning at lag=181.41 ...
    
    Seems to have converged at iteration 60 / 128 with tolerance 2.27e-05 
    :::::::::::::::::::::::
    Scanning at lag=181.29 ...
    
    Seems to have converged at iteration 61 / 128 with tolerance 1.04e-05 
    :::::::::::::::::::::::
    Scanning at lag=181.16 ...
    
    Seems to have converged at iteration 62 / 128 with tolerance 1.19e-05 
    :::::::::::::::::::::::
    Scanning at lag=173.20 ...
    
    Seems to have converged at iteration 63 / 128 with tolerance 8.25e-06 
    :::::::::::::::::::::::
    Scanning at lag=157.48 ...
    
    Seems to have converged at iteration 64 / 128 with tolerance 2.19e+01 
    :::::::::::::::::::::::
    Scanning at lag=141.73 ...
    
    Seems to have converged at iteration 65 / 128 with tolerance 4.30e-05 
    :::::::::::::::::::::::
    Scanning at lag=125.98 ...
    
    Seems to have converged at iteration 66 / 128 with tolerance 2.27e+01 
    :::::::::::::::::::::::
    Scanning at lag=110.24 ...
    
    Seems to have converged at iteration 67 / 128 with tolerance 1.25e+01 
    :::::::::::::::::::::::
    Scanning at lag=94.49 ...
    
    Seems to have converged at iteration 68 / 128 with tolerance 4.46e+01 
    :::::::::::::::::::::::
    Scanning at lag=78.74 ...
    
    Seems to have converged at iteration 69 / 128 with tolerance 1.38e+02 
    :::::::::::::::::::::::
    Scanning at lag=62.99 ...
    
    Seems to have converged at iteration 70 / 128 with tolerance 6.68e+01 
    :::::::::::::::::::::::
    Scanning at lag=47.24 ...
    
    :::::::::::::::::::::::
    Scanning at lag=31.50 ...
    
    :::::::::::::::::::::::
    Scanning at lag=15.75 ...
    
    Seems to have converged at iteration 73 / 128 with tolerance 5.96e+01 
    :::::::::::::::::::::::
    Scanning at lag=0.00 ...
    
    Seems to have converged at iteration 74 / 128 with tolerance 1.17e+02 
    :::::::::::::::::::::::
    Scanning at lag=188.91 ...
    
    Seems to have converged at iteration 75 / 128 with tolerance 9.50e-06 
    :::::::::::::::::::::::
    Scanning at lag=196.85 ...
    
    :::::::::::::::::::::::
    Scanning at lag=212.60 ...
    
    Seems to have converged at iteration 77 / 128 with tolerance 2.59e+01 
    :::::::::::::::::::::::
    Scanning at lag=228.35 ...
    
    Seems to have converged at iteration 78 / 128 with tolerance 6.59e-06 
    :::::::::::::::::::::::
    Scanning at lag=244.09 ...
    
    :::::::::::::::::::::::
    Scanning at lag=259.84 ...
    
    :::::::::::::::::::::::
    Scanning at lag=275.59 ...
    
    Seems to have converged at iteration 81 / 128 with tolerance 2.84e-06 
    :::::::::::::::::::::::
    Scanning at lag=291.34 ...
    
    Seems to have converged at iteration 82 / 128 with tolerance 2.56e+01 
    :::::::::::::::::::::::
    Scanning at lag=307.09 ...
    
    Seems to have converged at iteration 83 / 128 with tolerance 4.58e-04 
    :::::::::::::::::::::::
    Scanning at lag=322.83 ...
    
    :::::::::::::::::::::::
    Scanning at lag=338.58 ...
    
    Seems to have converged at iteration 85 / 128 with tolerance 1.12e+00 
    :::::::::::::::::::::::
    Scanning at lag=354.33 ...
    
    :::::::::::::::::::::::
    Scanning at lag=370.08 ...
    
    Seems to have converged at iteration 87 / 128 with tolerance 7.03e+02 
    :::::::::::::::::::::::
    Scanning at lag=385.83 ...
    
    :::::::::::::::::::::::
    Scanning at lag=401.57 ...
    
    :::::::::::::::::::::::
    Scanning at lag=417.32 ...
    
    :::::::::::::::::::::::
    Scanning at lag=433.07 ...
    
    :::::::::::::::::::::::
    Scanning at lag=448.82 ...
    
    Seems to have converged at iteration 92 / 128 with tolerance 2.32e+02 
    :::::::::::::::::::::::
    Scanning at lag=464.57 ...
    
    :::::::::::::::::::::::
    Scanning at lag=480.31 ...
    
    :::::::::::::::::::::::
    Scanning at lag=496.06 ...
    
    :::::::::::::::::::::::
    Scanning at lag=511.81 ...
    
    Seems to have converged at iteration 96 / 128 with tolerance 1.38e+01 
    :::::::::::::::::::::::
    Scanning at lag=527.56 ...
    
    :::::::::::::::::::::::
    Scanning at lag=543.31 ...
    
    :::::::::::::::::::::::
    Scanning at lag=559.06 ...
    
    :::::::::::::::::::::::
    Scanning at lag=574.80 ...
    
    Seems to have converged at iteration 100 / 128 with tolerance 5.18e+01 
    :::::::::::::::::::::::
    Scanning at lag=590.55 ...
    
    :::::::::::::::::::::::
    Scanning at lag=606.30 ...
    
    :::::::::::::::::::::::
    Scanning at lag=622.05 ...
    
    :::::::::::::::::::::::
    Scanning at lag=637.80 ...
    
    :::::::::::::::::::::::
    Scanning at lag=653.54 ...
    
    Seems to have converged at iteration 105 / 128 with tolerance 3.31e+02 
    :::::::::::::::::::::::
    Scanning at lag=669.29 ...
    
    :::::::::::::::::::::::
    Scanning at lag=685.04 ...
    
    Seems to have converged at iteration 107 / 128 with tolerance 9.25e+02 
    :::::::::::::::::::::::
    Scanning at lag=700.79 ...
    
    :::::::::::::::::::::::
    Scanning at lag=716.54 ...
    
    :::::::::::::::::::::::
    Scanning at lag=732.28 ...
    
    :::::::::::::::::::::::
    Scanning at lag=748.03 ...
    
    :::::::::::::::::::::::
    Scanning at lag=763.78 ...
    
    :::::::::::::::::::::::
    Scanning at lag=779.53 ...
    
    :::::::::::::::::::::::
    Scanning at lag=795.28 ...
    
    Seems to have converged at iteration 114 / 128 with tolerance 1.54e+02 
    :::::::::::::::::::::::
    Scanning at lag=811.02 ...
    
    :::::::::::::::::::::::
    Scanning at lag=826.77 ...
    
    Seems to have converged at iteration 116 / 128 with tolerance 8.59e+03 
    :::::::::::::::::::::::
    Scanning at lag=842.52 ...
    
    :::::::::::::::::::::::
    Scanning at lag=858.27 ...
    
    Seems to have converged at iteration 118 / 128 with tolerance 1.38e+02 
    :::::::::::::::::::::::
    Scanning at lag=874.02 ...
    
    Seems to have converged at iteration 119 / 128 with tolerance 2.82e+01 
    :::::::::::::::::::::::
    Scanning at lag=889.76 ...
    
    :::::::::::::::::::::::
    Scanning at lag=905.51 ...
    
    :::::::::::::::::::::::
    Scanning at lag=921.26 ...
    
    :::::::::::::::::::::::
    Scanning at lag=937.01 ...
    
    :::::::::::::::::::::::
    Scanning at lag=952.76 ...
    
    :::::::::::::::::::::::
    Scanning at lag=968.50 ...
    
    :::::::::::::::::::::::
    Scanning at lag=984.25 ...
    
    :::::::::::::::::::::::
    Scanning at lag=1000.00 ...
    
    Scanning Complete. Calculating laplace integrals... 
    Hessian Scan Fitting complete.
    -----------------------
    -----------------------
    



    
![png](output_7_1.png)
    


To be safe let's check our diagnostics: it looks like some of our slices are still away from convergence. Let's give them another go. Okay, this looks good! We've got a single densely sampled peak, lots of converged slices, everything's great, right?


```python
fitter.refit(mock.lc_1, mock.lc_2)
fitter.diagnostics(show=False)
plt.show()
```

    Doing re-fitting of 21 lags 
    :::::::::::::::::::::::
    Refitting lag 0/21 at lag 157.48
    
    Settled at new tol 1.14e-03 
    :::::::::::::::::::::::
    Refitting lag 1/21 at lag 125.98
    
    Settled at new tol 4.43e-04 
    :::::::::::::::::::::::
    Refitting lag 2/21 at lag 110.24
    
    Settled at new tol 1.85e-03 
    :::::::::::::::::::::::
    Refitting lag 3/21 at lag 94.49
    
    Settled at new tol 7.67e-05 
    :::::::::::::::::::::::
    Refitting lag 4/21 at lag 78.74
    
    Settled at new tol 2.73e-03 
    :::::::::::::::::::::::
    Refitting lag 5/21 at lag 62.99
    
    Settled at new tol 1.61e-03 
    :::::::::::::::::::::::
    Refitting lag 6/21 at lag 15.75
    
    Settled at new tol 1.01e-04 
    :::::::::::::::::::::::
    Refitting lag 7/21 at lag 0.00
    
    Settled at new tol 2.72e-04 
    :::::::::::::::::::::::
    Refitting lag 8/21 at lag 212.60
    
    Settled at new tol 2.81e-04 
    :::::::::::::::::::::::
    Refitting lag 9/21 at lag 291.34
    
    Settled at new tol 8.83e-04 
    :::::::::::::::::::::::
    Refitting lag 10/21 at lag 338.58
    
    Settled at new tol 1.48e-03 
    :::::::::::::::::::::::
    Refitting lag 11/21 at lag 370.08
    
    Settled at new tol 3.57e-03 
    :::::::::::::::::::::::
    Refitting lag 12/21 at lag 448.82
    
    Settled at new tol 7.83e-04 
    :::::::::::::::::::::::
    Refitting lag 13/21 at lag 511.81
    
    Settled at new tol 3.21e-04 
    :::::::::::::::::::::::
    Refitting lag 14/21 at lag 574.80
    
    Settled at new tol 5.79e-04 
    :::::::::::::::::::::::
    Refitting lag 15/21 at lag 653.54
    
    Settled at new tol 7.84e-04 
    :::::::::::::::::::::::
    Refitting lag 16/21 at lag 685.04
    
    Settled at new tol 4.96e+01 
    :::::::::::::::::::::::
    Refitting lag 17/21 at lag 795.28
    
    Settled at new tol 1.70e+01 
    :::::::::::::::::::::::
    Refitting lag 18/21 at lag 826.77
    
    Settled at new tol 2.49e-05 
    :::::::::::::::::::::::
    Refitting lag 19/21 at lag 858.27
    
    Settled at new tol 8.35e-05 
    :::::::::::::::::::::::
    Refitting lag 20/21 at lag 874.02
    
    Settled at new tol 8.49e-04 
    Refitting complete. 



    
![png](output_9_1.png)
    


Sadly, no. If we plot the recovered lag, we can see that our fitter has confidently honed in on a lag of $\Delta t = 184^{+2.2}_{-7.5} \; \mathrm{d}$, several dozen $\sigma$ from the true lag of $\Delta t = 256  \; \mathrm{d}$. We've converged but on the wrong answer!


```python
lt = LITMUS(fitter)
f = lt.lag_plot(show=False, prior_extents=True)
f.axes[0].axvline(mock.lag, ls="--", color="navy", label="True Lag"), f.legend()
plt.show()
```

    Warning! LITMUS object built on pre-run fitting_procedure. May have unexpected behaviour. 

    



    
![png](output_11_2.png)
    


## What's Gone Wrong?
Let's take a closer look with `diagnostic_lagplot`. Equipped with the true parameters we can see the issue: our test lag grid has completely missed the true lag, it's slipped between the gaps:


```python
f = fitter.diagnostic_lagplot(show=False)
for ax in f.axes: ax.axvline(mock.lag, ls="--", color="navy", label="True Lag"), ax.legend()
```


    
![png](output_13_0.png)
    


Because we know the true parameters we can drill in even further. We can trace out the _conditional_ lag distribution with the other parameters fixed at both the _true_ parameters and our (failed) estimate of the MAP. Doing so we see what's gone wrong: in it's initial guesses the fitter has locked onto a shallower, wider mode at ~200 days. In lower SNR signals this is fine because the non-lag parameters are loosely constrained and can be used for different lags decently well, but in this high SNR signal the two lags correspond to different timescales / amplitudes etc and so the grid smoothing has failed:


```python
p1, p2 = mock.params(), fitter.estmap_params
p1, p2 = (litmus._utils.dict_extend(p, {"lag": np.linspace(100, 300, 10_000)}) for p in [p1, p2])
LL1, LL2 = [model_1.log_density(p, data) for p in [p1, p2]]

#------------------

plt.figure(figsize=(8, 4))
for p, LL, col, lab in zip([p1, p2], [LL1, LL2], ["royalblue", "orchid"], ["Conditioned at True", "Conditioned at Estimated MAP Params"]):
    I = p["lag"].argsort()
    X, Y = p["lag"][I], LL[I]
    plt.plot(X, Y, color=col, alpha=0.75, label=lab)
    plt.scatter(X[Y.argmax()], Y.max(), color=col, marker = "o", alpha=1.0)

plt.axvline(mock.lag, ls='--', color='navy', label="True Lag")
plt.legend()
plt.xlim(100, 300)
plt.ylim(-100, 80)
plt.ylabel("Conditional Log Posterior Density")
plt.xlabel("Lag $\Delta t$, days")
plt.grid()
plt.show()
```


    
![png](output_15_0.png)
    


## How to Fix It - Brute Force

1. **Use a denser sampling grid (decrease `grid_bunching` and increase `Nlags`)**
2. Use a more exhaustive sampler (e.g. `fitting_methods.nested_sampling`)
3. **Use different test lags**

In this example, we'll use the first and last methods. For examples how to use nested sampling in `LITMUS`, see other examples.

To start, let's take a brute force approach and scan with lots of lags. By increasing `Nlags` we test more slices and by lowering `grid_bunching` we spread them more evenly across the lag prior, thereby nullifying the impact of our mis-matched MAP estimate. This is _slower_, but not intractable as the smaller gaps between test lags means the solver has to adjust less as it moves between them.

Testing more lags also means testing more _bad_ lags which we intend to discard. For this reason I've lowered `maxiter` in the `optimizer_args`, telling the solver to abandon poor fitting lags early rather than waste too much time trying to make sense of them.


```python
fitter_brute = litmus.fitting_methods.hessian_scan(model_1, precondition="diag",
                                             verbose=0, debug=False, warn=False,
                                             Nlags=1024,
                                             grid_bunching=0.1,
                                             init_samples=10_000,
                                             optimizer_args={"maxiter": 128}
                                             )
fitter_brute.fit(*mock.lcs())
fitter_brute.refit(*mock.lcs())
```

    Starting Hessian Scan 
    Using stat model .find_seed to estimate some parameters 
    Optimizing Non-Lag Params... 
    Beginning scan at constrained-space position: 
    	 lag: 	 192.30 
    	 logtau: 	 7.26 
    	 logamp: 	 0.49 
    	 rel_amp: 	 0.96 
    	 mean: 	 0.33 
    	 rel_mean: 	 -0.26 
    Log-Density for this is: 7.92 
    Moving non-lag params to new location... 
    Optimizer settled at new fit with log density 10.57: 
    Optimizer settled at new fit: 
    	 lag: 	 192.30 
    	 logtau: 	 6.68 
    	 logamp: 	 0.32 
    	 rel_amp: 	 0.96 
    	 mean: 	 0.55 
    	 rel_mean: 	 -0.27 
    Log-Density for this is: 10.57 
    Finding a good lag with grid sweep... 
    Grid finds good lag at 192.30: 
    Log-Density for this is: 10.57 
    Doing lag Optimization in isolation... 
    Lag-only opt settled at new lag 192.33... 
    Log-Density for this is: 10.80 
    Running final optimization... 
    Optimizer settled at new fit: 
    	 lag: 	 192.33 
    	 logtau: 	 6.68 
    	 logamp: 	 0.32 
    	 rel_amp: 	 0.96 
    	 mean: 	 0.55 
    	 rel_mean: 	 -0.27 
    Log-Density for this is: 10.81 
    Estimated to be within ±1.35e+00σ of local optimum in non-lag parameters,
    and within ±infσ of local optimum in all parameters
    
    Making test lags from .make_grid() 
    Making Grid with interp scale log 
    Prefitting Complete 
    :::::::::::::::::::::::
    Scanning at lag=192.30 ...
    
    Change of -789.63 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=192.26 ...
    
    Change of 0.01 against 100.00 
    Seems to have converged at iteration 1 / 1024 with tolerance 1.51e-05 
    :::::::::::::::::::::::
    Scanning at lag=192.22 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 2 / 1024 with tolerance 4.44e-06 
    :::::::::::::::::::::::
    Scanning at lag=192.18 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 3 / 1024 with tolerance 4.96e-07 
    :::::::::::::::::::::::
    Scanning at lag=192.15 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 4 / 1024 with tolerance 5.76e-07 
    :::::::::::::::::::::::
    Scanning at lag=192.11 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 5 / 1024 with tolerance 2.56e-05 
    :::::::::::::::::::::::
    Scanning at lag=192.07 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 6 / 1024 with tolerance 1.60e-06 
    :::::::::::::::::::::::
    Scanning at lag=192.03 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 7 / 1024 with tolerance 1.31e-05 
    :::::::::::::::::::::::
    Scanning at lag=191.99 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 8 / 1024 with tolerance 4.11e-06 
    :::::::::::::::::::::::
    Scanning at lag=191.96 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 9 / 1024 with tolerance 2.02e-06 
    :::::::::::::::::::::::
    Scanning at lag=191.92 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 10 / 1024 with tolerance 1.96e-05 
    :::::::::::::::::::::::
    Scanning at lag=191.88 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 11 / 1024 with tolerance 4.33e-07 
    :::::::::::::::::::::::
    Scanning at lag=191.84 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 12 / 1024 with tolerance 1.35e-05 
    :::::::::::::::::::::::
    Scanning at lag=191.80 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 13 / 1024 with tolerance 1.94e-05 
    :::::::::::::::::::::::
    Scanning at lag=191.77 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 14 / 1024 with tolerance 9.86e-07 
    :::::::::::::::::::::::
    Scanning at lag=191.73 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 15 / 1024 with tolerance 7.61e-07 
    :::::::::::::::::::::::
    Scanning at lag=191.69 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 16 / 1024 with tolerance 5.70e-05 
    :::::::::::::::::::::::
    Scanning at lag=191.65 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 17 / 1024 with tolerance 1.86e-05 
    :::::::::::::::::::::::
    Scanning at lag=191.61 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 18 / 1024 with tolerance 1.25e-05 
    :::::::::::::::::::::::
    Scanning at lag=191.57 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 19 / 1024 with tolerance 1.43e-05 
    :::::::::::::::::::::::
    Scanning at lag=191.52 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 20 / 1024 with tolerance 4.51e-06 
    :::::::::::::::::::::::
    Scanning at lag=191.47 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 21 / 1024 with tolerance 3.84e-06 
    :::::::::::::::::::::::
    Scanning at lag=191.42 ...
    
    Change of 0.01 against 100.00 
    Seems to have converged at iteration 22 / 1024 with tolerance 2.42e-06 
    :::::::::::::::::::::::
    Scanning at lag=191.38 ...
    
    Change of 0.01 against 100.00 
    Seems to have converged at iteration 23 / 1024 with tolerance 4.25e-06 
    :::::::::::::::::::::::
    Scanning at lag=191.33 ...
    
    Change of 0.01 against 100.00 
    Seems to have converged at iteration 24 / 1024 with tolerance 5.02e-06 
    :::::::::::::::::::::::
    Scanning at lag=191.28 ...
    
    Change of 0.01 against 100.00 
    Seems to have converged at iteration 25 / 1024 with tolerance 1.87e-06 
    :::::::::::::::::::::::
    Scanning at lag=191.23 ...
    
    Change of 0.01 against 100.00 
    Seems to have converged at iteration 26 / 1024 with tolerance 1.30e-06 
    :::::::::::::::::::::::
    Scanning at lag=191.18 ...
    
    Change of 0.02 against 100.00 
    Seems to have converged at iteration 27 / 1024 with tolerance 1.80e-06 
    :::::::::::::::::::::::
    Scanning at lag=191.13 ...
    
    Change of 0.02 against 100.00 
    Seems to have converged at iteration 28 / 1024 with tolerance 7.12e-06 
    :::::::::::::::::::::::
    Scanning at lag=191.08 ...
    
    Change of 0.04 against 100.00 
    Seems to have converged at iteration 29 / 1024 with tolerance 5.23e-06 
    :::::::::::::::::::::::
    Scanning at lag=191.04 ...
    
    Change of 0.02 against 100.00 
    Seems to have converged at iteration 30 / 1024 with tolerance 5.81e-07 
    :::::::::::::::::::::::
    Scanning at lag=190.99 ...
    
    Change of 0.04 against 100.00 
    Seems to have converged at iteration 31 / 1024 with tolerance 1.57e-06 
    :::::::::::::::::::::::
    Scanning at lag=190.94 ...
    
    Change of 0.02 against 100.00 
    Seems to have converged at iteration 32 / 1024 with tolerance 5.21e-06 
    :::::::::::::::::::::::
    Scanning at lag=190.89 ...
    
    Change of 0.01 against 100.00 
    Seems to have converged at iteration 33 / 1024 with tolerance 1.39e-06 
    :::::::::::::::::::::::
    Scanning at lag=190.84 ...
    
    Change of 0.01 against 100.00 
    Seems to have converged at iteration 34 / 1024 with tolerance 1.52e-06 
    :::::::::::::::::::::::
    Scanning at lag=190.79 ...
    
    Change of 0.01 against 100.00 
    Seems to have converged at iteration 35 / 1024 with tolerance 2.18e-06 
    :::::::::::::::::::::::
    Scanning at lag=190.74 ...
    
    Change of 0.01 against 100.00 
    Seems to have converged at iteration 36 / 1024 with tolerance 9.99e-07 
    :::::::::::::::::::::::
    Scanning at lag=190.70 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 37 / 1024 with tolerance 5.24e-06 
    :::::::::::::::::::::::
    Scanning at lag=190.65 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 38 / 1024 with tolerance 3.38e-06 
    :::::::::::::::::::::::
    Scanning at lag=190.60 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 39 / 1024 with tolerance 6.80e-06 
    :::::::::::::::::::::::
    Scanning at lag=190.54 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 40 / 1024 with tolerance 8.12e-07 
    :::::::::::::::::::::::
    Scanning at lag=190.49 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 41 / 1024 with tolerance 6.54e-06 
    :::::::::::::::::::::::
    Scanning at lag=190.44 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 42 / 1024 with tolerance 2.42e-06 
    :::::::::::::::::::::::
    Scanning at lag=190.38 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 43 / 1024 with tolerance 9.65e-06 
    :::::::::::::::::::::::
    Scanning at lag=190.33 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 44 / 1024 with tolerance 1.21e-06 
    :::::::::::::::::::::::
    Scanning at lag=190.28 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 45 / 1024 with tolerance 2.25e-06 
    :::::::::::::::::::::::
    Scanning at lag=190.22 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 46 / 1024 with tolerance 8.47e-07 
    :::::::::::::::::::::::
    Scanning at lag=190.17 ...
    
    Change of -0.00 against 100.00 
    Seems to have converged at iteration 47 / 1024 with tolerance 8.30e-05 
    :::::::::::::::::::::::
    Scanning at lag=190.12 ...
    
    Change of -0.00 against 100.00 
    Seems to have converged at iteration 48 / 1024 with tolerance 1.69e-06 
    :::::::::::::::::::::::
    Scanning at lag=190.06 ...
    
    Change of -0.00 against 100.00 
    Seems to have converged at iteration 49 / 1024 with tolerance 3.49e-06 
    :::::::::::::::::::::::
    Scanning at lag=190.01 ...
    
    Change of -0.00 against 100.00 
    Seems to have converged at iteration 50 / 1024 with tolerance 5.97e-07 
    :::::::::::::::::::::::
    Scanning at lag=189.96 ...
    
    Change of -0.00 against 100.00 
    Seems to have converged at iteration 51 / 1024 with tolerance 4.53e-05 
    :::::::::::::::::::::::
    Scanning at lag=189.90 ...
    
    Change of -0.00 against 100.00 
    Seems to have converged at iteration 52 / 1024 with tolerance 1.52e-05 
    :::::::::::::::::::::::
    Scanning at lag=189.85 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 53 / 1024 with tolerance 2.52e-06 
    :::::::::::::::::::::::
    Scanning at lag=189.79 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 54 / 1024 with tolerance 6.18e-06 
    :::::::::::::::::::::::
    Scanning at lag=189.74 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 55 / 1024 with tolerance 1.49e-06 
    :::::::::::::::::::::::
    Scanning at lag=189.69 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 56 / 1024 with tolerance 1.73e-05 
    :::::::::::::::::::::::
    Scanning at lag=189.64 ...
    
    Change of 0.01 against 100.00 
    Seems to have converged at iteration 57 / 1024 with tolerance 1.28e-06 
    :::::::::::::::::::::::
    Scanning at lag=189.60 ...
    
    Change of 0.01 against 100.00 
    Seems to have converged at iteration 58 / 1024 with tolerance 1.93e-06 
    :::::::::::::::::::::::
    Scanning at lag=189.57 ...
    
    Change of 0.01 against 100.00 
    Seems to have converged at iteration 59 / 1024 with tolerance 1.11e-06 
    :::::::::::::::::::::::
    Scanning at lag=189.53 ...
    
    Change of 0.01 against 100.00 
    Seems to have converged at iteration 60 / 1024 with tolerance 4.34e-05 
    :::::::::::::::::::::::
    Scanning at lag=189.50 ...
    
    Change of 0.02 against 100.00 
    Seems to have converged at iteration 61 / 1024 with tolerance 4.88e-06 
    :::::::::::::::::::::::
    Scanning at lag=189.47 ...
    
    Change of 0.05 against 100.00 
    Seems to have converged at iteration 62 / 1024 with tolerance 6.82e-06 
    :::::::::::::::::::::::
    Scanning at lag=189.43 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 63 / 1024 with tolerance 4.55e-06 
    :::::::::::::::::::::::
    Scanning at lag=189.40 ...
    
    Change of 0.03 against 100.00 
    Seems to have converged at iteration 64 / 1024 with tolerance 4.63e-06 
    :::::::::::::::::::::::
    Scanning at lag=189.37 ...
    
    Change of 0.02 against 100.00 
    Seems to have converged at iteration 65 / 1024 with tolerance 5.16e-05 
    :::::::::::::::::::::::
    Scanning at lag=189.33 ...
    
    Change of 0.01 against 100.00 
    Seems to have converged at iteration 66 / 1024 with tolerance 3.07e-05 
    :::::::::::::::::::::::
    Scanning at lag=189.30 ...
    
    Change of 0.01 against 100.00 
    Seems to have converged at iteration 67 / 1024 with tolerance 3.52e-05 
    :::::::::::::::::::::::
    Scanning at lag=189.27 ...
    
    Change of 0.01 against 100.00 
    Seems to have converged at iteration 68 / 1024 with tolerance 1.10e-06 
    :::::::::::::::::::::::
    Scanning at lag=189.23 ...
    
    Change of 0.01 against 100.00 
    Seems to have converged at iteration 69 / 1024 with tolerance 3.90e-06 
    :::::::::::::::::::::::
    Scanning at lag=189.20 ...
    
    Change of 0.01 against 100.00 
    Seems to have converged at iteration 70 / 1024 with tolerance 1.26e-05 
    :::::::::::::::::::::::
    Scanning at lag=189.16 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 71 / 1024 with tolerance 1.38e-06 
    :::::::::::::::::::::::
    Scanning at lag=189.13 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 72 / 1024 with tolerance 1.21e-06 
    :::::::::::::::::::::::
    Scanning at lag=189.10 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 73 / 1024 with tolerance 2.93e-05 
    :::::::::::::::::::::::
    Scanning at lag=189.06 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 74 / 1024 with tolerance 1.34e-06 
    :::::::::::::::::::::::
    Scanning at lag=189.03 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 75 / 1024 with tolerance 1.87e-05 
    :::::::::::::::::::::::
    Scanning at lag=189.00 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 76 / 1024 with tolerance 8.96e-07 
    :::::::::::::::::::::::
    Scanning at lag=188.96 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 77 / 1024 with tolerance 3.72e-06 
    :::::::::::::::::::::::
    Scanning at lag=188.93 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 78 / 1024 with tolerance 1.08e-05 
    :::::::::::::::::::::::
    Scanning at lag=188.90 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 79 / 1024 with tolerance 7.51e-07 
    :::::::::::::::::::::::
    Scanning at lag=188.86 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 80 / 1024 with tolerance 3.09e-06 
    :::::::::::::::::::::::
    Scanning at lag=188.83 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 81 / 1024 with tolerance 2.56e-05 
    :::::::::::::::::::::::
    Scanning at lag=188.80 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 82 / 1024 with tolerance 3.10e-06 
    :::::::::::::::::::::::
    Scanning at lag=188.76 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 83 / 1024 with tolerance 1.09e-05 
    :::::::::::::::::::::::
    Scanning at lag=188.73 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 84 / 1024 with tolerance 2.97e-06 
    :::::::::::::::::::::::
    Scanning at lag=188.69 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 85 / 1024 with tolerance 1.00e-06 
    :::::::::::::::::::::::
    Scanning at lag=188.66 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 86 / 1024 with tolerance 4.36e-06 
    :::::::::::::::::::::::
    Scanning at lag=188.53 ...
    
    Change of 0.02 against 100.00 
    Seems to have converged at iteration 87 / 1024 with tolerance 1.43e-05 
    :::::::::::::::::::::::
    Scanning at lag=188.40 ...
    
    Change of 0.01 against 100.00 
    Seems to have converged at iteration 88 / 1024 with tolerance 3.86e-05 
    :::::::::::::::::::::::
    Scanning at lag=188.26 ...
    
    Change of 0.01 against 100.00 
    Seems to have converged at iteration 89 / 1024 with tolerance 1.35e-06 
    :::::::::::::::::::::::
    Scanning at lag=188.13 ...
    
    Change of 0.01 against 100.00 
    Seems to have converged at iteration 90 / 1024 with tolerance 1.82e-05 
    :::::::::::::::::::::::
    Scanning at lag=188.00 ...
    
    Change of 0.01 against 100.00 
    Seems to have converged at iteration 91 / 1024 with tolerance 1.73e-05 
    :::::::::::::::::::::::
    Scanning at lag=187.87 ...
    
    Change of 0.01 against 100.00 
    Seems to have converged at iteration 92 / 1024 with tolerance 3.07e-06 
    :::::::::::::::::::::::
    Scanning at lag=187.74 ...
    
    Change of 0.01 against 100.00 
    Seems to have converged at iteration 93 / 1024 with tolerance 2.16e-05 
    :::::::::::::::::::::::
    Scanning at lag=187.28 ...
    
    Change of 0.24 against 100.00 
    Seems to have converged at iteration 94 / 1024 with tolerance 6.90e-06 
    :::::::::::::::::::::::
    Scanning at lag=186.52 ...
    
    Change of -0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=185.44 ...
    
    Change of 0.23 against 100.00 
    Seems to have converged at iteration 96 / 1024 with tolerance 2.94e-06 
    :::::::::::::::::::::::
    Scanning at lag=184.40 ...
    
    Change of 0.72 against 100.00 
    Seems to have converged at iteration 97 / 1024 with tolerance 2.45e-05 
    :::::::::::::::::::::::
    Scanning at lag=183.44 ...
    
    Change of 0.20 against 100.00 
    Seems to have converged at iteration 98 / 1024 with tolerance 1.05e-05 
    :::::::::::::::::::::::
    Scanning at lag=182.43 ...
    
    Change of 0.34 against 100.00 
    Seems to have converged at iteration 99 / 1024 with tolerance 2.93e-05 
    :::::::::::::::::::::::
    Scanning at lag=181.35 ...
    
    Change of 1.23 against 100.00 
    Seems to have converged at iteration 100 / 1024 with tolerance 1.75e-05 
    :::::::::::::::::::::::
    Scanning at lag=180.26 ...
    
    Change of 0.41 against 100.00 
    Seems to have converged at iteration 101 / 1024 with tolerance 1.16e-05 
    :::::::::::::::::::::::
    Scanning at lag=179.19 ...
    
    Change of 0.19 against 100.00 
    Seems to have converged at iteration 102 / 1024 with tolerance 4.11e-06 
    :::::::::::::::::::::::
    Scanning at lag=178.11 ...
    
    Change of 0.07 against 100.00 
    Seems to have converged at iteration 103 / 1024 with tolerance 9.84e-06 
    :::::::::::::::::::::::
    Scanning at lag=177.04 ...
    
    Change of 0.37 against 100.00 
    Seems to have converged at iteration 104 / 1024 with tolerance 2.51e-06 
    :::::::::::::::::::::::
    Scanning at lag=175.95 ...
    
    Change of 4.51 against 100.00 
    Seems to have converged at iteration 105 / 1024 with tolerance 1.16e-05 
    :::::::::::::::::::::::
    Scanning at lag=174.87 ...
    
    Change of 0.12 against 100.00 
    Seems to have converged at iteration 106 / 1024 with tolerance 7.03e-05 
    :::::::::::::::::::::::
    Scanning at lag=173.78 ...
    
    Change of 0.66 against 100.00 
    Seems to have converged at iteration 107 / 1024 with tolerance 1.08e-05 
    :::::::::::::::::::::::
    Scanning at lag=172.69 ...
    
    Change of 0.16 against 100.00 
    Seems to have converged at iteration 108 / 1024 with tolerance 1.39e-05 
    :::::::::::::::::::::::
    Scanning at lag=171.61 ...
    
    Change of 0.24 against 100.00 
    Seems to have converged at iteration 109 / 1024 with tolerance 3.42e-06 
    :::::::::::::::::::::::
    Scanning at lag=170.52 ...
    
    Change of 0.24 against 100.00 
    Seems to have converged at iteration 110 / 1024 with tolerance 1.02e-05 
    :::::::::::::::::::::::
    Scanning at lag=169.44 ...
    
    Change of -0.01 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=168.35 ...
    
    Change of -0.03 against 100.00 
    Seems to have converged at iteration 112 / 1024 with tolerance 2.41e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=167.26 ...
    
    Change of -0.01 against 100.00 
    Seems to have converged at iteration 113 / 1024 with tolerance 1.41e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=166.18 ...
    
    Change of 0.55 against 100.00 
    Seems to have converged at iteration 114 / 1024 with tolerance 9.86e+00 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=165.09 ...
    
    Change of 8.62 against 100.00 
    Seems to have converged at iteration 115 / 1024 with tolerance 1.46e-05 
    :::::::::::::::::::::::
    Scanning at lag=164.01 ...
    
    Change of 0.01 against 100.00 
    Seems to have converged at iteration 116 / 1024 with tolerance 3.22e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=162.92 ...
    
    Change of -3.58 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=161.83 ...
    
    Change of 27.61 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=160.75 ...
    
    Change of 22.09 against 100.00 
    Seems to have converged at iteration 119 / 1024 with tolerance 6.08e-06 
    :::::::::::::::::::::::
    Scanning at lag=159.66 ...
    
    Change of 0.49 against 100.00 
    Seems to have converged at iteration 120 / 1024 with tolerance 5.55e-06 
    :::::::::::::::::::::::
    Scanning at lag=158.57 ...
    
    Change of 0.27 against 100.00 
    Seems to have converged at iteration 121 / 1024 with tolerance 2.93e-05 
    :::::::::::::::::::::::
    Scanning at lag=157.49 ...
    
    Change of -0.22 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=156.40 ...
    
    Change of 5.56 against 100.00 
    Seems to have converged at iteration 123 / 1024 with tolerance 2.41e-05 
    :::::::::::::::::::::::
    Scanning at lag=155.32 ...
    
    Change of 1.76 against 100.00 
    Seems to have converged at iteration 124 / 1024 with tolerance 5.45e-07 
    :::::::::::::::::::::::
    Scanning at lag=154.23 ...
    
    Change of 0.53 against 100.00 
    Seems to have converged at iteration 125 / 1024 with tolerance 8.38e-06 
    :::::::::::::::::::::::
    Scanning at lag=153.14 ...
    
    Change of 0.25 against 100.00 
    Seems to have converged at iteration 126 / 1024 with tolerance 7.49e-06 
    :::::::::::::::::::::::
    Scanning at lag=152.06 ...
    
    Change of 0.30 against 100.00 
    Seems to have converged at iteration 127 / 1024 with tolerance 1.29e-05 
    :::::::::::::::::::::::
    Scanning at lag=150.97 ...
    
    Change of 2.61 against 100.00 
    Seems to have converged at iteration 128 / 1024 with tolerance 2.18e-05 
    :::::::::::::::::::::::
    Scanning at lag=149.89 ...
    
    Change of 30.32 against 100.00 
    Seems to have converged at iteration 129 / 1024 with tolerance 7.22e-06 
    :::::::::::::::::::::::
    Scanning at lag=148.80 ...
    
    Change of 1.27 against 100.00 
    Seems to have converged at iteration 130 / 1024 with tolerance 6.90e-06 
    :::::::::::::::::::::::
    Scanning at lag=147.71 ...
    
    Change of 0.35 against 100.00 
    Seems to have converged at iteration 131 / 1024 with tolerance 6.52e-06 
    :::::::::::::::::::::::
    Scanning at lag=146.63 ...
    
    Change of 0.40 against 100.00 
    Seems to have converged at iteration 132 / 1024 with tolerance 9.24e-06 
    :::::::::::::::::::::::
    Scanning at lag=145.54 ...
    
    Change of 1.72 against 100.00 
    Seems to have converged at iteration 133 / 1024 with tolerance 7.07e-06 
    :::::::::::::::::::::::
    Scanning at lag=144.46 ...
    
    Change of -0.12 against 100.00 
    Seems to have converged at iteration 134 / 1024 with tolerance 2.43e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=143.37 ...
    
    Change of 34.92 against 100.00 
    Seems to have converged at iteration 135 / 1024 with tolerance 1.17e-05 
    :::::::::::::::::::::::
    Scanning at lag=142.28 ...
    
    Change of -0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=141.20 ...
    
    Change of 1.53 against 100.00 
    Seems to have converged at iteration 137 / 1024 with tolerance 1.96e-05 
    :::::::::::::::::::::::
    Scanning at lag=140.11 ...
    
    Change of 0.30 against 100.00 
    Seems to have converged at iteration 138 / 1024 with tolerance 1.75e-05 
    :::::::::::::::::::::::
    Scanning at lag=139.02 ...
    
    Change of -0.01 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=137.94 ...
    
    Change of 16.79 against 100.00 
    Seems to have converged at iteration 140 / 1024 with tolerance 1.78e-05 
    :::::::::::::::::::::::
    Scanning at lag=136.85 ...
    
    Change of -0.03 against 100.00 
    Seems to have converged at iteration 141 / 1024 with tolerance 7.90e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=135.77 ...
    
    Change of 89.19 against 100.00 
    Seems to have converged at iteration 142 / 1024 with tolerance 2.14e-05 
    :::::::::::::::::::::::
    Scanning at lag=134.68 ...
    
    Change of 14.52 against 100.00 
    Seems to have converged at iteration 143 / 1024 with tolerance 1.05e-05 
    :::::::::::::::::::::::
    Scanning at lag=133.59 ...
    
    Change of 4.33 against 100.00 
    Seems to have converged at iteration 144 / 1024 with tolerance 1.74e-06 
    :::::::::::::::::::::::
    Scanning at lag=132.51 ...
    
    Change of 57.05 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=131.42 ...
    
    Change of 0.83 against 100.00 
    Seems to have converged at iteration 146 / 1024 with tolerance 1.30e-05 
    :::::::::::::::::::::::
    Scanning at lag=130.34 ...
    
    Change of 7.71 against 100.00 
    Seems to have converged at iteration 147 / 1024 with tolerance 1.28e-05 
    :::::::::::::::::::::::
    Scanning at lag=129.25 ...
    
    Change of -0.15 against 100.00 
    Seems to have converged at iteration 148 / 1024 with tolerance 6.69e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=128.16 ...
    
    Change of 50.68 against 100.00 
    Seems to have converged at iteration 149 / 1024 with tolerance 4.32e-06 
    :::::::::::::::::::::::
    Scanning at lag=127.08 ...
    
    Change of 0.84 against 100.00 
    Seems to have converged at iteration 150 / 1024 with tolerance 7.68e-06 
    :::::::::::::::::::::::
    Scanning at lag=125.99 ...
    
    Change of 0.28 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=124.90 ...
    
    Change of 8.31 against 100.00 
    Seems to have converged at iteration 152 / 1024 with tolerance 1.10e-05 
    :::::::::::::::::::::::
    Scanning at lag=123.82 ...
    
    Change of 4.01 against 100.00 
    Seems to have converged at iteration 153 / 1024 with tolerance 2.95e-06 
    :::::::::::::::::::::::
    Scanning at lag=122.73 ...
    
    Change of 15.20 against 100.00 
    Seems to have converged at iteration 154 / 1024 with tolerance 1.41e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=121.65 ...
    
    Change of 118.31 against 100.00 
    Seems to have converged at iteration 155 / 1024 with tolerance 1.91e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=120.56 ...
    
    Change of 226.58 against 100.00 
    Seems to have converged at iteration 156 / 1024 with tolerance 2.13e-05 
    :::::::::::::::::::::::
    Scanning at lag=119.47 ...
    
    Change of 0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=118.39 ...
    
    Change of 0.04 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=117.30 ...
    
    Change of 28.80 against 100.00 
    Seems to have converged at iteration 159 / 1024 with tolerance 8.89e-06 
    :::::::::::::::::::::::
    Scanning at lag=116.22 ...
    
    Change of -0.04 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=115.13 ...
    
    Change of 135.42 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=114.04 ...
    
    Change of 1.29 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=112.96 ...
    
    Change of 131.67 against 100.00 
    Seems to have converged at iteration 163 / 1024 with tolerance 8.18e-01 
    :::::::::::::::::::::::
    Scanning at lag=111.87 ...
    
    Change of 48.00 against 100.00 
    Seems to have converged at iteration 164 / 1024 with tolerance 7.23e-06 
    :::::::::::::::::::::::
    Scanning at lag=110.79 ...
    
    Change of 0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=109.70 ...
    
    Change of 4.64 against 100.00 
    Seems to have converged at iteration 166 / 1024 with tolerance 2.08e-05 
    :::::::::::::::::::::::
    Scanning at lag=108.61 ...
    
    Change of 0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=107.53 ...
    
    Change of 464.79 against 100.00 
    Seems to have converged at iteration 168 / 1024 with tolerance 1.12e-06 
    :::::::::::::::::::::::
    Scanning at lag=106.44 ...
    
    Change of 34.11 against 100.00 
    Seems to have converged at iteration 169 / 1024 with tolerance 2.92e+00 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=105.35 ...
    
    Change of -0.02 against 100.00 
    Seems to have converged at iteration 170 / 1024 with tolerance 2.66e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=104.27 ...
    
    Change of 0.62 against 100.00 
    Seems to have converged at iteration 171 / 1024 with tolerance 4.17e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=103.18 ...
    
    Change of -0.15 against 100.00 
    Seems to have converged at iteration 172 / 1024 with tolerance 8.38e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=102.10 ...
    
    Change of -61690.13 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=101.01 ...
    
    Change of 489.32 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=99.92 ...
    
    Change of 141.00 against 100.00 
    Seems to have converged at iteration 175 / 1024 with tolerance 1.93e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=98.84 ...
    
    Change of 393.15 against 100.00 
    Seems to have converged at iteration 176 / 1024 with tolerance 4.83e+00 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=97.75 ...
    
    Change of 3024.71 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=96.67 ...
    
    Change of 381.91 against 100.00 
    Seems to have converged at iteration 178 / 1024 with tolerance 1.22e-05 
    :::::::::::::::::::::::
    Scanning at lag=95.58 ...
    
    Change of 7.80 against 100.00 
    Seems to have converged at iteration 179 / 1024 with tolerance 9.22e-06 
    :::::::::::::::::::::::
    Scanning at lag=94.49 ...
    
    Change of 33.72 against 100.00 
    Seems to have converged at iteration 180 / 1024 with tolerance 4.42e+00 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=93.41 ...
    
    Change of 0.04 against 100.00 
    Seems to have converged at iteration 181 / 1024 with tolerance 4.43e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=92.32 ...
    
    Change of -0.17 against 100.00 
    Seems to have converged at iteration 182 / 1024 with tolerance 3.48e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=91.23 ...
    
    Change of 369.48 against 100.00 
    Seems to have converged at iteration 183 / 1024 with tolerance 3.32e+00 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=90.15 ...
    
    Change of -0.00 against 100.00 
    Seems to have converged at iteration 184 / 1024 with tolerance 6.15e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=89.06 ...
    
    Change of -0.10 against 100.00 
    Seems to have converged at iteration 185 / 1024 with tolerance 3.56e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=87.98 ...
    
    Change of -0.36 against 100.00 
    Seems to have converged at iteration 186 / 1024 with tolerance 4.77e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=86.89 ...
    
    Change of 1.46 against 100.00 
    Seems to have converged at iteration 187 / 1024 with tolerance 5.02e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=85.80 ...
    
    Change of -0.18 against 100.00 
    Seems to have converged at iteration 188 / 1024 with tolerance 4.03e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=84.72 ...
    
    Change of -1.12 against 100.00 
    Seems to have converged at iteration 189 / 1024 with tolerance 1.73e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=83.63 ...
    
    Change of -0.68 against 100.00 
    Seems to have converged at iteration 190 / 1024 with tolerance 3.12e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=82.55 ...
    
    Change of -6.77 against 100.00 
    Seems to have converged at iteration 191 / 1024 with tolerance 4.18e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=81.46 ...
    
    Change of -2.66 against 100.00 
    Seems to have converged at iteration 192 / 1024 with tolerance 6.07e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=80.37 ...
    
    Change of 2176.68 against 100.00 
    Seems to have converged at iteration 193 / 1024 with tolerance 1.02e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=79.29 ...
    
    Change of -0.18 against 100.00 
    Seems to have converged at iteration 194 / 1024 with tolerance 4.72e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=78.20 ...
    
    Change of 4.52 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=77.12 ...
    
    Change of 513.96 against 100.00 
    Seems to have converged at iteration 196 / 1024 with tolerance 2.22e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=76.03 ...
    
    Change of -2.31 against 100.00 
    Seems to have converged at iteration 197 / 1024 with tolerance 6.52e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=74.94 ...
    
    Change of 5.23 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=73.86 ...
    
    Change of -1.21 against 100.00 
    Seems to have converged at iteration 199 / 1024 with tolerance 8.26e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=72.77 ...
    
    Change of 3378.78 against 100.00 
    Seems to have converged at iteration 200 / 1024 with tolerance 1.55e+04 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=71.68 ...
    
    Change of 1217.41 against 100.00 
    Seems to have converged at iteration 201 / 1024 with tolerance 4.08e-01 
    :::::::::::::::::::::::
    Scanning at lag=70.60 ...
    
    Change of 0.01 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=69.51 ...
    
    Change of 33.67 against 100.00 
    Seems to have converged at iteration 203 / 1024 with tolerance 2.35e-05 
    :::::::::::::::::::::::
    Scanning at lag=68.43 ...
    
    Change of 233.51 against 100.00 
    Seems to have converged at iteration 204 / 1024 with tolerance 1.48e-06 
    :::::::::::::::::::::::
    Scanning at lag=67.34 ...
    
    Change of 30.17 against 100.00 
    Seems to have converged at iteration 205 / 1024 with tolerance 4.00e-06 
    :::::::::::::::::::::::
    Scanning at lag=66.25 ...
    
    Change of 109.20 against 100.00 
    Seems to have converged at iteration 206 / 1024 with tolerance 2.43e-06 
    :::::::::::::::::::::::
    Scanning at lag=65.17 ...
    
    Change of 21.36 against 100.00 
    Seems to have converged at iteration 207 / 1024 with tolerance 1.70e-05 
    :::::::::::::::::::::::
    Scanning at lag=64.08 ...
    
    Change of 30.12 against 100.00 
    Seems to have converged at iteration 208 / 1024 with tolerance 9.28e-06 
    :::::::::::::::::::::::
    Scanning at lag=63.00 ...
    
    Change of 19.06 against 100.00 
    Seems to have converged at iteration 209 / 1024 with tolerance 2.90e-06 
    :::::::::::::::::::::::
    Scanning at lag=61.91 ...
    
    Change of 266.28 against 100.00 
    Seems to have converged at iteration 210 / 1024 with tolerance 1.60e-05 
    :::::::::::::::::::::::
    Scanning at lag=60.82 ...
    
    Change of 127.84 against 100.00 
    Seems to have converged at iteration 211 / 1024 with tolerance 1.95e-06 
    :::::::::::::::::::::::
    Scanning at lag=59.74 ...
    
    Change of 2.86 against 100.00 
    Seems to have converged at iteration 212 / 1024 with tolerance 1.34e-05 
    :::::::::::::::::::::::
    Scanning at lag=58.65 ...
    
    Change of 8.72 against 100.00 
    Seems to have converged at iteration 213 / 1024 with tolerance 2.48e-05 
    :::::::::::::::::::::::
    Scanning at lag=57.56 ...
    
    Change of -0.04 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=56.48 ...
    
    Change of 97.94 against 100.00 
    Seems to have converged at iteration 215 / 1024 with tolerance 1.99e-05 
    :::::::::::::::::::::::
    Scanning at lag=55.39 ...
    
    Change of 0.01 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=54.31 ...
    
    Change of 43.37 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=53.22 ...
    
    Change of 10.85 against 100.00 
    Seems to have converged at iteration 218 / 1024 with tolerance 1.59e-05 
    :::::::::::::::::::::::
    Scanning at lag=52.13 ...
    
    Change of 2.73 against 100.00 
    Seems to have converged at iteration 219 / 1024 with tolerance 1.24e-05 
    :::::::::::::::::::::::
    Scanning at lag=51.05 ...
    
    Change of -0.05 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=49.96 ...
    
    Change of 88.95 against 100.00 
    Seems to have converged at iteration 221 / 1024 with tolerance 2.49e-05 
    :::::::::::::::::::::::
    Scanning at lag=48.88 ...
    
    Change of 4.53 against 100.00 
    Seems to have converged at iteration 222 / 1024 with tolerance 1.29e-05 
    :::::::::::::::::::::::
    Scanning at lag=47.79 ...
    
    Change of 19.74 against 100.00 
    Seems to have converged at iteration 223 / 1024 with tolerance 7.47e-06 
    :::::::::::::::::::::::
    Scanning at lag=46.70 ...
    
    Change of -0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=45.62 ...
    
    Change of 22.00 against 100.00 
    Seems to have converged at iteration 225 / 1024 with tolerance 3.10e-05 
    :::::::::::::::::::::::
    Scanning at lag=44.53 ...
    
    Change of -0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=43.45 ...
    
    Change of 15.64 against 100.00 
    Seems to have converged at iteration 227 / 1024 with tolerance 2.98e-05 
    :::::::::::::::::::::::
    Scanning at lag=42.36 ...
    
    Change of 41.34 against 100.00 
    Seems to have converged at iteration 228 / 1024 with tolerance 1.80e-05 
    :::::::::::::::::::::::
    Scanning at lag=41.27 ...
    
    Change of 15.59 against 100.00 
    Seems to have converged at iteration 229 / 1024 with tolerance 8.34e-06 
    :::::::::::::::::::::::
    Scanning at lag=40.19 ...
    
    Change of -0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=39.10 ...
    
    Change of 27.21 against 100.00 
    Seems to have converged at iteration 231 / 1024 with tolerance 9.43e-06 
    :::::::::::::::::::::::
    Scanning at lag=38.01 ...
    
    Change of 8.13 against 100.00 
    Seems to have converged at iteration 232 / 1024 with tolerance 4.83e-05 
    :::::::::::::::::::::::
    Scanning at lag=36.93 ...
    
    Change of 12.38 against 100.00 
    Seems to have converged at iteration 233 / 1024 with tolerance 1.38e-05 
    :::::::::::::::::::::::
    Scanning at lag=35.84 ...
    
    Change of 39.30 against 100.00 
    Seems to have converged at iteration 234 / 1024 with tolerance 3.17e-05 
    :::::::::::::::::::::::
    Scanning at lag=34.76 ...
    
    Change of 7.11 against 100.00 
    Seems to have converged at iteration 235 / 1024 with tolerance 9.83e-06 
    :::::::::::::::::::::::
    Scanning at lag=33.67 ...
    
    Change of 16.58 against 100.00 
    Seems to have converged at iteration 236 / 1024 with tolerance 2.67e-05 
    :::::::::::::::::::::::
    Scanning at lag=32.58 ...
    
    Change of 11.03 against 100.00 
    Seems to have converged at iteration 237 / 1024 with tolerance 4.93e-06 
    :::::::::::::::::::::::
    Scanning at lag=31.50 ...
    
    Change of 4.35 against 100.00 
    Seems to have converged at iteration 238 / 1024 with tolerance 1.29e-05 
    :::::::::::::::::::::::
    Scanning at lag=30.41 ...
    
    Change of -0.01 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=29.33 ...
    
    Change of 96.51 against 100.00 
    Seems to have converged at iteration 240 / 1024 with tolerance 1.30e-06 
    :::::::::::::::::::::::
    Scanning at lag=28.24 ...
    
    Change of 5.92 against 100.00 
    Seems to have converged at iteration 241 / 1024 with tolerance 5.20e-06 
    :::::::::::::::::::::::
    Scanning at lag=27.15 ...
    
    Change of 2.43 against 100.00 
    Seems to have converged at iteration 242 / 1024 with tolerance 1.87e-06 
    :::::::::::::::::::::::
    Scanning at lag=26.07 ...
    
    Change of 12.16 against 100.00 
    Seems to have converged at iteration 243 / 1024 with tolerance 4.83e-05 
    :::::::::::::::::::::::
    Scanning at lag=24.98 ...
    
    Change of 0.88 against 100.00 
    Seems to have converged at iteration 244 / 1024 with tolerance 2.89e-05 
    :::::::::::::::::::::::
    Scanning at lag=23.89 ...
    
    Change of 27.66 against 100.00 
    Seems to have converged at iteration 245 / 1024 with tolerance 5.46e-06 
    :::::::::::::::::::::::
    Scanning at lag=22.81 ...
    
    Change of -0.01 against 100.00 
    Seems to have converged at iteration 246 / 1024 with tolerance 3.23e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=21.72 ...
    
    Change of -3339.76 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=20.64 ...
    
    Change of 2138.82 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=19.55 ...
    
    Change of -11684959.96 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=18.46 ...
    
    Change of 3199.27 against 100.00 
    Seems to have converged at iteration 250 / 1024 with tolerance 8.39e-06 
    :::::::::::::::::::::::
    Scanning at lag=17.38 ...
    
    Change of -0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=16.29 ...
    
    Change of -0.13 against 100.00 
    Seems to have converged at iteration 252 / 1024 with tolerance 8.31e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=15.21 ...
    
    Change of 0.17 against 100.00 
    Seems to have converged at iteration 253 / 1024 with tolerance 1.03e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=14.12 ...
    
    Change of -2.17 against 100.00 
    Seems to have converged at iteration 254 / 1024 with tolerance 9.35e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=13.03 ...
    
    Change of 1.07 against 100.00 
    Seems to have converged at iteration 255 / 1024 with tolerance 8.20e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=11.95 ...
    
    Change of -0.07 against 100.00 
    Seems to have converged at iteration 256 / 1024 with tolerance 1.11e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=10.86 ...
    
    Change of -0.02 against 100.00 
    Seems to have converged at iteration 257 / 1024 with tolerance 7.84e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=9.78 ...
    
    Change of -0.02 against 100.00 
    Seems to have converged at iteration 258 / 1024 with tolerance 9.17e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=8.69 ...
    
    Change of -0.15 against 100.00 
    Seems to have converged at iteration 259 / 1024 with tolerance 1.03e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=7.60 ...
    
    Change of -0.05 against 100.00 
    Seems to have converged at iteration 260 / 1024 with tolerance 1.71e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=6.52 ...
    
    Change of -0.31 against 100.00 
    Seems to have converged at iteration 261 / 1024 with tolerance 8.02e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=5.43 ...
    
    Change of 0.21 against 100.00 
    Seems to have converged at iteration 262 / 1024 with tolerance 9.50e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=4.34 ...
    
    Change of -0.01 against 100.00 
    Seems to have converged at iteration 263 / 1024 with tolerance 4.19e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=3.26 ...
    
    Change of 169.45 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=2.17 ...
    
    Change of 23.32 against 100.00 
    Seems to have converged at iteration 265 / 1024 with tolerance 8.87e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=1.09 ...
    
    Change of 5.10 against 100.00 
    Seems to have converged at iteration 266 / 1024 with tolerance 1.67e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=0.00 ...
    
    Change of 0.06 against 100.00 
    Seems to have converged at iteration 267 / 1024 with tolerance 1.11e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=192.34 ...
    
    Change of 0.01 against 100.00 
    Seems to have converged at iteration 268 / 1024 with tolerance 8.90e-05 
    :::::::::::::::::::::::
    Scanning at lag=192.37 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 269 / 1024 with tolerance 2.66e-05 
    :::::::::::::::::::::::
    Scanning at lag=192.41 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 270 / 1024 with tolerance 2.81e-06 
    :::::::::::::::::::::::
    Scanning at lag=192.45 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 271 / 1024 with tolerance 1.82e-05 
    :::::::::::::::::::::::
    Scanning at lag=192.49 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 272 / 1024 with tolerance 2.15e-06 
    :::::::::::::::::::::::
    Scanning at lag=192.53 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 273 / 1024 with tolerance 2.51e-05 
    :::::::::::::::::::::::
    Scanning at lag=192.56 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 274 / 1024 with tolerance 1.21e-06 
    :::::::::::::::::::::::
    Scanning at lag=192.71 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 275 / 1024 with tolerance 9.35e-06 
    :::::::::::::::::::::::
    Scanning at lag=192.88 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 276 / 1024 with tolerance 6.98e-06 
    :::::::::::::::::::::::
    Scanning at lag=193.05 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 277 / 1024 with tolerance 1.84e-06 
    :::::::::::::::::::::::
    Scanning at lag=193.22 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 278 / 1024 with tolerance 2.66e-06 
    :::::::::::::::::::::::
    Scanning at lag=193.39 ...
    
    Change of -0.00 against 100.00 
    Seems to have converged at iteration 279 / 1024 with tolerance 2.83e-05 
    :::::::::::::::::::::::
    Scanning at lag=193.59 ...
    
    Change of -0.00 against 100.00 
    Seems to have converged at iteration 280 / 1024 with tolerance 4.48e-06 
    :::::::::::::::::::::::
    Scanning at lag=194.27 ...
    
    Change of 0.02 against 100.00 
    Seems to have converged at iteration 281 / 1024 with tolerance 4.26e-06 
    :::::::::::::::::::::::
    Scanning at lag=195.21 ...
    
    Change of 0.56 against 100.00 
    Seems to have converged at iteration 282 / 1024 with tolerance 3.17e-05 
    :::::::::::::::::::::::
    Scanning at lag=196.30 ...
    
    Change of 2.90 against 100.00 
    Seems to have converged at iteration 283 / 1024 with tolerance 2.52e-06 
    :::::::::::::::::::::::
    Scanning at lag=197.39 ...
    
    Change of 0.43 against 100.00 
    Seems to have converged at iteration 284 / 1024 with tolerance 1.22e-05 
    :::::::::::::::::::::::
    Scanning at lag=198.47 ...
    
    Change of 16.61 against 100.00 
    Seems to have converged at iteration 285 / 1024 with tolerance 2.77e-06 
    :::::::::::::::::::::::
    Scanning at lag=199.56 ...
    
    Change of 19.29 against 100.00 
    Seems to have converged at iteration 286 / 1024 with tolerance 1.88e-05 
    :::::::::::::::::::::::
    Scanning at lag=200.64 ...
    
    Change of 3.27 against 100.00 
    Seems to have converged at iteration 287 / 1024 with tolerance 7.20e-06 
    :::::::::::::::::::::::
    Scanning at lag=201.73 ...
    
    Change of 1.30 against 100.00 
    Seems to have converged at iteration 288 / 1024 with tolerance 4.40e-06 
    :::::::::::::::::::::::
    Scanning at lag=202.82 ...
    
    Change of 0.24 against 100.00 
    Seems to have converged at iteration 289 / 1024 with tolerance 4.22e-07 
    :::::::::::::::::::::::
    Scanning at lag=203.90 ...
    
    Change of 7.09 against 100.00 
    Seems to have converged at iteration 290 / 1024 with tolerance 1.02e-05 
    :::::::::::::::::::::::
    Scanning at lag=204.99 ...
    
    Change of 2.93 against 100.00 
    Seems to have converged at iteration 291 / 1024 with tolerance 3.86e-06 
    :::::::::::::::::::::::
    Scanning at lag=206.07 ...
    
    Change of 1.21 against 100.00 
    Seems to have converged at iteration 292 / 1024 with tolerance 6.24e-06 
    :::::::::::::::::::::::
    Scanning at lag=207.16 ...
    
    Change of 1.31 against 100.00 
    Seems to have converged at iteration 293 / 1024 with tolerance 1.19e-07 
    :::::::::::::::::::::::
    Scanning at lag=208.25 ...
    
    Change of 19.00 against 100.00 
    Seems to have converged at iteration 294 / 1024 with tolerance 5.40e-05 
    :::::::::::::::::::::::
    Scanning at lag=209.33 ...
    
    Change of 0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=210.42 ...
    
    Change of 0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=211.50 ...
    
    Change of 48.91 against 100.00 
    Seems to have converged at iteration 297 / 1024 with tolerance 2.37e-01 
    :::::::::::::::::::::::
    Scanning at lag=212.58 ...
    
    Change of 28.30 against 100.00 
    Seems to have converged at iteration 298 / 1024 with tolerance 6.45e-05 
    :::::::::::::::::::::::
    Scanning at lag=213.65 ...
    
    Change of 0.98 against 100.00 
    Seems to have converged at iteration 299 / 1024 with tolerance 3.99e-05 
    :::::::::::::::::::::::
    Scanning at lag=214.73 ...
    
    Change of 0.70 against 100.00 
    Seems to have converged at iteration 300 / 1024 with tolerance 1.08e-05 
    :::::::::::::::::::::::
    Scanning at lag=215.81 ...
    
    Change of 9.07 against 100.00 
    Seems to have converged at iteration 301 / 1024 with tolerance 9.77e-07 
    :::::::::::::::::::::::
    Scanning at lag=216.90 ...
    
    Change of -0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=217.99 ...
    
    Change of 5.69 against 100.00 
    Seems to have converged at iteration 303 / 1024 with tolerance 1.14e-06 
    :::::::::::::::::::::::
    Scanning at lag=219.07 ...
    
    Change of 0.69 against 100.00 
    Seems to have converged at iteration 304 / 1024 with tolerance 8.11e-06 
    :::::::::::::::::::::::
    Scanning at lag=220.16 ...
    
    Change of 2.83 against 100.00 
    Seems to have converged at iteration 305 / 1024 with tolerance 4.55e-05 
    :::::::::::::::::::::::
    Scanning at lag=221.24 ...
    
    Change of 1.96 against 100.00 
    Seems to have converged at iteration 306 / 1024 with tolerance 1.70e-05 
    :::::::::::::::::::::::
    Scanning at lag=222.33 ...
    
    Change of 15.50 against 100.00 
    Seems to have converged at iteration 307 / 1024 with tolerance 1.31e-05 
    :::::::::::::::::::::::
    Scanning at lag=223.42 ...
    
    Change of 5.22 against 100.00 
    Seems to have converged at iteration 308 / 1024 with tolerance 6.66e-05 
    :::::::::::::::::::::::
    Scanning at lag=224.50 ...
    
    Change of 1.90 against 100.00 
    Seems to have converged at iteration 309 / 1024 with tolerance 2.31e-05 
    :::::::::::::::::::::::
    Scanning at lag=225.59 ...
    
    Change of -0.02 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=226.68 ...
    
    Change of 15.17 against 100.00 
    Seems to have converged at iteration 311 / 1024 with tolerance 1.77e-06 
    :::::::::::::::::::::::
    Scanning at lag=227.76 ...
    
    Change of 0.01 against 100.00 
    Seems to have converged at iteration 312 / 1024 with tolerance 4.63e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=228.85 ...
    
    Change of 248.57 against 100.00 
    Seems to have converged at iteration 313 / 1024 with tolerance 3.24e-06 
    :::::::::::::::::::::::
    Scanning at lag=229.93 ...
    
    Change of 0.03 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=231.02 ...
    
    Change of -0.01 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=232.11 ...
    
    Change of 20.05 against 100.00 
    Seems to have converged at iteration 316 / 1024 with tolerance 1.41e-06 
    :::::::::::::::::::::::
    Scanning at lag=233.19 ...
    
    Change of -0.01 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=234.28 ...
    
    Change of 15.88 against 100.00 
    Seems to have converged at iteration 318 / 1024 with tolerance 2.09e-06 
    :::::::::::::::::::::::
    Scanning at lag=235.36 ...
    
    Change of 16.75 against 100.00 
    Seems to have converged at iteration 319 / 1024 with tolerance 5.43e-06 
    :::::::::::::::::::::::
    Scanning at lag=236.45 ...
    
    Change of 0.51 against 100.00 
    Seems to have converged at iteration 320 / 1024 with tolerance 3.30e-05 
    :::::::::::::::::::::::
    Scanning at lag=237.54 ...
    
    Change of -0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=238.62 ...
    
    Change of 6.98 against 100.00 
    Seems to have converged at iteration 322 / 1024 with tolerance 2.21e-05 
    :::::::::::::::::::::::
    Scanning at lag=239.71 ...
    
    Change of 0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=240.80 ...
    
    Change of 2.73 against 100.00 
    Seems to have converged at iteration 324 / 1024 with tolerance 4.70e-06 
    :::::::::::::::::::::::
    Scanning at lag=241.88 ...
    
    Change of 6.59 against 100.00 
    Seems to have converged at iteration 325 / 1024 with tolerance 1.68e-05 
    :::::::::::::::::::::::
    Scanning at lag=242.97 ...
    
    Change of -0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=244.05 ...
    
    Change of 8.46 against 100.00 
    Seems to have converged at iteration 327 / 1024 with tolerance 8.06e-06 
    :::::::::::::::::::::::
    Scanning at lag=245.14 ...
    
    Change of 1.53 against 100.00 
    Seems to have converged at iteration 328 / 1024 with tolerance 9.47e-06 
    :::::::::::::::::::::::
    Scanning at lag=246.23 ...
    
    Change of 10.97 against 100.00 
    Seems to have converged at iteration 329 / 1024 with tolerance 1.12e-05 
    :::::::::::::::::::::::
    Scanning at lag=247.31 ...
    
    Change of -0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=248.40 ...
    
    Change of 0.35 against 100.00 
    Seems to have converged at iteration 331 / 1024 with tolerance 6.63e-06 
    :::::::::::::::::::::::
    Scanning at lag=249.48 ...
    
    Change of 2.04 against 100.00 
    Seems to have converged at iteration 332 / 1024 with tolerance 1.96e-05 
    :::::::::::::::::::::::
    Scanning at lag=250.57 ...
    
    Change of 0.92 against 100.00 
    Seems to have converged at iteration 333 / 1024 with tolerance 6.22e-06 
    :::::::::::::::::::::::
    Scanning at lag=251.66 ...
    
    Change of 0.79 against 100.00 
    Seems to have converged at iteration 334 / 1024 with tolerance 1.26e-05 
    :::::::::::::::::::::::
    Scanning at lag=252.74 ...
    
    Change of 15.71 against 100.00 
    Seems to have converged at iteration 335 / 1024 with tolerance 1.25e-05 
    :::::::::::::::::::::::
    Scanning at lag=253.83 ...
    
    Change of 10.79 against 100.00 
    Seems to have converged at iteration 336 / 1024 with tolerance 7.10e-06 
    :::::::::::::::::::::::
    Scanning at lag=254.91 ...
    
    Change of 0.69 against 100.00 
    Seems to have converged at iteration 337 / 1024 with tolerance 3.65e-06 
    :::::::::::::::::::::::
    Scanning at lag=256.00 ...
    
    Change of 1.59 against 100.00 
    Seems to have converged at iteration 338 / 1024 with tolerance 2.35e-05 
    :::::::::::::::::::::::
    Scanning at lag=257.09 ...
    
    Change of 0.60 against 100.00 
    Seems to have converged at iteration 339 / 1024 with tolerance 7.25e-06 
    :::::::::::::::::::::::
    Scanning at lag=258.17 ...
    
    Change of 0.01 against 100.00 
    Seems to have converged at iteration 340 / 1024 with tolerance 5.13e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=259.26 ...
    
    Change of -0.11 against 100.00 
    Seems to have converged at iteration 341 / 1024 with tolerance 2.65e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=260.35 ...
    
    Change of -1.31 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=261.43 ...
    
    Change of 43.63 against 100.00 
    Seems to have converged at iteration 343 / 1024 with tolerance 4.48e+00 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=262.52 ...
    
    Change of 0.05 against 100.00 
    Seems to have converged at iteration 344 / 1024 with tolerance 1.55e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=263.60 ...
    
    Change of -0.33 against 100.00 
    Seems to have converged at iteration 345 / 1024 with tolerance 7.51e+00 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=264.69 ...
    
    Change of -8.17 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=265.78 ...
    
    Change of -36.44 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=266.86 ...
    
    Change of -115.39 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=267.95 ...
    
    Change of 80.25 against 100.00 
    Seems to have converged at iteration 349 / 1024 with tolerance 6.17e-06 
    :::::::::::::::::::::::
    Scanning at lag=269.03 ...
    
    Change of 141.53 against 100.00 
    Seems to have converged at iteration 350 / 1024 with tolerance 1.53e-06 
    :::::::::::::::::::::::
    Scanning at lag=270.12 ...
    
    Change of 29.88 against 100.00 
    Seems to have converged at iteration 351 / 1024 with tolerance 1.87e-05 
    :::::::::::::::::::::::
    Scanning at lag=271.21 ...
    
    Change of 17.99 against 100.00 
    Seems to have converged at iteration 352 / 1024 with tolerance 2.13e-05 
    :::::::::::::::::::::::
    Scanning at lag=272.29 ...
    
    Change of 0.02 against 100.00 
    Seems to have converged at iteration 353 / 1024 with tolerance 3.75e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=273.38 ...
    
    Change of -0.39 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=274.47 ...
    
    Change of 96.74 against 100.00 
    Seems to have converged at iteration 355 / 1024 with tolerance 5.52e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=275.55 ...
    
    Change of 312.02 against 100.00 
    Seems to have converged at iteration 356 / 1024 with tolerance 1.96e-05 
    :::::::::::::::::::::::
    Scanning at lag=276.64 ...
    
    Change of -0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=277.72 ...
    
    Change of 1.88 against 100.00 
    Seems to have converged at iteration 358 / 1024 with tolerance 7.63e-05 
    :::::::::::::::::::::::
    Scanning at lag=278.81 ...
    
    Change of -0.00 against 100.00 
    Seems to have converged at iteration 359 / 1024 with tolerance 3.49e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=279.90 ...
    
    Change of -253.81 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=280.98 ...
    
    Change of -152.02 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=282.07 ...
    
    Change of 195.11 against 100.00 
    Seems to have converged at iteration 362 / 1024 with tolerance 1.29e-05 
    :::::::::::::::::::::::
    Scanning at lag=283.15 ...
    
    Change of 0.29 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=284.24 ...
    
    Change of 17.75 against 100.00 
    Seems to have converged at iteration 364 / 1024 with tolerance 2.40e-06 
    :::::::::::::::::::::::
    Scanning at lag=285.33 ...
    
    Change of 3.62 against 100.00 
    Seems to have converged at iteration 365 / 1024 with tolerance 6.78e-07 
    :::::::::::::::::::::::
    Scanning at lag=286.41 ...
    
    Change of 13.67 against 100.00 
    Seems to have converged at iteration 366 / 1024 with tolerance 2.76e-05 
    :::::::::::::::::::::::
    Scanning at lag=287.50 ...
    
    Change of 32.40 against 100.00 
    Seems to have converged at iteration 367 / 1024 with tolerance 2.21e-05 
    :::::::::::::::::::::::
    Scanning at lag=288.58 ...
    
    Change of 22.40 against 100.00 
    Seems to have converged at iteration 368 / 1024 with tolerance 6.59e-04 
    :::::::::::::::::::::::
    Scanning at lag=289.67 ...
    
    Change of -0.02 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=290.76 ...
    
    Change of 18.05 against 100.00 
    Seems to have converged at iteration 370 / 1024 with tolerance 1.01e-05 
    :::::::::::::::::::::::
    Scanning at lag=291.84 ...
    
    Change of -0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=292.93 ...
    
    Change of -0.03 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=294.02 ...
    
    Change of 5.54 against 100.00 
    Seems to have converged at iteration 373 / 1024 with tolerance 7.53e-06 
    :::::::::::::::::::::::
    Scanning at lag=295.10 ...
    
    Change of 4.47 against 100.00 
    Seems to have converged at iteration 374 / 1024 with tolerance 1.63e-05 
    :::::::::::::::::::::::
    Scanning at lag=296.19 ...
    
    Change of -0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=297.27 ...
    
    Change of 0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=298.36 ...
    
    Change of 29.98 against 100.00 
    Seems to have converged at iteration 377 / 1024 with tolerance 1.18e-06 
    :::::::::::::::::::::::
    Scanning at lag=299.45 ...
    
    Change of 4.70 against 100.00 
    Seems to have converged at iteration 378 / 1024 with tolerance 6.48e-07 
    :::::::::::::::::::::::
    Scanning at lag=300.53 ...
    
    Change of -0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=301.62 ...
    
    Change of 126.12 against 100.00 
    Seems to have converged at iteration 380 / 1024 with tolerance 1.53e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=302.70 ...
    
    Change of 0.12 against 100.00 
    Seems to have converged at iteration 381 / 1024 with tolerance 2.34e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=303.79 ...
    
    Change of -0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=304.88 ...
    
    Change of -0.02 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=305.96 ...
    
    Change of -0.01 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=307.05 ...
    
    Change of -0.06 against 100.00 
    Seems to have converged at iteration 385 / 1024 with tolerance 1.19e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=308.14 ...
    
    Change of -0.04 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=309.22 ...
    
    Change of -35.66 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=310.31 ...
    
    Change of -5.93 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=311.39 ...
    
    Change of -2.26 against 100.00 
    Seems to have converged at iteration 389 / 1024 with tolerance 2.53e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=312.48 ...
    
    Change of 784.52 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=313.57 ...
    
    Change of -8.89 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=314.65 ...
    
    Change of -569.83 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=315.74 ...
    
    Change of -2186.47 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=316.82 ...
    
    Change of 862.89 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=317.91 ...
    
    Change of -57.75 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=319.00 ...
    
    Change of 1640.88 against 100.00 
    Seems to have converged at iteration 396 / 1024 with tolerance 5.37e-06 
    :::::::::::::::::::::::
    Scanning at lag=320.08 ...
    
    Change of 0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=321.17 ...
    
    Change of 5.55 against 100.00 
    Seems to have converged at iteration 398 / 1024 with tolerance 3.80e-05 
    :::::::::::::::::::::::
    Scanning at lag=322.25 ...
    
    Change of 29.02 against 100.00 
    Seems to have converged at iteration 399 / 1024 with tolerance 1.11e-06 
    :::::::::::::::::::::::
    Scanning at lag=323.34 ...
    
    Change of 1.13 against 100.00 
    Seems to have converged at iteration 400 / 1024 with tolerance 6.40e-06 
    :::::::::::::::::::::::
    Scanning at lag=324.43 ...
    
    Change of 0.01 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=325.51 ...
    
    Change of 25.58 against 100.00 
    Seems to have converged at iteration 402 / 1024 with tolerance 2.47e+00 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=326.60 ...
    
    Change of 991.43 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=327.69 ...
    
    Change of 1438.72 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=328.77 ...
    
    Change of 1408.99 against 100.00 
    Seems to have converged at iteration 405 / 1024 with tolerance 7.10e-07 
    :::::::::::::::::::::::
    Scanning at lag=329.86 ...
    
    Change of 11.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=330.94 ...
    
    Change of 5.05 against 100.00 
    Seems to have converged at iteration 407 / 1024 with tolerance 1.72e-06 
    :::::::::::::::::::::::
    Scanning at lag=332.03 ...
    
    Change of 151.61 against 100.00 
    Seems to have converged at iteration 408 / 1024 with tolerance 1.17e+03 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=333.12 ...
    
    Change of 1882.89 against 100.00 
    Seems to have converged at iteration 409 / 1024 with tolerance 4.83e-05 
    :::::::::::::::::::::::
    Scanning at lag=334.20 ...
    
    Change of 35.61 against 100.00 
    Seems to have converged at iteration 410 / 1024 with tolerance 6.58e-06 
    :::::::::::::::::::::::
    Scanning at lag=335.29 ...
    
    Change of 0.81 against 100.00 
    Seems to have converged at iteration 411 / 1024 with tolerance 4.00e-05 
    :::::::::::::::::::::::
    Scanning at lag=336.37 ...
    
    Change of 6.91 against 100.00 
    Seems to have converged at iteration 412 / 1024 with tolerance 1.29e-05 
    :::::::::::::::::::::::
    Scanning at lag=337.46 ...
    
    Change of -1.48 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=338.55 ...
    
    Change of 14.51 against 100.00 
    Seems to have converged at iteration 414 / 1024 with tolerance 3.44e-05 
    :::::::::::::::::::::::
    Scanning at lag=339.63 ...
    
    Change of -0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=340.72 ...
    
    Change of 3.71 against 100.00 
    Seems to have converged at iteration 416 / 1024 with tolerance 1.44e-05 
    :::::::::::::::::::::::
    Scanning at lag=341.81 ...
    
    Change of 14.13 against 100.00 
    Seems to have converged at iteration 417 / 1024 with tolerance 3.94e-06 
    :::::::::::::::::::::::
    Scanning at lag=342.89 ...
    
    Change of 15.30 against 100.00 
    Seems to have converged at iteration 418 / 1024 with tolerance 3.84e-06 
    :::::::::::::::::::::::
    Scanning at lag=343.98 ...
    
    Change of 5.64 against 100.00 
    Seems to have converged at iteration 419 / 1024 with tolerance 9.81e-06 
    :::::::::::::::::::::::
    Scanning at lag=345.06 ...
    
    Change of 7.61 against 100.00 
    Seems to have converged at iteration 420 / 1024 with tolerance 4.78e-06 
    :::::::::::::::::::::::
    Scanning at lag=346.15 ...
    
    Change of -0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=347.24 ...
    
    Change of 13.93 against 100.00 
    Seems to have converged at iteration 422 / 1024 with tolerance 3.92e-02 
    :::::::::::::::::::::::
    Scanning at lag=348.32 ...
    
    Change of 3.25 against 100.00 
    Seems to have converged at iteration 423 / 1024 with tolerance 2.79e-05 
    :::::::::::::::::::::::
    Scanning at lag=349.41 ...
    
    Change of 26.34 against 100.00 
    Seems to have converged at iteration 424 / 1024 with tolerance 2.16e-05 
    :::::::::::::::::::::::
    Scanning at lag=350.49 ...
    
    Change of 25.05 against 100.00 
    Seems to have converged at iteration 425 / 1024 with tolerance 2.95e-05 
    :::::::::::::::::::::::
    Scanning at lag=351.58 ...
    
    Change of 1.77 against 100.00 
    Seems to have converged at iteration 426 / 1024 with tolerance 9.45e-06 
    :::::::::::::::::::::::
    Scanning at lag=352.67 ...
    
    Change of 120.09 against 100.00 
    Seems to have converged at iteration 427 / 1024 with tolerance 6.74e-06 
    :::::::::::::::::::::::
    Scanning at lag=353.75 ...
    
    Change of 34.37 against 100.00 
    Seems to have converged at iteration 428 / 1024 with tolerance 2.59e-05 
    :::::::::::::::::::::::
    Scanning at lag=354.84 ...
    
    Change of -0.02 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=355.92 ...
    
    Change of 30.64 against 100.00 
    Seems to have converged at iteration 430 / 1024 with tolerance 3.19e-06 
    :::::::::::::::::::::::
    Scanning at lag=357.01 ...
    
    Change of 6.75 against 100.00 
    Seems to have converged at iteration 431 / 1024 with tolerance 1.63e-06 
    :::::::::::::::::::::::
    Scanning at lag=358.10 ...
    
    Change of 5.83 against 100.00 
    Seems to have converged at iteration 432 / 1024 with tolerance 5.01e-07 
    :::::::::::::::::::::::
    Scanning at lag=359.18 ...
    
    Change of 2.98 against 100.00 
    Seems to have converged at iteration 433 / 1024 with tolerance 5.85e-06 
    :::::::::::::::::::::::
    Scanning at lag=360.27 ...
    
    Change of 4.86 against 100.00 
    Seems to have converged at iteration 434 / 1024 with tolerance 5.44e-05 
    :::::::::::::::::::::::
    Scanning at lag=361.36 ...
    
    Change of 7.21 against 100.00 
    Seems to have converged at iteration 435 / 1024 with tolerance 2.08e-05 
    :::::::::::::::::::::::
    Scanning at lag=362.44 ...
    
    Change of -0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=363.53 ...
    
    Change of 232.25 against 100.00 
    Seems to have converged at iteration 437 / 1024 with tolerance 2.63e-06 
    :::::::::::::::::::::::
    Scanning at lag=364.61 ...
    
    Change of -0.01 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=365.70 ...
    
    Change of 0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=366.79 ...
    
    Change of 100.24 against 100.00 
    Seems to have converged at iteration 440 / 1024 with tolerance 1.68e-06 
    :::::::::::::::::::::::
    Scanning at lag=367.87 ...
    
    Change of 5.17 against 100.00 
    Seems to have converged at iteration 441 / 1024 with tolerance 2.20e-06 
    :::::::::::::::::::::::
    Scanning at lag=368.96 ...
    
    Change of 4.72 against 100.00 
    Seems to have converged at iteration 442 / 1024 with tolerance 2.03e-05 
    :::::::::::::::::::::::
    Scanning at lag=370.04 ...
    
    Change of 73.13 against 100.00 
    Seems to have converged at iteration 443 / 1024 with tolerance 5.22e-06 
    :::::::::::::::::::::::
    Scanning at lag=371.13 ...
    
    Change of 0.02 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=372.22 ...
    
    Change of 23.46 against 100.00 
    Seems to have converged at iteration 445 / 1024 with tolerance 3.90e-05 
    :::::::::::::::::::::::
    Scanning at lag=373.30 ...
    
    Change of 1.49 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=374.39 ...
    
    Change of 315.91 against 100.00 
    Seems to have converged at iteration 447 / 1024 with tolerance 1.72e-05 
    :::::::::::::::::::::::
    Scanning at lag=375.48 ...
    
    Change of 45.89 against 100.00 
    Seems to have converged at iteration 448 / 1024 with tolerance 8.42e-07 
    :::::::::::::::::::::::
    Scanning at lag=376.56 ...
    
    Change of -0.63 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=377.65 ...
    
    Change of 4.23 against 100.00 
    Seems to have converged at iteration 450 / 1024 with tolerance 7.64e-06 
    :::::::::::::::::::::::
    Scanning at lag=378.73 ...
    
    Change of 0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=379.82 ...
    
    Change of 35.91 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=380.91 ...
    
    Change of 435.48 against 100.00 
    Seems to have converged at iteration 453 / 1024 with tolerance 2.89e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=381.99 ...
    
    Change of 0.00 against 100.00 
    Seems to have converged at iteration 454 / 1024 with tolerance 4.41e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=383.08 ...
    
    Change of -0.55 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=384.16 ...
    
    Change of 2519.37 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=385.25 ...
    
    Change of 1959.96 against 100.00 
    Seems to have converged at iteration 457 / 1024 with tolerance 1.48e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=386.34 ...
    
    Change of -1071.93 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=387.42 ...
    
    Change of 2309.05 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=388.51 ...
    
    Change of 1471.18 against 100.00 
    Seems to have converged at iteration 460 / 1024 with tolerance 4.38e-06 
    :::::::::::::::::::::::
    Scanning at lag=389.59 ...
    
    Change of -0.63 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=390.68 ...
    
    Change of 19.14 against 100.00 
    Seems to have converged at iteration 462 / 1024 with tolerance 2.51e-05 
    :::::::::::::::::::::::
    Scanning at lag=391.77 ...
    
    Change of -0.03 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=392.85 ...
    
    Change of 6.37 against 100.00 
    Seems to have converged at iteration 464 / 1024 with tolerance 8.84e-06 
    :::::::::::::::::::::::
    Scanning at lag=393.94 ...
    
    Change of 4.08 against 100.00 
    Seems to have converged at iteration 465 / 1024 with tolerance 1.12e-06 
    :::::::::::::::::::::::
    Scanning at lag=395.03 ...
    
    Change of 1.90 against 100.00 
    Seems to have converged at iteration 466 / 1024 with tolerance 1.19e-05 
    :::::::::::::::::::::::
    Scanning at lag=396.11 ...
    
    Change of -0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=397.20 ...
    
    Change of 4.85 against 100.00 
    Seems to have converged at iteration 468 / 1024 with tolerance 9.56e-06 
    :::::::::::::::::::::::
    Scanning at lag=398.28 ...
    
    Change of 30.87 against 100.00 
    Seems to have converged at iteration 469 / 1024 with tolerance 6.44e-05 
    :::::::::::::::::::::::
    Scanning at lag=399.37 ...
    
    Change of 0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=400.46 ...
    
    Change of 0.58 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=401.54 ...
    
    Change of 22.18 against 100.00 
    Seems to have converged at iteration 472 / 1024 with tolerance 1.56e-06 
    :::::::::::::::::::::::
    Scanning at lag=402.63 ...
    
    Change of 18.70 against 100.00 
    Seems to have converged at iteration 473 / 1024 with tolerance 3.42e-06 
    :::::::::::::::::::::::
    Scanning at lag=403.71 ...
    
    Change of 2.20 against 100.00 
    Seems to have converged at iteration 474 / 1024 with tolerance 2.01e-05 
    :::::::::::::::::::::::
    Scanning at lag=404.80 ...
    
    Change of 38.84 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=405.89 ...
    
    Change of 0.51 against 100.00 
    Seems to have converged at iteration 476 / 1024 with tolerance 5.16e-06 
    :::::::::::::::::::::::
    Scanning at lag=406.97 ...
    
    Change of 31.03 against 100.00 
    Seems to have converged at iteration 477 / 1024 with tolerance 2.37e-06 
    :::::::::::::::::::::::
    Scanning at lag=408.06 ...
    
    Change of 12.43 against 100.00 
    Seems to have converged at iteration 478 / 1024 with tolerance 9.41e-06 
    :::::::::::::::::::::::
    Scanning at lag=409.15 ...
    
    Change of 62.72 against 100.00 
    Seems to have converged at iteration 479 / 1024 with tolerance 7.39e-05 
    :::::::::::::::::::::::
    Scanning at lag=410.23 ...
    
    Change of 13.41 against 100.00 
    Seems to have converged at iteration 480 / 1024 with tolerance 4.10e-06 
    :::::::::::::::::::::::
    Scanning at lag=411.32 ...
    
    Change of -0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=412.40 ...
    
    Change of 0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=413.49 ...
    
    Change of 13.03 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=414.58 ...
    
    Change of 12.48 against 100.00 
    Seems to have converged at iteration 484 / 1024 with tolerance 4.48e-06 
    :::::::::::::::::::::::
    Scanning at lag=415.66 ...
    
    Change of -0.03 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=416.75 ...
    
    Change of 6.16 against 100.00 
    Seems to have converged at iteration 486 / 1024 with tolerance 3.25e-05 
    :::::::::::::::::::::::
    Scanning at lag=417.83 ...
    
    Change of 74.32 against 100.00 
    Seems to have converged at iteration 487 / 1024 with tolerance 1.69e-05 
    :::::::::::::::::::::::
    Scanning at lag=418.92 ...
    
    Change of -0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=420.01 ...
    
    Change of 71.94 against 100.00 
    Seems to have converged at iteration 489 / 1024 with tolerance 3.74e-06 
    :::::::::::::::::::::::
    Scanning at lag=421.09 ...
    
    Change of 14.90 against 100.00 
    Seems to have converged at iteration 490 / 1024 with tolerance 2.13e-05 
    :::::::::::::::::::::::
    Scanning at lag=422.18 ...
    
    Change of 27.71 against 100.00 
    Seems to have converged at iteration 491 / 1024 with tolerance 3.44e-05 
    :::::::::::::::::::::::
    Scanning at lag=423.26 ...
    
    Change of -0.05 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=424.35 ...
    
    Change of -1.42 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=425.44 ...
    
    Change of 15.63 against 100.00 
    Seems to have converged at iteration 494 / 1024 with tolerance 2.97e-06 
    :::::::::::::::::::::::
    Scanning at lag=426.52 ...
    
    Change of 18.85 against 100.00 
    Seems to have converged at iteration 495 / 1024 with tolerance 4.11e-06 
    :::::::::::::::::::::::
    Scanning at lag=427.61 ...
    
    Change of 22.01 against 100.00 
    Seems to have converged at iteration 496 / 1024 with tolerance 8.48e-05 
    :::::::::::::::::::::::
    Scanning at lag=428.70 ...
    
    Change of -0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=429.78 ...
    
    Change of 43.40 against 100.00 
    Seems to have converged at iteration 498 / 1024 with tolerance 2.28e+00 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=430.87 ...
    
    Change of -0.49 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=431.95 ...
    
    Change of -4.32 against 100.00 
    Seems to have converged at iteration 500 / 1024 with tolerance 6.17e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=433.04 ...
    
    Change of -14.25 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=434.13 ...
    
    Change of -15.23 against 100.00 
    Seems to have converged at iteration 502 / 1024 with tolerance 1.67e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=435.21 ...
    
    Change of -0.11 against 100.00 
    Seems to have converged at iteration 503 / 1024 with tolerance 2.27e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=436.30 ...
    
    Change of -0.03 against 100.00 
    Seems to have converged at iteration 504 / 1024 with tolerance 8.00e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=437.38 ...
    
    Change of -0.02 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=438.47 ...
    
    Change of -0.10 against 100.00 
    Seems to have converged at iteration 506 / 1024 with tolerance 2.68e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=439.56 ...
    
    Change of -136.37 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=440.64 ...
    
    Change of 2514.77 against 100.00 
    Seems to have converged at iteration 508 / 1024 with tolerance 3.60e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=441.73 ...
    
    Change of -175.34 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=442.82 ...
    
    Change of 1980.07 against 100.00 
    Seems to have converged at iteration 510 / 1024 with tolerance 1.59e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=443.90 ...
    
    Change of 962.57 against 100.00 
    Seems to have converged at iteration 511 / 1024 with tolerance 8.67e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=444.99 ...
    
    Change of -10795918.44 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=446.07 ...
    
    Change of 17.27 against 100.00 
    Seems to have converged at iteration 513 / 1024 with tolerance 1.08e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=447.16 ...
    
    Change of -7.46 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=448.25 ...
    
    Change of -42.96 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=449.33 ...
    
    Change of 753.59 against 100.00 
    Seems to have converged at iteration 516 / 1024 with tolerance 2.31e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=450.42 ...
    
    Change of 2085.60 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=451.50 ...
    
    Change of 2331.64 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=452.59 ...
    
    Change of 2772.83 against 100.00 
    Seems to have converged at iteration 519 / 1024 with tolerance 7.13e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=453.68 ...
    
    Change of 1657.77 against 100.00 
    Seems to have converged at iteration 520 / 1024 with tolerance 6.78e-06 
    :::::::::::::::::::::::
    Scanning at lag=454.76 ...
    
    Change of 0.16 against 100.00 
    Seems to have converged at iteration 521 / 1024 with tolerance 2.84e-05 
    :::::::::::::::::::::::
    Scanning at lag=455.85 ...
    
    Change of 39.60 against 100.00 
    Seems to have converged at iteration 522 / 1024 with tolerance 1.64e-05 
    :::::::::::::::::::::::
    Scanning at lag=456.93 ...
    
    Change of -0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=458.02 ...
    
    Change of 14.32 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=459.11 ...
    
    Change of 12.57 against 100.00 
    Seems to have converged at iteration 525 / 1024 with tolerance 2.56e-05 
    :::::::::::::::::::::::
    Scanning at lag=460.19 ...
    
    Change of -1.69 against 100.00 
    Seems to have converged at iteration 526 / 1024 with tolerance 3.52e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=461.28 ...
    
    Change of 2062.58 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=462.37 ...
    
    Change of 1212.79 against 100.00 
    Seems to have converged at iteration 528 / 1024 with tolerance 3.77e-06 
    :::::::::::::::::::::::
    Scanning at lag=463.45 ...
    
    Change of 27.05 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=464.54 ...
    
    Change of -1.14 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=465.62 ...
    
    Change of 101.64 against 100.00 
    Seems to have converged at iteration 531 / 1024 with tolerance 2.98e-05 
    :::::::::::::::::::::::
    Scanning at lag=466.71 ...
    
    Change of -0.02 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=467.80 ...
    
    Change of 20.65 against 100.00 
    Seems to have converged at iteration 533 / 1024 with tolerance 4.86e+00 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=468.88 ...
    
    Change of 1106.66 against 100.00 
    Seems to have converged at iteration 534 / 1024 with tolerance 7.49e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=469.97 ...
    
    Change of 2090.45 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=471.05 ...
    
    Change of 3360.19 against 100.00 
    Seems to have converged at iteration 536 / 1024 with tolerance 1.49e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=472.14 ...
    
    Change of 512.49 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=473.23 ...
    
    Change of -755799.40 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=474.31 ...
    
    Change of 1568.30 against 100.00 
    Seems to have converged at iteration 539 / 1024 with tolerance 6.29e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=475.40 ...
    
    Change of 1732.07 against 100.00 
    Seems to have converged at iteration 540 / 1024 with tolerance 4.19e-06 
    :::::::::::::::::::::::
    Scanning at lag=476.49 ...
    
    Change of 4.46 against 100.00 
    Seems to have converged at iteration 541 / 1024 with tolerance 1.46e-06 
    :::::::::::::::::::::::
    Scanning at lag=477.57 ...
    
    Change of -0.80 against 100.00 
    Seems to have converged at iteration 542 / 1024 with tolerance 5.58e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=478.66 ...
    
    Change of 10006.47 against 100.00 
    Seems to have converged at iteration 543 / 1024 with tolerance 2.42e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=479.74 ...
    
    Change of 2850.58 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=480.83 ...
    
    Change of 3972.68 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=481.92 ...
    
    Change of -0.93 against 100.00 
    Seems to have converged at iteration 546 / 1024 with tolerance 1.23e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=483.00 ...
    
    Change of -4.25 against 100.00 
    Seems to have converged at iteration 547 / 1024 with tolerance 1.73e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=484.09 ...
    
    Change of -0.09 against 100.00 
    Seems to have converged at iteration 548 / 1024 with tolerance 8.35e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=485.17 ...
    
    Change of -3.39 against 100.00 
    Seems to have converged at iteration 549 / 1024 with tolerance 6.27e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=486.26 ...
    
    Change of -26.94 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=487.35 ...
    
    Change of -211.64 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=488.43 ...
    
    Change of 1181.18 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=489.52 ...
    
    Change of -0.65 against 100.00 
    Seems to have converged at iteration 553 / 1024 with tolerance 5.08e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=490.60 ...
    
    Change of -0.52 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=491.69 ...
    
    Change of -0.10 against 100.00 
    Seems to have converged at iteration 555 / 1024 with tolerance 6.86e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=492.78 ...
    
    Change of -44.34 against 100.00 
    Seems to have converged at iteration 556 / 1024 with tolerance 2.12e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=493.86 ...
    
    Change of 4712.72 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=494.95 ...
    
    Change of -21856.96 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=496.04 ...
    
    Change of -20.80 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=497.12 ...
    
    Change of 806.08 against 100.00 
    Seems to have converged at iteration 560 / 1024 with tolerance 6.32e+00 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=498.21 ...
    
    Change of -9862436.21 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=499.29 ...
    
    Change of 836.38 against 100.00 
    Seems to have converged at iteration 562 / 1024 with tolerance 1.43e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=500.38 ...
    
    Change of 910.27 against 100.00 
    Seems to have converged at iteration 563 / 1024 with tolerance 6.13e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=501.47 ...
    
    Change of -3.80 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=502.55 ...
    
    Change of 1510.92 against 100.00 
    Seems to have converged at iteration 565 / 1024 with tolerance 4.99e+00 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=503.64 ...
    
    Change of 917.35 against 100.00 
    Seems to have converged at iteration 566 / 1024 with tolerance 1.88e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=504.72 ...
    
    Change of -0.40 against 100.00 
    Seems to have converged at iteration 567 / 1024 with tolerance 2.18e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=505.81 ...
    
    Change of -1.07 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=506.90 ...
    
    Change of 881.45 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=507.98 ...
    
    Change of -2.77 against 100.00 
    Seems to have converged at iteration 570 / 1024 with tolerance 3.11e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=509.07 ...
    
    Change of -13.76 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=510.16 ...
    
    Change of 206.96 against 100.00 
    Seems to have converged at iteration 572 / 1024 with tolerance 8.23e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=511.24 ...
    
    Change of 538.97 against 100.00 
    Seems to have converged at iteration 573 / 1024 with tolerance 2.40e+00 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=512.33 ...
    
    Change of -8.39 against 100.00 
    Seems to have converged at iteration 574 / 1024 with tolerance 1.50e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=513.41 ...
    
    Change of 289.65 against 100.00 
    Seems to have converged at iteration 575 / 1024 with tolerance 2.78e-05 
    :::::::::::::::::::::::
    Scanning at lag=514.50 ...
    
    Change of 0.11 against 100.00 
    Seems to have converged at iteration 576 / 1024 with tolerance 1.61e-05 
    :::::::::::::::::::::::
    Scanning at lag=515.59 ...
    
    Change of 2.35 against 100.00 
    Seems to have converged at iteration 577 / 1024 with tolerance 3.47e-05 
    :::::::::::::::::::::::
    Scanning at lag=516.67 ...
    
    Change of 3.28 against 100.00 
    Seems to have converged at iteration 578 / 1024 with tolerance 6.22e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=517.76 ...
    
    Change of 253.96 against 100.00 
    Seems to have converged at iteration 579 / 1024 with tolerance 2.89e-01 
    :::::::::::::::::::::::
    Scanning at lag=518.84 ...
    
    Change of 0.50 against 100.00 
    Seems to have converged at iteration 580 / 1024 with tolerance 6.51e-05 
    :::::::::::::::::::::::
    Scanning at lag=519.93 ...
    
    Change of 0.01 against 100.00 
    Seems to have converged at iteration 581 / 1024 with tolerance 1.81e-05 
    :::::::::::::::::::::::
    Scanning at lag=521.02 ...
    
    Change of 0.15 against 100.00 
    Seems to have converged at iteration 582 / 1024 with tolerance 2.21e-05 
    :::::::::::::::::::::::
    Scanning at lag=522.10 ...
    
    Change of 4.10 against 100.00 
    Seems to have converged at iteration 583 / 1024 with tolerance 6.16e-06 
    :::::::::::::::::::::::
    Scanning at lag=523.19 ...
    
    Change of 13.12 against 100.00 
    Seems to have converged at iteration 584 / 1024 with tolerance 2.17e-06 
    :::::::::::::::::::::::
    Scanning at lag=524.28 ...
    
    Change of 13.08 against 100.00 
    Seems to have converged at iteration 585 / 1024 with tolerance 7.91e-05 
    :::::::::::::::::::::::
    Scanning at lag=525.36 ...
    
    Change of 16.02 against 100.00 
    Seems to have converged at iteration 586 / 1024 with tolerance 1.05e-04 
    :::::::::::::::::::::::
    Scanning at lag=526.45 ...
    
    Change of 41.46 against 100.00 
    Seems to have converged at iteration 587 / 1024 with tolerance 6.08e-05 
    :::::::::::::::::::::::
    Scanning at lag=527.53 ...
    
    Change of 0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=528.62 ...
    
    Change of -0.22 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=529.71 ...
    
    Change of 397.12 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=530.79 ...
    
    Change of 24.92 against 100.00 
    Seems to have converged at iteration 591 / 1024 with tolerance 2.77e-05 
    :::::::::::::::::::::::
    Scanning at lag=531.88 ...
    
    Change of -0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=532.96 ...
    
    Change of -0.19 against 100.00 
    Seems to have converged at iteration 593 / 1024 with tolerance 5.95e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=534.05 ...
    
    Change of 508.74 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=535.14 ...
    
    Change of -0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=536.22 ...
    
    Change of -1.31 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=537.31 ...
    
    Change of -1.14 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=538.39 ...
    
    Change of -25.36 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=539.48 ...
    
    Change of -7.98 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=540.57 ...
    
    Change of -0.09 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=541.65 ...
    
    Change of -0.54 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=542.74 ...
    
    Change of -0.39 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=543.83 ...
    
    Change of -0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=544.91 ...
    
    Change of -0.68 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=546.00 ...
    
    Change of 1.98 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=547.08 ...
    
    Change of -0.48 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=548.17 ...
    
    Change of -1.06 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=549.26 ...
    
    Change of -0.67 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=550.34 ...
    
    Change of -3.23 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=551.43 ...
    
    Change of -0.18 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=552.51 ...
    
    Change of -2.72 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=553.60 ...
    
    Change of -2.69 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=554.69 ...
    
    Change of -6.24 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=555.77 ...
    
    Change of -4.28 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=556.86 ...
    
    Change of -14.91 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=557.95 ...
    
    Change of -24.61 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=559.03 ...
    
    Change of 21.61 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=560.12 ...
    
    Change of -4.51 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=561.20 ...
    
    Change of -9.13 against 100.00 
    Seems to have converged at iteration 619 / 1024 with tolerance 1.13e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=562.29 ...
    
    Change of -14.58 against 100.00 
    Seems to have converged at iteration 620 / 1024 with tolerance 3.45e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=563.38 ...
    
    Change of -2.73 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=564.46 ...
    
    Change of -21.27 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=565.55 ...
    
    Change of -3.33 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=566.63 ...
    
    Change of -4.63 against 100.00 
    Seems to have converged at iteration 624 / 1024 with tolerance 1.97e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=567.72 ...
    
    Change of -11.75 against 100.00 
    Seems to have converged at iteration 625 / 1024 with tolerance 2.24e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=568.81 ...
    
    Change of -3.43 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=569.89 ...
    
    Change of 11.96 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=570.98 ...
    
    Change of -0.64 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=572.06 ...
    
    Change of -2.32 against 100.00 
    Seems to have converged at iteration 629 / 1024 with tolerance 4.80e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=573.15 ...
    
    Change of -2.54 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=574.24 ...
    
    Change of -19.24 against 100.00 
    Seems to have converged at iteration 631 / 1024 with tolerance 5.24e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=575.32 ...
    
    Change of 2.69 against 100.00 
    Seems to have converged at iteration 632 / 1024 with tolerance 6.59e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=576.41 ...
    
    Change of -6.75 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=577.50 ...
    
    Change of -3.90 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=578.58 ...
    
    Change of -31.86 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=579.67 ...
    
    Change of -5.55 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=580.75 ...
    
    Change of -9.74 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=581.84 ...
    
    Change of -7.18 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=582.93 ...
    
    Change of -3.02 against 100.00 
    Seems to have converged at iteration 639 / 1024 with tolerance 3.31e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=584.01 ...
    
    Change of -1.20 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=585.10 ...
    
    Change of -0.33 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=586.18 ...
    
    Change of -2.60 against 100.00 
    Seems to have converged at iteration 642 / 1024 with tolerance 2.88e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=587.27 ...
    
    Change of -6.17 against 100.00 
    Seems to have converged at iteration 643 / 1024 with tolerance 1.30e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=588.36 ...
    
    Change of -58.64 against 100.00 
    Seems to have converged at iteration 644 / 1024 with tolerance 6.88e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=589.44 ...
    
    Change of 79.71 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=590.53 ...
    
    Change of -3.03 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=591.62 ...
    
    Change of -9.46 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=592.70 ...
    
    Change of -10.39 against 100.00 
    Seems to have converged at iteration 648 / 1024 with tolerance 8.37e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=593.79 ...
    
    Change of -31.43 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=594.87 ...
    
    Change of -129.20 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=595.96 ...
    
    Change of 2933.17 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=597.05 ...
    
    Change of 2460.53 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=598.13 ...
    
    Change of 21.52 against 100.00 
    Seems to have converged at iteration 653 / 1024 with tolerance 2.79e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=599.22 ...
    
    Change of 1645.25 against 100.00 
    Seems to have converged at iteration 654 / 1024 with tolerance 8.03e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=600.30 ...
    
    Change of -8.48 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=601.39 ...
    
    Change of -0.16 against 100.00 
    Seems to have converged at iteration 656 / 1024 with tolerance 9.64e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=602.48 ...
    
    Change of -0.27 against 100.00 
    Seems to have converged at iteration 657 / 1024 with tolerance 1.81e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=603.56 ...
    
    Change of -0.83 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=604.65 ...
    
    Change of -20.65 against 100.00 
    Seems to have converged at iteration 659 / 1024 with tolerance 2.04e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=605.73 ...
    
    Change of -24.32 against 100.00 
    Seems to have converged at iteration 660 / 1024 with tolerance 2.44e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=606.82 ...
    
    Change of -295.17 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=607.91 ...
    
    Change of -235.80 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=608.99 ...
    
    Change of -1.07 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=610.08 ...
    
    Change of -0.56 against 100.00 
    Seems to have converged at iteration 664 / 1024 with tolerance 3.97e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=611.17 ...
    
    Change of -2.27 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=612.25 ...
    
    Change of -8.51 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=613.34 ...
    
    Change of -12.55 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=614.42 ...
    
    Change of -5.77 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=615.51 ...
    
    Change of -4.04 against 100.00 
    Seems to have converged at iteration 669 / 1024 with tolerance 3.50e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=616.60 ...
    
    Change of -4.07 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=617.68 ...
    
    Change of -0.65 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=618.77 ...
    
    Change of -3.65 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=619.85 ...
    
    Change of -4.91 against 100.00 
    Seems to have converged at iteration 673 / 1024 with tolerance 3.24e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=620.94 ...
    
    Change of -6.81 against 100.00 
    Seems to have converged at iteration 674 / 1024 with tolerance 5.53e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=622.03 ...
    
    Change of -6.29 against 100.00 
    Seems to have converged at iteration 675 / 1024 with tolerance 2.31e+03 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=623.11 ...
    
    Change of -30.55 against 100.00 
    Seems to have converged at iteration 676 / 1024 with tolerance 6.35e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=624.20 ...
    
    Change of -2.99 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=625.29 ...
    
    Change of 3136.17 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=626.37 ...
    
    Change of -34.46 against 100.00 
    Seems to have converged at iteration 679 / 1024 with tolerance 1.56e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=627.46 ...
    
    Change of -72.27 against 100.00 
    Seems to have converged at iteration 680 / 1024 with tolerance 6.38e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=628.54 ...
    
    Change of 9712.18 against 100.00 
    Seems to have converged at iteration 681 / 1024 with tolerance 2.78e+06 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=629.63 ...
    
    Change of 16236.52 against 100.00 
    Seems to have converged at iteration 682 / 1024 with tolerance 1.41e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=630.72 ...
    
    Change of 4069.54 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=631.80 ...
    
    Change of -2.53 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=632.89 ...
    
    Change of 1021.52 against 100.00 
    Seems to have converged at iteration 685 / 1024 with tolerance 1.26e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=633.97 ...
    
    Change of 5623.92 against 100.00 
    Seems to have converged at iteration 686 / 1024 with tolerance 5.02e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=635.06 ...
    
    Change of 7281.75 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=636.15 ...
    
    Change of 7567.20 against 100.00 
    Seems to have converged at iteration 688 / 1024 with tolerance 1.48e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=637.23 ...
    
    Change of -11.42 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=638.32 ...
    
    Change of -8.63 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=639.40 ...
    
    Change of 6550.94 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=640.49 ...
    
    Change of -143.39 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=641.58 ...
    
    Change of -228.97 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=642.66 ...
    
    Change of 7777.78 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=643.75 ...
    
    Change of 0.30 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=644.84 ...
    
    Change of 1.25 against 100.00 
    Seems to have converged at iteration 696 / 1024 with tolerance 1.75e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=645.92 ...
    
    Change of -2.49 against 100.00 
    Seems to have converged at iteration 697 / 1024 with tolerance 2.67e+03 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=647.01 ...
    
    Change of -0.01 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=648.09 ...
    
    Change of -1.14 against 100.00 
    Seems to have converged at iteration 699 / 1024 with tolerance 6.28e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=649.18 ...
    
    Change of 1.06 against 100.00 
    Seems to have converged at iteration 700 / 1024 with tolerance 4.29e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=650.27 ...
    
    Change of -0.24 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=651.35 ...
    
    Change of -0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=652.44 ...
    
    Change of -0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=653.52 ...
    
    Change of -0.01 against 100.00 
    Seems to have converged at iteration 704 / 1024 with tolerance 4.58e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=654.61 ...
    
    Change of 0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=655.70 ...
    
    Change of -0.00 against 100.00 
    Seems to have converged at iteration 706 / 1024 with tolerance 5.50e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=656.78 ...
    
    Change of -0.04 against 100.00 
    Seems to have converged at iteration 707 / 1024 with tolerance 3.15e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=657.87 ...
    
    Change of -0.08 against 100.00 
    Seems to have converged at iteration 708 / 1024 with tolerance 1.54e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=658.96 ...
    
    Change of -0.06 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=660.04 ...
    
    Change of -0.03 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=661.13 ...
    
    Change of -0.55 against 100.00 
    Seems to have converged at iteration 711 / 1024 with tolerance 1.87e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=662.21 ...
    
    Change of 1.71 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=663.30 ...
    
    Change of -0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=664.39 ...
    
    Change of -0.08 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=665.47 ...
    
    Change of -0.58 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=666.56 ...
    
    Change of 38.73 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=667.64 ...
    
    Change of -2.25 against 100.00 
    Seems to have converged at iteration 717 / 1024 with tolerance 1.22e+03 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=668.73 ...
    
    Change of 10262.15 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=669.82 ...
    
    Change of 20.04 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=670.90 ...
    
    Change of 13.60 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=671.99 ...
    
    Change of -1.14 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=673.07 ...
    
    Change of -1.29 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=674.16 ...
    
    Change of 0.26 against 100.00 
    Seems to have converged at iteration 723 / 1024 with tolerance 3.87e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=675.25 ...
    
    Change of 7033.47 against 100.00 
    Seems to have converged at iteration 724 / 1024 with tolerance 1.54e+00 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=676.33 ...
    
    Change of 9086.53 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=677.42 ...
    
    Change of 14497.72 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=678.51 ...
    
    Change of -0.05 against 100.00 
    Seems to have converged at iteration 727 / 1024 with tolerance 2.42e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=679.59 ...
    
    Change of 0.26 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=680.68 ...
    
    Change of -0.04 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=681.76 ...
    
    Change of -0.01 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=682.85 ...
    
    Change of -0.07 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=683.94 ...
    
    Change of -0.42 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=685.02 ...
    
    Change of -3.32 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=686.11 ...
    
    Change of -0.16 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=687.19 ...
    
    Change of -0.03 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=688.28 ...
    
    Change of -0.12 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=689.37 ...
    
    Change of -14.74 against 100.00 
    Seems to have converged at iteration 737 / 1024 with tolerance 2.40e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=690.45 ...
    
    Change of -7.63 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=691.54 ...
    
    Change of -5.67 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=692.63 ...
    
    Change of -77.02 against 100.00 
    Seems to have converged at iteration 740 / 1024 with tolerance 8.84e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=693.71 ...
    
    Change of -32.96 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=694.80 ...
    
    Change of -46.93 against 100.00 
    Seems to have converged at iteration 742 / 1024 with tolerance 4.60e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=695.88 ...
    
    Change of -66.14 against 100.00 
    Seems to have converged at iteration 743 / 1024 with tolerance 7.17e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=696.97 ...
    
    Change of -55.27 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=698.06 ...
    
    Change of 9347.15 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=699.14 ...
    
    Change of -0.03 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=700.23 ...
    
    Change of -0.25 against 100.00 
    Seems to have converged at iteration 747 / 1024 with tolerance 1.81e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=701.31 ...
    
    Change of -2.86 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=702.40 ...
    
    Change of -0.05 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=703.49 ...
    
    Change of -0.01 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=704.57 ...
    
    Change of -0.06 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=705.66 ...
    
    Change of -0.42 against 100.00 
    Seems to have converged at iteration 752 / 1024 with tolerance 9.90e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=706.74 ...
    
    Change of -0.03 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=707.83 ...
    
    Change of -0.04 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=708.92 ...
    
    Change of -0.02 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=710.00 ...
    
    Change of -0.28 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=711.09 ...
    
    Change of -0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=712.18 ...
    
    Change of 0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=713.26 ...
    
    Change of -0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=714.35 ...
    
    Change of -0.59 against 100.00 
    Seems to have converged at iteration 760 / 1024 with tolerance 1.70e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=715.43 ...
    
    Change of -0.56 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=716.52 ...
    
    Change of -0.74 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=717.61 ...
    
    Change of -0.04 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=718.69 ...
    
    Change of -0.40 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=719.78 ...
    
    Change of -2.33 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=720.86 ...
    
    Change of -0.01 against 100.00 
    Seems to have converged at iteration 766 / 1024 with tolerance 5.77e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=721.95 ...
    
    Change of -0.24 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=723.04 ...
    
    Change of -0.30 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=724.12 ...
    
    Change of -0.36 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=725.21 ...
    
    Change of -0.41 against 100.00 
    Seems to have converged at iteration 770 / 1024 with tolerance 1.70e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=726.30 ...
    
    Change of -1.30 against 100.00 
    Seems to have converged at iteration 771 / 1024 with tolerance 8.95e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=727.38 ...
    
    Change of -0.49 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=728.47 ...
    
    Change of -0.37 against 100.00 
    Seems to have converged at iteration 773 / 1024 with tolerance 5.05e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=729.55 ...
    
    Change of -2.72 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=730.64 ...
    
    Change of -0.22 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=731.73 ...
    
    Change of -0.66 against 100.00 
    Seems to have converged at iteration 776 / 1024 with tolerance 2.22e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=732.81 ...
    
    Change of -0.46 against 100.00 
    Seems to have converged at iteration 777 / 1024 with tolerance 1.02e+03 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=733.90 ...
    
    Change of -0.09 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=734.98 ...
    
    Change of -0.89 against 100.00 
    Seems to have converged at iteration 779 / 1024 with tolerance 1.71e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=736.07 ...
    
    Change of -0.50 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=737.16 ...
    
    Change of -1.11 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=738.24 ...
    
    Change of -2.31 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=739.33 ...
    
    Change of -0.18 against 100.00 
    Seems to have converged at iteration 783 / 1024 with tolerance 3.15e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=740.41 ...
    
    Change of -1.03 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=741.50 ...
    
    Change of -0.33 against 100.00 
    Seems to have converged at iteration 785 / 1024 with tolerance 4.57e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=742.59 ...
    
    Change of -0.82 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=743.67 ...
    
    Change of -0.37 against 100.00 
    Seems to have converged at iteration 787 / 1024 with tolerance 5.39e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=744.76 ...
    
    Change of -0.35 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=745.85 ...
    
    Change of -0.06 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=746.93 ...
    
    Change of 0.17 against 100.00 
    Seems to have converged at iteration 790 / 1024 with tolerance 4.89e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=748.02 ...
    
    Change of -2.35 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=749.10 ...
    
    Change of -0.06 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=750.19 ...
    
    Change of -2.02 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=751.28 ...
    
    Change of -0.82 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=752.36 ...
    
    Change of 2.24 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=753.45 ...
    
    Change of -0.11 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=754.53 ...
    
    Change of -0.04 against 100.00 
    Seems to have converged at iteration 797 / 1024 with tolerance 2.82e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=755.62 ...
    
    Change of -0.06 against 100.00 
    Seems to have converged at iteration 798 / 1024 with tolerance 1.59e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=756.71 ...
    
    Change of -0.15 against 100.00 
    Seems to have converged at iteration 799 / 1024 with tolerance 4.63e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=757.79 ...
    
    Change of -0.08 against 100.00 
    Seems to have converged at iteration 800 / 1024 with tolerance 8.58e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=758.88 ...
    
    Change of -0.26 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=759.97 ...
    
    Change of -0.31 against 100.00 
    Seems to have converged at iteration 802 / 1024 with tolerance 4.30e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=761.05 ...
    
    Change of -1.80 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=762.14 ...
    
    Change of -1.52 against 100.00 
    Seems to have converged at iteration 804 / 1024 with tolerance 6.67e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=763.22 ...
    
    Change of -0.78 against 100.00 
    Seems to have converged at iteration 805 / 1024 with tolerance 7.07e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=764.31 ...
    
    Change of -0.81 against 100.00 
    Seems to have converged at iteration 806 / 1024 with tolerance 5.85e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=765.40 ...
    
    Change of -0.38 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=766.48 ...
    
    Change of -0.51 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=767.57 ...
    
    Change of -0.98 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=768.65 ...
    
    Change of -0.69 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=769.74 ...
    
    Change of -0.35 against 100.00 
    Seems to have converged at iteration 811 / 1024 with tolerance 6.82e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=770.83 ...
    
    Change of -2.11 against 100.00 
    Seems to have converged at iteration 812 / 1024 with tolerance 1.28e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=771.91 ...
    
    Change of -0.82 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=773.00 ...
    
    Change of -2.52 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=774.08 ...
    
    Change of -1.38 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=775.17 ...
    
    Change of -0.38 against 100.00 
    Seems to have converged at iteration 816 / 1024 with tolerance 2.45e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=776.26 ...
    
    Change of -2.29 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=777.34 ...
    
    Change of -0.42 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=778.43 ...
    
    Change of -2.68 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=779.52 ...
    
    Change of -0.54 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=780.60 ...
    
    Change of -0.44 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=781.69 ...
    
    Change of -4.22 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=782.77 ...
    
    Change of 3.34 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=783.86 ...
    
    Change of -18.41 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=784.95 ...
    
    Change of -0.35 against 100.00 
    Seems to have converged at iteration 825 / 1024 with tolerance 1.20e+03 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=786.03 ...
    
    Change of -3.05 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=787.12 ...
    
    Change of -0.48 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=788.20 ...
    
    Change of -5.57 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=789.29 ...
    
    Change of -1.21 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=790.38 ...
    
    Change of -0.37 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=791.46 ...
    
    Change of 0.03 against 100.00 
    Seems to have converged at iteration 831 / 1024 with tolerance 4.30e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=792.55 ...
    
    Change of -0.32 against 100.00 
    Seems to have converged at iteration 832 / 1024 with tolerance 3.27e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=793.64 ...
    
    Change of -0.47 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=794.72 ...
    
    Change of -3.61 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=795.81 ...
    
    Change of -0.86 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=796.89 ...
    
    Change of -1.64 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=797.98 ...
    
    Change of -3.88 against 100.00 
    Seems to have converged at iteration 837 / 1024 with tolerance 2.89e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=799.07 ...
    
    Change of -4.85 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=800.15 ...
    
    Change of -2.17 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=801.24 ...
    
    Change of -2.20 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=802.32 ...
    
    Change of -1.85 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=803.41 ...
    
    Change of -8.02 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=804.50 ...
    
    Change of -0.23 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=805.58 ...
    
    Change of -0.20 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=806.67 ...
    
    Change of -1.14 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=807.75 ...
    
    Change of -0.38 against 100.00 
    Seems to have converged at iteration 846 / 1024 with tolerance 2.27e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=808.84 ...
    
    Change of -0.89 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=809.93 ...
    
    Change of -0.72 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=811.01 ...
    
    Change of -0.33 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=812.10 ...
    
    Change of -1.47 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=813.19 ...
    
    Change of -0.34 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=814.27 ...
    
    Change of -0.42 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=815.36 ...
    
    Change of -0.95 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=816.44 ...
    
    Change of -0.31 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=817.53 ...
    
    Change of -0.37 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=818.62 ...
    
    Change of -1.57 against 100.00 
    Seems to have converged at iteration 856 / 1024 with tolerance 2.63e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=819.70 ...
    
    Change of -0.35 against 100.00 
    Seems to have converged at iteration 857 / 1024 with tolerance 8.49e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=820.79 ...
    
    Change of -0.24 against 100.00 
    Seems to have converged at iteration 858 / 1024 with tolerance 1.21e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=821.87 ...
    
    Change of -0.37 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=822.96 ...
    
    Change of -0.47 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=824.05 ...
    
    Change of -0.17 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=825.13 ...
    
    Change of -0.69 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=826.22 ...
    
    Change of -0.46 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=827.31 ...
    
    Change of -1.87 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=828.39 ...
    
    Change of -0.36 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=829.48 ...
    
    Change of -0.42 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=830.56 ...
    
    Change of -0.46 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=831.65 ...
    
    Change of -0.47 against 100.00 
    Seems to have converged at iteration 868 / 1024 with tolerance 6.47e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=832.74 ...
    
    Change of -0.60 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=833.82 ...
    
    Change of -2.79 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=834.91 ...
    
    Change of -0.45 against 100.00 
    Seems to have converged at iteration 871 / 1024 with tolerance 2.38e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=835.99 ...
    
    Change of -0.28 against 100.00 
    Seems to have converged at iteration 872 / 1024 with tolerance 2.95e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=837.08 ...
    
    Change of -0.20 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=838.17 ...
    
    Change of -0.11 against 100.00 
    Seems to have converged at iteration 874 / 1024 with tolerance 3.11e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=839.25 ...
    
    Change of -0.46 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=840.34 ...
    
    Change of -2.05 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=841.43 ...
    
    Change of -0.45 against 100.00 
    Seems to have converged at iteration 877 / 1024 with tolerance 1.74e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=842.51 ...
    
    Change of -0.32 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=843.60 ...
    
    Change of -0.63 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=844.68 ...
    
    Change of -0.98 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=845.77 ...
    
    Change of -1.08 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=846.86 ...
    
    Change of -0.95 against 100.00 
    Seems to have converged at iteration 882 / 1024 with tolerance 2.28e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=847.94 ...
    
    Change of 130.80 against 100.00 
    Seems to have converged at iteration 883 / 1024 with tolerance 4.47e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=849.03 ...
    
    Change of 247.26 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=850.11 ...
    
    Change of -0.04 against 100.00 
    Seems to have converged at iteration 885 / 1024 with tolerance 1.00e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=851.20 ...
    
    Change of -0.11 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=852.29 ...
    
    Change of 5594.53 against 100.00 
    Seems to have converged at iteration 887 / 1024 with tolerance 2.74e+00 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=853.37 ...
    
    Change of 4664.76 against 100.00 
    Seems to have converged at iteration 888 / 1024 with tolerance 9.92e+03 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=854.46 ...
    
    Change of 1985.18 against 100.00 
    Seems to have converged at iteration 889 / 1024 with tolerance 4.06e+00 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=855.54 ...
    
    Change of -15.40 against 100.00 
    Seems to have converged at iteration 890 / 1024 with tolerance 1.21e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=856.63 ...
    
    Change of 1315.59 against 100.00 
    Seems to have converged at iteration 891 / 1024 with tolerance 6.28e+00 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=857.72 ...
    
    Change of 1119.45 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=858.80 ...
    
    Change of 2.29 against 100.00 
    Seems to have converged at iteration 893 / 1024 with tolerance 2.81e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=859.89 ...
    
    Change of -0.33 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=860.98 ...
    
    Change of -0.28 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=862.06 ...
    
    Change of -2.80 against 100.00 
    Seems to have converged at iteration 896 / 1024 with tolerance 3.49e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=863.15 ...
    
    Change of -0.34 against 100.00 
    Seems to have converged at iteration 897 / 1024 with tolerance 1.09e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=864.23 ...
    
    Change of -0.22 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=865.32 ...
    
    Change of -0.01 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=866.41 ...
    
    Change of -0.12 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=867.49 ...
    
    Change of -0.06 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=868.58 ...
    
    Change of -0.35 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=869.66 ...
    
    Change of -0.38 against 100.00 
    Seems to have converged at iteration 903 / 1024 with tolerance 6.69e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=870.75 ...
    
    Change of -0.20 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=871.84 ...
    
    Change of -0.12 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=872.92 ...
    
    Change of -0.30 against 100.00 
    Seems to have converged at iteration 906 / 1024 with tolerance 4.63e+02 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=874.01 ...
    
    Change of -0.73 against 100.00 
    Seems to have converged at iteration 907 / 1024 with tolerance 8.18e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=875.10 ...
    
    Change of -0.62 against 100.00 
    Seems to have converged at iteration 908 / 1024 with tolerance 4.25e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=876.18 ...
    
    Change of -0.62 against 100.00 
    Seems to have converged at iteration 909 / 1024 with tolerance 1.55e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=877.27 ...
    
    Change of -1.48 against 100.00 
    Seems to have converged at iteration 910 / 1024 with tolerance 3.54e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=878.35 ...
    
    Change of -0.70 against 100.00 
    Seems to have converged at iteration 911 / 1024 with tolerance 1.84e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=879.44 ...
    
    Change of -2.29 against 100.00 
    Seems to have converged at iteration 912 / 1024 with tolerance 1.05e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=880.53 ...
    
    Change of -0.59 against 100.00 
    Seems to have converged at iteration 913 / 1024 with tolerance 3.34e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=881.61 ...
    
    Change of -0.61 against 100.00 
    Seems to have converged at iteration 914 / 1024 with tolerance 4.11e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=882.70 ...
    
    Change of -0.80 against 100.00 
    Seems to have converged at iteration 915 / 1024 with tolerance 5.33e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=883.78 ...
    
    Change of 620.90 against 100.00 
    Seems to have converged at iteration 916 / 1024 with tolerance 5.38e-01 
    :::::::::::::::::::::::
    Scanning at lag=884.87 ...
    
    Change of 0.68 against 100.00 
    Seems to have converged at iteration 917 / 1024 with tolerance 1.61e-04 
    :::::::::::::::::::::::
    Scanning at lag=885.96 ...
    
    Change of 0.13 against 100.00 
    Seems to have converged at iteration 918 / 1024 with tolerance 2.13e-05 
    :::::::::::::::::::::::
    Scanning at lag=887.04 ...
    
    Change of 0.01 against 100.00 
    Seems to have converged at iteration 919 / 1024 with tolerance 1.14e-04 
    :::::::::::::::::::::::
    Scanning at lag=888.13 ...
    
    Change of 0.03 against 100.00 
    Seems to have converged at iteration 920 / 1024 with tolerance 1.13e-04 
    :::::::::::::::::::::::
    Scanning at lag=889.21 ...
    
    Change of -0.00 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=890.30 ...
    
    Change of 0.02 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=891.39 ...
    
    Change of -0.01 against 100.00 
    Seems to have converged at iteration 923 / 1024 with tolerance 4.71e+01 
    Possibly stuck in a furrow. Resetting start params 
    :::::::::::::::::::::::
    Scanning at lag=892.47 ...
    
    Change of -0.03 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=893.56 ...
    
    Change of 463.21 against 100.00 
    Eval:	True 
    Hessian / Tol:	True 
    Evidence Calc:	False 
    :::::::::::::::::::::::
    Scanning at lag=894.65 ...
    
    Change of -10057435.39 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=895.73 ...
    
    Change of -10065512.13 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=896.82 ...
    
    Change of -10127776.80 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=897.90 ...
    
    Change of -10065073.52 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=898.99 ...
    
    Change of -10130330.59 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=900.08 ...
    
    Change of -10075688.49 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=901.16 ...
    
    Change of -10084899.35 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=902.25 ...
    
    Change of -10148249.91 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=903.33 ...
    
    Change of -10062385.37 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=904.42 ...
    
    Change of -10054619.45 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=905.51 ...
    
    Change of -10060821.14 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=906.59 ...
    
    Change of -10327328.99 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=907.68 ...
    
    Change of -10068053.22 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=908.77 ...
    
    Change of -10058920.75 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=909.85 ...
    
    Change of -10330274.92 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=910.94 ...
    
    Change of -10058189.59 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=912.02 ...
    
    Change of -10055295.98 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=913.11 ...
    
    Change of -10087217.90 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=914.20 ...
    
    Change of -10103278.41 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=915.28 ...
    
    Change of -10072092.49 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=916.37 ...
    
    Change of -10083417.87 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=917.45 ...
    
    Change of -10071387.74 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=918.54 ...
    
    Change of -10059737.87 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=919.63 ...
    
    Change of -10260902.43 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=920.71 ...
    
    Change of -10057576.11 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=921.80 ...
    
    Change of -10153496.20 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=922.88 ...
    
    Change of -10235885.81 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=923.97 ...
    
    Change of -10677812.74 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=925.06 ...
    
    Change of -10063383.11 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=926.14 ...
    
    Change of -10053029.35 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=927.23 ...
    
    Change of -10053157.25 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=928.32 ...
    
    Change of -10081908.32 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=929.40 ...
    
    Change of -10129733.46 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=930.49 ...
    
    Change of -10414966.74 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=931.57 ...
    
    Change of -10071275.38 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=932.66 ...
    
    Change of -10087622.64 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=933.75 ...
    
    Change of -10056949.65 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=934.83 ...
    
    Change of -10193558.25 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=935.92 ...
    
    Change of -10120698.31 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=937.00 ...
    
    Change of -10120624.68 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=938.09 ...
    
    Change of -10808911.19 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=939.18 ...
    
    Change of -10054166.93 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=940.26 ...
    
    Change of -10051361.00 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=941.35 ...
    
    Change of -10130874.77 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=942.44 ...
    
    Change of -10096055.32 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=943.52 ...
    
    Change of -10055091.59 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=944.61 ...
    
    Change of -10840319.47 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=945.69 ...
    
    Change of -10081413.10 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=946.78 ...
    
    Change of -10074906.09 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=947.87 ...
    
    Change of -10054701.23 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=948.95 ...
    
    Change of -10254599.10 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=950.04 ...
    
    Change of -10117059.34 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=951.12 ...
    
    Change of -10063691.40 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=952.21 ...
    
    Change of -10052629.66 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=953.30 ...
    
    Change of -10134087.03 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=954.38 ...
    
    Change of -10095224.47 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=955.47 ...
    
    Change of -10223164.46 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=956.55 ...
    
    Change of -10178618.34 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=957.64 ...
    
    Change of -10054737.92 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=958.73 ...
    
    Change of -10381860.04 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=959.81 ...
    
    Change of -10054746.40 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=960.90 ...
    
    Change of -10119385.63 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=961.99 ...
    
    Change of -10087229.50 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=963.07 ...
    
    Change of -10128415.43 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=964.16 ...
    
    Change of -11216443.11 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=965.24 ...
    
    Change of -10069040.97 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=966.33 ...
    
    Change of -10053702.11 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=967.42 ...
    
    Change of -10226078.61 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=968.50 ...
    
    Change of -10066705.06 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=969.59 ...
    
    Change of -10724041.98 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=970.67 ...
    
    Change of -10089436.64 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=971.76 ...
    
    Change of -10092063.31 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=972.85 ...
    
    Change of -10420316.73 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=973.93 ...
    
    Change of -10090931.53 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=975.02 ...
    
    Change of -10068462.47 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=976.11 ...
    
    Change of -10590240.54 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=977.19 ...
    
    Change of -10139912.71 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=978.28 ...
    
    Change of -10049608.29 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=979.36 ...
    
    Change of -10058649.05 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=980.45 ...
    
    Change of -10111880.64 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=981.54 ...
    
    Change of -10103205.75 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=982.62 ...
    
    Change of -10118836.42 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=983.71 ...
    
    Change of -10101740.72 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=984.79 ...
    
    Change of -10806225.73 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=985.88 ...
    
    Change of -10337006.61 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=986.97 ...
    
    Change of -10401636.02 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=988.05 ...
    
    Change of -10175587.85 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=989.14 ...
    
    Change of -10072405.84 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=990.22 ...
    
    Change of -10197297.43 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=991.31 ...
    
    Change of -10298918.26 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=992.40 ...
    
    Change of -10048024.40 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=993.48 ...
    
    Change of -10307210.42 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=994.57 ...
    
    Change of -10152881.97 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=995.66 ...
    
    Change of -12258492.43 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=996.74 ...
    
    Change of -10055418.69 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=997.83 ...
    
    Change of -10421737.62 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=998.91 ...
    
    Change of -10274187.15 against 100.00 
    :::::::::::::::::::::::
    Scanning at lag=1000.00 ...
    
    Change of -10175596.15 against 100.00 
    Scanning Complete. Calculating laplace integrals... 
    Hessian Scan Fitting complete.
    -----------------------
    -----------------------
    
    Doing re-fitting of 220 lags 
    :::::::::::::::::::::::
    Refitting lag 0/220 at lag 168.35
    
    Settled at new tol 1.56e-04 
    :::::::::::::::::::::::
    Refitting lag 1/220 at lag 167.26
    
    Settled at new tol 3.60e-04 
    :::::::::::::::::::::::
    Refitting lag 2/220 at lag 166.18
    
    Settled at new tol 5.91e-04 
    :::::::::::::::::::::::
    Refitting lag 3/220 at lag 164.01
    
    Settled at new tol 8.74e-04 
    :::::::::::::::::::::::
    Refitting lag 4/220 at lag 144.46
    
    Settled at new tol 3.18e-03 
    :::::::::::::::::::::::
    Refitting lag 5/220 at lag 136.85
    
    Settled at new tol 5.73e-04 
    :::::::::::::::::::::::
    Refitting lag 6/220 at lag 129.25
    
    Settled at new tol 6.90e-04 
    :::::::::::::::::::::::
    Refitting lag 7/220 at lag 122.73
    
    Settled at new tol 1.41e-03 
    :::::::::::::::::::::::
    Refitting lag 8/220 at lag 121.65
    
    Optimization failed on 8/220 
    :::::::::::::::::::::::
    Refitting lag 9/220 at lag 112.96
    
    Settled at new tol 2.64e-03 
    :::::::::::::::::::::::
    Refitting lag 10/220 at lag 106.44
    
    Settled at new tol 2.08e-05 
    :::::::::::::::::::::::
    Refitting lag 11/220 at lag 105.35
    
    Settled at new tol 2.97e-04 
    :::::::::::::::::::::::
    Refitting lag 12/220 at lag 104.27
    
    Settled at new tol 8.40e-05 
    :::::::::::::::::::::::
    Refitting lag 13/220 at lag 103.18
    
    Optimization failed on 13/220 
    :::::::::::::::::::::::
    Refitting lag 14/220 at lag 99.92
    
    Settled at new tol 2.88e-04 
    :::::::::::::::::::::::
    Refitting lag 15/220 at lag 98.84
    
    Settled at new tol 3.70e-04 
    :::::::::::::::::::::::
    Refitting lag 16/220 at lag 94.49
    
    Settled at new tol 1.48e-04 
    :::::::::::::::::::::::
    Refitting lag 17/220 at lag 93.41
    
    Settled at new tol 6.84e-04 
    :::::::::::::::::::::::
    Refitting lag 18/220 at lag 92.32
    
    Settled at new tol 1.98e-03 
    :::::::::::::::::::::::
    Refitting lag 19/220 at lag 91.23
    
    Settled at new tol 3.46e-05 
    :::::::::::::::::::::::
    Refitting lag 20/220 at lag 90.15
    
    Settled at new tol 3.69e-03 
    :::::::::::::::::::::::
    Refitting lag 21/220 at lag 89.06
    
    Settled at new tol 4.00e-03 
    :::::::::::::::::::::::
    Refitting lag 22/220 at lag 87.98
    
    Settled at new tol 1.12e-03 
    :::::::::::::::::::::::
    Refitting lag 23/220 at lag 86.89
    
    Settled at new tol 3.42e-03 
    :::::::::::::::::::::::
    Refitting lag 24/220 at lag 85.80
    
    Settled at new tol 3.04e-03 
    :::::::::::::::::::::::
    Refitting lag 25/220 at lag 84.72
    
    Settled at new tol 1.07e-03 
    :::::::::::::::::::::::
    Refitting lag 26/220 at lag 83.63
    
    Settled at new tol 9.75e-04 
    :::::::::::::::::::::::
    Refitting lag 27/220 at lag 82.55
    
    Settled at new tol 7.84e-04 
    :::::::::::::::::::::::
    Refitting lag 28/220 at lag 81.46
    
    Settled at new tol 2.37e-03 
    :::::::::::::::::::::::
    Refitting lag 29/220 at lag 80.37
    
    New peak bad (LL from -5.11e+02 to -5.11e+02. Trying new start location & Simpler Solver 



    ---------------------------------------------------------------------------

    TypeError                                 Traceback (most recent call last)

    Cell In[22], line 9
          1 fitter = litmus.fitting_methods.hessian_scan(model_1, precondition="diag",
          2                                              verbose=4, debug=False, warn=False,
          3                                              Nlags=1024,
       (...)
          6                                              optimizer_args={"maxiter": 128, "increase_factor": 1.2}
          7                                              )
          8 fitter.fit(*mock.lcs())
    ----> 9 fitter.refit(*mock.lcs())


    File /mnt/c/Work/litmus/litmus/fitting_methods.py:1440, in hessian_scan.refit(self, lc_1, lc_2, seed)
       1436 if ll_old > ll_new or np.isnan(ll_new) or np.isinf(ll_new):
       1437     self.msg_run(
       1438         "New peak bad (LL from %.2e to %.2e. Trying new start location & Simpler Solver" % (ll_old, ll_new),
       1439         lvl=2)
    -> 1440     new_peak = self.stat_model.scan(start_params=self.estmap_params,
       1441                                     optim_params=self.params_toscan,
       1442                                     data=data,
       1443                                     optim_kwargs=self.optimizer_args,
       1444                                     precondition=self.precondition,
       1445                                     solver="GradientDescent"
       1446                                     )
       1447     ll_new = self.stat_model.log_density(new_peak, data)
       1449 new_peak_uncon = self.stat_model.to_uncon(new_peak)


    File /mnt/c/Work/litmus/litmus/models.py:942, in stats_model.scan(self, start_params, data, optim_params, use_vmap, optim_kwargs, precondition, solver)
        934 # =====================
        935 # Jaxopt Work
        936 
        937 # Build the optimizer
        938 if solver == "BFGS":
        939     solver = jaxopt.BFGS(fun=optfunc,
        940                          value_and_grad=False,
        941                          jit=True,
    --> 942                          **optimizer_args
        943                          )
        944 elif solver == "GradientDescent":
        945     solver = jaxopt.GradientDescent(fun=optfunc,
        946                                     value_and_grad=False,
        947                                     jit=True,
        948                                     **optimizer_args
        949                                     )


    TypeError: GradientDescent.__init__() got an unexpected keyword argument 'increase_factor'


Checking the fitter's diagnostic plot, we see that it's got a lot of poorly converged lags, but that the properly converged ones now span the $100-300 \; \mathrm{d}$ range: 


```python
fitter_brute.diagnostics(show=False)
plt.show()
```


    
![png](output_19_0.png)
    


Because we've searched the lag-prior near exhaustively, we've picked up the true lag peak _as well_ as the false positive from earlier. This comes at the cost of taking about $2-3$ times longer to run than our ICCF combination run, but also gives us a really high precision estimate of the evidence as we've mapped out a giant chunk of the posterior.


```python
fitter_brute.diagnostic_lagplot(show=False)
plt.show()
```


    
![png](output_21_0.png)
    



```python
lt = LITMUS(fitter_brute)
lt.lag_plot(show=False)
plt.show()
```

## A More Elegant Solution - Manually Specifying Test Lags with ICCF

By default, `LITMUS` uses it's grid smoothing algorithm to select test lags for you, but you can over-ride this with whatever lags you so desire. All we need is some way of knowing what lags to direct our attention towards. Fortunately we have one on hand already: the frequentist ICCF method, happily already included in `LITMUS`'s available fitting methods.

We create an ICCF sampler and fire it off:


```python
fitter_ICCF = fitting_methods.ICCF(model_1, verbose=False, debug=False, Nboot=1024)
fitter_ICCF.fit(mock.lc_1, mock.lc_2)
```

Checking the results of this sampler, we can see that it is still preferring shorter lags of $\approx 200 \; \mathrm{d}$, but its vagueness means that it broadly captures the true lag of $256 \; \mathrm{d}$:


```python
plt.hist(fitter_ICCF.get_samples()["lag"], bins=24, color='royalblue', alpha=0.5)
plt.axvline(mock.lag, ls='--', color='lightsalmon', label="True")
plt.axvline(fitter_ICCF.get_peaks()["lag"], ls='--', color='orchid', label="ICCF Est Peak")
plt.legend()
plt.xlabel("Lag $\Delta t$, days")
plt.ylabel("ICCF Bootstrap Meak Correlation Density")
plt.tight_layout()
plt.show()
```


    
![png](output_26_0.png)
    


Now we can grab our test lags _from_ the ICCF using `fitter_ICCF.get_samples()`, and then feed them into a new `hessian_scan` with the `test_lags` fitting parameter. Let's go with the same number of lags as our original run to keep things fair and fire it off:


```python
test_lags = fitter_ICCF.get_samples(fitter.Nlags)["lag"]
fitter_testlags = litmus.fitting_methods.hessian_scan(model_1, precondition="diag",
                                               verbose=False, debug=False, warn=0,
                                               Nlags=fitter.Nlags,
                                               init_samples=10_000,
                                               optimizer_args={"maxiter": 256, "increase_factor": 1.2},
                                               test_lags=test_lags
                                               )
fitter_testlags.fit(mock.lc_1, mock.lc_2)
fitter_testlags.refit(mock.lc_1, mock.lc_2)
```

As usual, check to make sure this has actually converged:


```python
fitter_testlags.diagnostics(show=False)
plt.show()
```


    
![png](output_30_0.png)
    


And then, checking the parameters we recovered, we find that we're bang-on the true underlying parameters!


```python
lt = LITMUS(fitter_testlags)
lt.plot_parameters(truth=mock.params(), prior_extents=False, show=False)
plt.show()
```

    Warning! LITMUS object built on pre-run fitting_procedure. May have unexpected behaviour. 

    


    WARNING:chainconsumer:Parameter lag in chain Lightcurves %i-%i is not constrained



    
![png](output_32_3.png)
    


Including the time taken to run the ICCF fit, this is markedly faster than the brute force approach of testing more lags.

## When to be Worried
In this example we've seen that `LITMUS` can sometimes fail _under its default settings_ in some edge cases. As end users, how we do know when to be worried in the real world? Well there's a few warning signs we should look for to at lease raise our curiosity, if not concern:

1. Is the constrained lag really narrow? This tells us it's a high SNR signal and might be subject to these sorts of issues.
2. Is the lag at or near an aliasing lag? (In reverberation mapping that's half-yearly lags, e.g. $180, \; 540 \; \mathrm{d}$ etc.
3. If we do a plot of the conditional posterior, is the main peak located on a broad platuea that might contain other modes?

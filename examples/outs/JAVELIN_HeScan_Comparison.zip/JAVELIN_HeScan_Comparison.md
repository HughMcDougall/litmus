# JAVELIN Hessian Scan Comparison

In this example we use 
To begin, we'll import all the relevant modules:


```python
from litmus import *
from litmus._utils import dict_extend
```

    An NVIDIA GPU may be present on this machine, but a CUDA-enabled jaxlib is not installed. Falling back to cpu.


Now we'll use the `litmus.mocks` module to generate some mock data:


```python
mock = mocks.mock(lag=180, cadende=[10, 30], E=[0.15, 0.25], tau=200)
mock = mock(10)
lc_1, lc_2 = mock.lc_1, mock.lc_2
mock.plot(show=True)
plt.show()
```


    
![png](output_3_0.png)
    


Now we create a stats model (specifically `models.GP_simple`, which models the response as an un-smoothed damped random walk), and set our prior ranges. In this case we'll numerical costs low by assuming we already know the signal mean's and relative amplitudes.


```python
model = models.GP_simple()
model.set_priors({
    'lag': [0, 800],
    'mean': [0.0, 0.0],
    'rel_mean': [0.0, 0.0],
    'rel_amp': [1.00, 1.00],
})
```

To get an idea of _why_ aliasing happens, let's use `model` to evaluate the log-density in a slice over the lag prior with the other parameters fixed. Notice the multimodal behaviour within the (highlighted) aliasing seasons?


```python
# Turn lightcurves into model-friendly data
data = model.lc_to_data(lc_1, lc_2)

# Set up a span of lags and calculate the model log-density conditioned on the data
lagplot = np.linspace(*model.prior_ranges['lag'], 1024)
LLs = model.log_density(dict_extend(mock.params(), {'lag': lagplot}), data)

# Plot likelihood and true lag
plt.figure(figsize=(8,4))
plt.plot(lagplot, (LLs - LLs.max()))
plt.axvline(mock.lag, ls='--', c='k')

# Highlight seasons
if mock.season != 0:
    tmax = model.prior_ranges['lag'][1]
    nyears = int(tmax // (mock.season * 2) + 1)
    for i in range(nyears):
        plt.axvspan((i + 1 / 2 - 1 / 4) * mock.season * 2, (i + 1 - 1 / 4) * mock.season * 2,
                    ymin=0, ymax=1, alpha=0.25, color='royalblue',
                    zorder=-10,
                    label="Aliasing Seasons" if i == 0 else None)

plt.xlim(0, model.prior_ranges['lag'][1])
plt.xlabel("Lag $\Delta t$ (days)")
plt.ylabel("Log Density $\mathcal{L(\Delta t \\vert \phi)}\pi(\Delta t \\vert \phi)$")
plt.legend()
plt.show()
```

    INFO:matplotlib.mathtext:Substituting symbol L from STIXNonUnicode
    INFO:matplotlib.mathtext:Substituting symbol ( from STIXGeneral
    INFO:matplotlib.mathtext:Substituting symbol \Delta from STIXNonUnicode
    INFO:matplotlib.mathtext:Substituting symbol t from STIXGeneral
    INFO:matplotlib.mathtext:Substituting symbol \vert from STIXGeneral
    INFO:matplotlib.mathtext:Substituting symbol \phi from STIXNonUnicode
    INFO:matplotlib.mathtext:Substituting symbol ) from STIXGeneral
    INFO:matplotlib.mathtext:Substituting symbol L from STIXNonUnicode
    INFO:matplotlib.mathtext:Substituting symbol ( from STIXGeneral
    INFO:matplotlib.mathtext:Substituting symbol \Delta from STIXNonUnicode
    INFO:matplotlib.mathtext:Substituting symbol t from STIXGeneral
    INFO:matplotlib.mathtext:Substituting symbol \vert from STIXGeneral
    INFO:matplotlib.mathtext:Substituting symbol \phi from STIXNonUnicode
    INFO:matplotlib.mathtext:Substituting symbol ) from STIXGeneral



    
![png](output_7_1.png)
    


That's all the mocks and statistics set up, now we set up two fitting method. Firstly, `meth_1` will be a `JAVELIKE`, i.e. an implementation of the AEIS, while `meth_2` will be `LITMUS`'s very own Hessian Scan. I've set the `debug` flag to `False` for each method for the sake of brevity, which otherwise would give granular detail about their inner workings, while I've kept the `verbose` flag, which outputs key information about the run progress, set to true. 


```python
meth_1 = fitting_methods.JAVELIKE(model,
                                  verbose=True,
                                  debug=False,
                                  num_warmup=5_000,
                                  num_samples=100_000 // 512,
                                  num_chains=512
                                  )

meth_2 = fitting_methods.hessian_scan(model,
                                      verbose=True,
                                      debug=False,
                                      Nlags=64,
                                      precondition="half-eig",
                                      reverse=False
                                      )
```

Now we can run each method. We've already set the fitting procedures up, all that's required now is to run them! In this example I run `prefit()` and `fit()` seperately, though this is not strictly necessary.

I then load the fitting methods into a `LITMUS` object, which is a wrapper for generating nice fancy plots and data outputs. In this case, I save the chains with `save_chain` and generate the methods' respective lag posterior distributions with `lag_plot`:


```python
print("Plots!")
for meth, name in zip([meth_1, meth_2], ["javelin", 'hessian']):
    print(name)
    meth.prefit(lc_1, lc_2)
    meth.fit(lc_1, lc_2)

    lt = LITMUS(meth)
    lt.save_chain("./chain_%s.csv" % name)
    lt.lag_plot(dir="./lagplot_%s.pdf" % name)
```

    Plots!
    javelin
    Running warmup with 512 chains and 5000 samples 
    Running sampler with 512 chains and 195 samples 


    sample: 100%|██████████| 5195/5195 [05:12<00:00, 16.64it/s, acc. prob=0.30]
    Tried to get 99840 sub-samples from chain of 50000 total samples. Tried to get 99840 sub-samples from chain of 50000 total samples. Warning! LITMUS object built on pre-run fitting_procedure. May have unexpected behaviour. 

    
    
    


    WARNING:chainconsumer:Parameter lag in chain Lightcurves %i-%i is not constrained


    hessian
    In find seed, sample no 1090 is best /w LL -84.97 at lag 174.40 
    Beginning scan at constrained-space position: 
    	 lag: 	 174.40 
    	 logtau: 	 4.35 
    	 logamp: 	 -0.27 
    	 rel_amp: 	 1.00 
    	 mean: 	 0.00 
    	 rel_mean: 	 0.00 
    Log-Density for this is: -84.97 
    Moving non-lag params to new location... 
    Scaling matrix: [[-0.08400983  0.02249271]
     [-0.05213635 -0.03624359]] 
    Inverse Scaling matrix: [[ -8.59360859  -5.3331779 ]
     [ 12.36189132 -19.91931592]] 
    At initial uncon position [0. 0.] with keys ['logtau', 'logamp'] eval for optfunc is 78.7558114271342 
    Creating and testing solver... 
    Jaxopt solver created and running fine 
    At final uncon position [0.10575967 0.04010741] with keys ['logtau', 'logamp'] eval for optfunc is 74.83207513294602 
    Optimizer settled at new fit: 
    	 lag: 	 174.40 
    	 logtau: 	 5.26 
    	 logamp: 	 0.06 
    	 rel_amp: 	 1.00 
    	 mean: 	 0.00 
    	 rel_mean: 	 0.00 
    Log-Density for this is: -81.07 
    Finding a good lag... 
    Grid finds good lag at 174.57: 
    Log-Density for this is: -81.07 
    Scaling matrix: [[0.04247514]] 
    Inverse Scaling matrix: [[23.54318207]] 
    At initial uncon position [0.] with keys ['lag'] eval for optfunc is 74.83207513294602 
    Creating and testing solver... 
    Jaxopt solver created and running fine 
    At final uncon position [-1.27596929] with keys ['lag'] eval for optfunc is 74.83153223598852 
    Lag-only opt settled at new lag 174.59... 
    Optimizer settled at new fit: 
    	 lag: 	 174.59 
    	 logtau: 	 5.26 
    	 logamp: 	 0.06 
    	 rel_amp: 	 1.00 
    	 mean: 	 0.00 
    	 rel_mean: 	 0.00 
    Log-Density for this is: -81.07 
    Estimated to be within ±3.01e-03σ of local optimum 
    Starting Hessian Scan 
    Creating and testing solver... 


    Something wrong in creation of jaxopt solver 

    
    ::::::::::::::::::::::: 
    Scanning at lag=172.88 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    Change of -0.00 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(172.8783902, dtype=float64), 'logtau': Array(5.2589655, dtype=float64), 'logamp': Array(0.05846278, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(-1.28855208, dtype=float64), 'logtau': Array(0.10367897, dtype=float64), 'logamp': Array(0.03898012, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 10735.846171195137 
    And log height: -74.97... 
    log-evidence is ~-77.77 
    Seems to have converged at iteration 0 / 64 with tolerance 1.96e-09 
    ::::::::::::::::::::::: 
    Scanning at lag=185.68 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    Change of 0.01 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(185.6767904, dtype=float64), 'logtau': Array(5.29702689, dtype=float64), 'logamp': Array(0.07229294, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(-1.19651371, dtype=float64), 'logtau': Array(0.11895082, dtype=float64), 'logamp': Array(0.04820462, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 10412.176256909199 
    And log height: -78.02... 
    log-evidence is ~-80.81 
    Seems to have converged at iteration 1 / 64 with tolerance 5.46e-06 
    ::::::::::::::::::::::: 
    Scanning at lag=198.48 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    Change of 0.03 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(198.4751906, dtype=float64), 'logtau': Array(5.28225008, dtype=float64), 'logamp': Array(0.08573843, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(-1.10880367, dtype=float64), 'logtau': Array(0.11302019, dtype=float64), 'logamp': Array(0.05717452, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 10323.083091025614 
    And log height: -80.99... 
    log-evidence is ~-83.78 
    Seems to have converged at iteration 2 / 64 with tolerance 8.14e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=211.27 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    Change of 0.02 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(211.2735908, dtype=float64), 'logtau': Array(5.26725953, dtype=float64), 'logamp': Array(0.09673917, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(-1.02480764, dtype=float64), 'logtau': Array(0.1070058, dtype=float64), 'logamp': Array(0.06451514, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 9778.758743446904 
    And log height: -89.88... 
    log-evidence is ~-92.63 
    Seems to have converged at iteration 3 / 64 with tolerance 4.43e-06 
    ::::::::::::::::::::::: 
    Scanning at lag=224.07 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    22 
    23 
    24 
    25 
    Change of 0.04 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(224.071991, dtype=float64), 'logtau': Array(5.24827209, dtype=float64), 'logamp': Array(0.11015274, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(-0.94401528, dtype=float64), 'logtau': Array(0.09939057, dtype=float64), 'logamp': Array(0.07346819, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 9590.613353662335 
    And log height: -93.71... 
    log-evidence is ~-96.46 
    Seems to have converged at iteration 4 / 64 with tolerance 4.47e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=236.87 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    Change of 0.01 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(236.8703912, dtype=float64), 'logtau': Array(5.24788739, dtype=float64), 'logamp': Array(0.11836983, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(-0.86599669, dtype=float64), 'logtau': Array(0.09923632, dtype=float64), 'logamp': Array(0.07895421, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 10159.017162191518 
    And log height: -88.54... 
    log-evidence is ~-91.32 
    Seems to have converged at iteration 5 / 64 with tolerance 5.43e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=249.67 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    22 
    Change of 0.07 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(249.6687914, dtype=float64), 'logtau': Array(5.2007492, dtype=float64), 'logamp': Array(0.12880985, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(-0.79038509, dtype=float64), 'logtau': Array(0.08034287, dtype=float64), 'logamp': Array(0.08592606, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 9495.748693417188 
    And log height: -100.52... 
    log-evidence is ~-103.26 
    Seems to have converged at iteration 6 / 64 with tolerance 1.16e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=262.47 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    22 
    23 
    24 
    25 
    Change of 0.35 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(262.4671916, dtype=float64), 'logtau': Array(5.06179063, dtype=float64), 'logamp': Array(0.13968948, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(-0.71686371, dtype=float64), 'logtau': Array(0.02471751, dtype=float64), 'logamp': Array(0.09319371, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 9056.91453473238 
    And log height: -116.40... 
    log-evidence is ~-119.11 
    Seems to have converged at iteration 7 / 64 with tolerance 7.02e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=275.27 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    Change of 0.17 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(275.2655918, dtype=float64), 'logtau': Array(4.97100673, dtype=float64), 'logamp': Array(0.15160547, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(-0.64515583, dtype=float64), 'logtau': Array(-0.01159744, dtype=float64), 'logamp': Array(0.10115649, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 9014.149543248497 
    And log height: -131.25... 
    log-evidence is ~-133.97 
    Seems to have converged at iteration 8 / 64 with tolerance 2.21e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=288.06 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    22 
    23 
    24 
    25 
    Change of 0.04 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(288.063992, dtype=float64), 'logtau': Array(5.03035595, dtype=float64), 'logamp': Array(0.15234395, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(-0.57501698, dtype=float64), 'logtau': Array(0.01214253, dtype=float64), 'logamp': Array(0.10165007, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 8302.344562011076 
    And log height: -152.03... 
    log-evidence is ~-154.70 
    Seems to have converged at iteration 9 / 64 with tolerance 1.40e-06 
    ::::::::::::::::::::::: 
    Scanning at lag=300.86 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    22 
    23 
    24 
    25 
    26 
    Change of 0.74 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(300.8623922, dtype=float64), 'logtau': Array(4.77969986, dtype=float64), 'logamp': Array(0.16161047, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(-0.50622883, dtype=float64), 'logtau': Array(-0.08817715, dtype=float64), 'logamp': Array(0.10784471, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 7628.103234278249 
    And log height: -154.66... 
    log-evidence is ~-157.29 
    Seems to have converged at iteration 10 / 64 with tolerance 7.05e-06 
    ::::::::::::::::::::::: 
    Scanning at lag=313.66 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    22 
    23 
    24 
    25 
    Change of 0.47 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(313.6607924, dtype=float64), 'logtau': Array(4.54940452, dtype=float64), 'logamp': Array(0.15096231, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(-0.43859422, dtype=float64), 'logtau': Array(-0.18072851, dtype=float64), 'logamp': Array(0.10072662, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 8852.930614848328 
    And log height: -146.36... 
    log-evidence is ~-149.07 
    Seems to have converged at iteration 11 / 64 with tolerance 6.91e-06 
    ::::::::::::::::::::::: 
    Scanning at lag=326.46 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    22 
    23 
    Change of 0.20 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(326.4591926, dtype=float64), 'logtau': Array(4.36618577, dtype=float64), 'logamp': Array(0.13476476, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(-0.37193313, dtype=float64), 'logtau': Array(-0.25489689, dtype=float64), 'logamp': Array(0.08990368, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 7790.053410864596 
    And log height: -159.34... 
    log-evidence is ~-161.98 
    Seems to have converged at iteration 12 / 64 with tolerance 1.07e-04 
    ::::::::::::::::::::::: 
    Scanning at lag=339.26 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    Change of 0.04 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(339.2575928, dtype=float64), 'logtau': Array(4.30935061, dtype=float64), 'logamp': Array(0.09409968, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(-0.30607944, dtype=float64), 'logtau': Array(-0.27803715, dtype=float64), 'logamp': Array(0.06275371, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 9105.367272956752 
    And log height: -158.29... 
    log-evidence is ~-161.01 
    Seems to have converged at iteration 13 / 64 with tolerance 1.92e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=352.06 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    22 
    Change of 0.16 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(352.055993, dtype=float64), 'logtau': Array(4.43103285, dtype=float64), 'logamp': Array(0.08725839, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(-0.24087801, dtype=float64), 'logtau': Array(-0.2285769, dtype=float64), 'logamp': Array(0.05818867, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 8878.071676334448 
    And log height: -155.23... 
    log-evidence is ~-157.93 
    Seems to have converged at iteration 14 / 64 with tolerance 9.75e-06 
    ::::::::::::::::::::::: 
    Scanning at lag=364.85 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    22 
    23 
    24 
    Change of 0.92 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(364.8543932, dtype=float64), 'logtau': Array(4.69925886, dtype=float64), 'logamp': Array(0.082399, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(-0.17618235, dtype=float64), 'logtau': Array(-0.12044184, dtype=float64), 'logamp': Array(0.05494649, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 10508.888150739962 
    And log height: -150.23... 
    log-evidence is ~-153.02 
    Seems to have converged at iteration 15 / 64 with tolerance 2.79e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=377.65 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    Change of 0.08 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(377.6527934, dtype=float64), 'logtau': Array(4.78887678, dtype=float64), 'logamp': Array(0.08264614, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(-0.1118525, dtype=float64), 'logtau': Array(-0.08449953, dtype=float64), 'logamp': Array(0.05511137, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 8587.561304112336 
    And log height: -152.35... 
    log-evidence is ~-155.04 
    Seems to have converged at iteration 16 / 64 with tolerance 4.62e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=390.45 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    Change of 0.30 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(390.4511936, dtype=float64), 'logtau': Array(4.91774366, dtype=float64), 'logamp': Array(0.07492639, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(-0.0477531, dtype=float64), 'logtau': Array(-0.03290551, dtype=float64), 'logamp': Array(0.04996131, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 11127.111267688313 
    And log height: -126.25... 
    log-evidence is ~-129.07 
    Seems to have converged at iteration 17 / 64 with tolerance 3.46e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=403.25 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    Change of 0.01 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(403.2495938, dtype=float64), 'logtau': Array(4.88247813, dtype=float64), 'logamp': Array(0.07177486, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(0.01624833, dtype=float64), 'logtau': Array(-0.04701741, dtype=float64), 'logamp': Array(0.04785904, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 10457.362182297966 
    And log height: -120.13... 
    log-evidence is ~-122.92 
    Seems to have converged at iteration 18 / 64 with tolerance 7.44e-06 
    ::::::::::::::::::::::: 
    Scanning at lag=416.05 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    22 
    23 
    24 
    25 
    Change of 0.01 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(416.047994, dtype=float64), 'logtau': Array(4.9015317, dtype=float64), 'logamp': Array(0.07099813, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(0.08028306, dtype=float64), 'logtau': Array(-0.03939241, dtype=float64), 'logamp': Array(0.04734093, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 9723.014329847865 
    And log height: -122.52... 
    log-evidence is ~-125.27 
    Seems to have converged at iteration 19 / 64 with tolerance 5.59e-06 
    ::::::::::::::::::::::: 
    Scanning at lag=428.85 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    22 
    23 
    Change of 0.35 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(428.8463942, dtype=float64), 'logtau': Array(5.04940972, dtype=float64), 'logamp': Array(0.06732388, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(0.14448279, dtype=float64), 'logtau': Array(0.01976453, dtype=float64), 'logamp': Array(0.04489012, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 10362.206712635108 
    And log height: -120.44... 
    log-evidence is ~-123.22 
    Seems to have converged at iteration 20 / 64 with tolerance 1.09e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=441.64 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    Change of 0.01 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(441.6447944, dtype=float64), 'logtau': Array(5.02765641, dtype=float64), 'logamp': Array(0.07069677, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(0.20898124, dtype=float64), 'logtau': Array(0.01106268, dtype=float64), 'logamp': Array(0.0471399, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 11179.621501141766 
    And log height: -104.07... 
    log-evidence is ~-106.89 
    Seems to have converged at iteration 21 / 64 with tolerance 1.13e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=454.44 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    Change of 0.06 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(454.4431946, dtype=float64), 'logtau': Array(5.09234729, dtype=float64), 'logamp': Array(0.07272627, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(0.27391588, dtype=float64), 'logtau': Array(0.03694312, dtype=float64), 'logamp': Array(0.04849368, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 11021.162831597443 
    And log height: -100.88... 
    log-evidence is ~-103.69 
    Seems to have converged at iteration 22 / 64 with tolerance 3.32e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=467.24 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    Change of 0.02 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(467.2415948, dtype=float64), 'logtau': Array(5.12730575, dtype=float64), 'logamp': Array(0.07523262, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(0.33942974, dtype=float64), 'logtau': Array(0.05093331, dtype=float64), 'logamp': Array(0.0501656, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 11717.791952988804 
    And log height: -94.53... 
    log-evidence is ~-97.38 
    Seems to have converged at iteration 23 / 64 with tolerance 1.80e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=480.04 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    Change of 0.04 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(480.039995, dtype=float64), 'logtau': Array(5.18163639, dtype=float64), 'logamp': Array(0.07927156, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(0.40567342, dtype=float64), 'logtau': Array(0.07268654, dtype=float64), 'logamp': Array(0.05286001, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 11854.803064043585 
    And log height: -90.61... 
    log-evidence is ~-93.46 
    Seems to have converged at iteration 24 / 64 with tolerance 2.70e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=492.84 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    Change of 0.00 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(492.8383952, dtype=float64), 'logtau': Array(5.2081509, dtype=float64), 'logamp': Array(0.08560515, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(0.47280731, dtype=float64), 'logtau': Array(0.08330851, dtype=float64), 'logamp': Array(0.0570856, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 12093.395503917192 
    And log height: -87.11... 
    log-evidence is ~-89.97 
    Seems to have converged at iteration 25 / 64 with tolerance 2.15e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=505.64 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    Change of 0.00 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(505.6367954, dtype=float64), 'logtau': Array(5.23346809, dtype=float64), 'logamp': Array(0.09099498, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(0.54100422, dtype=float64), 'logtau': Array(0.0934552, dtype=float64), 'logamp': Array(0.06068194, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 11932.357903853192 
    And log height: -87.46... 
    log-evidence is ~-90.31 
    Seems to have converged at iteration 26 / 64 with tolerance 3.66e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=518.44 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    Change of 0.03 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(518.4351956, dtype=float64), 'logtau': Array(5.28151785, dtype=float64), 'logamp': Array(0.09613948, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(0.6104524, dtype=float64), 'logtau': Array(0.11272636, dtype=float64), 'logamp': Array(0.06411494, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 11947.757827468422 
    And log height: -86.31... 
    log-evidence is ~-89.17 
    Seems to have converged at iteration 27 / 64 with tolerance 1.89e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=531.23 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    Change of 0.00 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(531.2335958, dtype=float64), 'logtau': Array(5.29039231, dtype=float64), 'logamp': Array(0.10338891, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(0.68135922, dtype=float64), 'logtau': Array(0.11628779, dtype=float64), 'logamp': Array(0.06895325, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 11923.191257673023 
    And log height: -82.60... 
    log-evidence is ~-85.45 
    Seems to have converged at iteration 28 / 64 with tolerance 3.61e-06 
    ::::::::::::::::::::::: 
    Scanning at lag=544.03 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    Change of 0.00 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(544.031996, dtype=float64), 'logtau': Array(5.31800168, dtype=float64), 'logamp': Array(0.11273685, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(0.75395561, dtype=float64), 'logtau': Array(0.1273726, dtype=float64), 'logamp': Array(0.07519331, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 11555.010630863895 
    And log height: -83.16... 
    log-evidence is ~-86.00 
    Seems to have converged at iteration 29 / 64 with tolerance 2.02e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=556.83 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    22 
    23 
    Change of 0.01 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(556.8303962, dtype=float64), 'logtau': Array(5.35034044, dtype=float64), 'logamp': Array(0.11996183, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(0.82850154, dtype=float64), 'logtau': Array(0.14036619, dtype=float64), 'logamp': Array(0.08001722, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 11486.16736959359 
    And log height: -82.86... 
    log-evidence is ~-85.69 
    Seems to have converged at iteration 30 / 64 with tolerance 3.06e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=569.63 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    Change of 0.00 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(569.6287964, dtype=float64), 'logtau': Array(5.35836896, dtype=float64), 'logamp': Array(0.12654133, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(0.90529298, dtype=float64), 'logtau': Array(0.14359381, dtype=float64), 'logamp': Array(0.08441097, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 11136.2465553326 
    And log height: -84.10... 
    log-evidence is ~-86.92 
    Seems to have converged at iteration 31 / 64 with tolerance 1.02e-04 
    ::::::::::::::::::::::: 
    Scanning at lag=582.43 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    Change of 0.00 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(582.4271966, dtype=float64), 'logtau': Array(5.35547606, dtype=float64), 'logamp': Array(0.13207002, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(0.98467067, dtype=float64), 'logtau': Array(0.14243072, dtype=float64), 'logamp': Array(0.08810362, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 11235.126434495613 
    And log height: -83.08... 
    log-evidence is ~-85.90 
    Seems to have converged at iteration 32 / 64 with tolerance 2.67e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=595.23 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    Change of 0.00 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(595.2255968, dtype=float64), 'logtau': Array(5.34887707, dtype=float64), 'logamp': Array(0.13560703, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(1.06703159, dtype=float64), 'logtau': Array(0.13977796, dtype=float64), 'logamp': Array(0.09046633, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 11159.781065764199 
    And log height: -85.79... 
    log-evidence is ~-88.61 
    Seems to have converged at iteration 33 / 64 with tolerance 2.41e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=608.02 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    22 
    Change of 0.04 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(608.023997, dtype=float64), 'logtau': Array(5.31719, dtype=float64), 'logamp': Array(0.14213307, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(1.15284397, dtype=float64), 'logtau': Array(0.12704661, dtype=float64), 'logamp': Array(0.09482637, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 11450.348821076794 
    And log height: -87.01... 
    log-evidence is ~-89.85 
    Seems to have converged at iteration 34 / 64 with tolerance 4.41e-06 
    ::::::::::::::::::::::: 
    Scanning at lag=620.82 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    22 
    23 
    24 
    25 
    26 
    Change of 0.01 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(620.8223972, dtype=float64), 'logtau': Array(5.30068747, dtype=float64), 'logamp': Array(0.14613897, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(1.24266754, dtype=float64), 'logtau': Array(0.1204203, dtype=float64), 'logamp': Array(0.09750315, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 10779.998397202566 
    And log height: -96.84... 
    log-evidence is ~-99.64 
    Seems to have converged at iteration 35 / 64 with tolerance 2.92e-06 
    ::::::::::::::::::::::: 
    Scanning at lag=633.62 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    22 
    23 
    24 
    Change of 0.04 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(633.6207974, dtype=float64), 'logtau': Array(5.26081784, dtype=float64), 'logamp': Array(0.14908845, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(1.33718113, dtype=float64), 'logtau': Array(0.10442192, dtype=float64), 'logamp': Array(0.09947425, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 11422.325647676593 
    And log height: -95.56... 
    log-evidence is ~-98.39 
    Seems to have converged at iteration 36 / 64 with tolerance 2.01e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=646.42 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    22 
    Change of 0.01 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(646.4191976, dtype=float64), 'logtau': Array(5.24352153, dtype=float64), 'logamp': Array(0.1538787, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(1.43722138, dtype=float64), 'logtau': Array(0.09748574, dtype=float64), 'logamp': Array(0.10267591, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 11086.910888934493 
    And log height: -100.95... 
    log-evidence is ~-103.77 
    Seems to have converged at iteration 37 / 64 with tolerance 3.45e-06 
    ::::::::::::::::::::::: 
    Scanning at lag=659.22 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    22 
    23 
    24 
    25 
    26 
    Change of 0.00 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(659.2175978, dtype=float64), 'logtau': Array(5.23437846, dtype=float64), 'logamp': Array(0.15828633, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(1.54383822, dtype=float64), 'logtau': Array(0.09382014, dtype=float64), 'logamp': Array(0.10562231, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 9961.626942977055 
    And log height: -109.16... 
    log-evidence is ~-111.93 
    Seems to have converged at iteration 38 / 64 with tolerance 7.88e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=672.02 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    Change of 0.00 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(672.015998, dtype=float64), 'logtau': Array(5.24098358, dtype=float64), 'logamp': Array(0.16513038, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(1.65837688, dtype=float64), 'logtau': Array(0.09646817, dtype=float64), 'logamp': Array(0.1101983, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 11090.800401180635 
    And log height: -102.24... 
    log-evidence is ~-105.06 
    Seems to have converged at iteration 39 / 64 with tolerance 5.86e-06 
    ::::::::::::::::::::::: 
    Scanning at lag=684.81 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    22 
    23 
    24 
    Change of 0.07 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(684.8143982, dtype=float64), 'logtau': Array(5.18058396, dtype=float64), 'logamp': Array(0.17098222, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(1.78260309, dtype=float64), 'logtau': Array(0.07226502, dtype=float64), 'logamp': Array(0.11411181, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 9516.021478174916 
    And log height: -126.82... 
    log-evidence is ~-129.56 
    Seems to have converged at iteration 40 / 64 with tolerance 7.90e-06 
    ::::::::::::::::::::::: 
    Scanning at lag=697.61 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    22 
    23 
    24 
    Change of 0.48 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(697.6127984, dtype=float64), 'logtau': Array(4.98910479, dtype=float64), 'logamp': Array(0.17617005, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(1.9189025, dtype=float64), 'logtau': Array(-0.00435809, dtype=float64), 'logamp': Array(0.11758198, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 8848.629334944715 
    And log height: -147.29... 
    log-evidence is ~-150.00 
    Seems to have converged at iteration 41 / 64 with tolerance 1.11e-04 
    ::::::::::::::::::::::: 
    Scanning at lag=710.41 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    22 
    Change of 0.07 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(710.4111986, dtype=float64), 'logtau': Array(4.91223203, dtype=float64), 'logamp': Array(0.17629207, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(2.07061363, dtype=float64), 'logtau': Array(-0.03511079, dtype=float64), 'logamp': Array(0.11766361, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 8768.003158097414 
    And log height: -152.26... 
    log-evidence is ~-154.97 
    Seems to have converged at iteration 42 / 64 with tolerance 3.58e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=723.21 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    Change of 0.00 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(723.2095988, dtype=float64), 'logtau': Array(4.90440102, dtype=float64), 'logamp': Array(0.17046547, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(2.24261943, dtype=float64), 'logtau': Array(-0.03824425, dtype=float64), 'logamp': Array(0.11376619, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 10332.508367088283 
    And log height: -130.36... 
    log-evidence is ~-133.14 
    Seems to have converged at iteration 43 / 64 with tolerance 4.84e-06 
    ::::::::::::::::::::::: 
    Scanning at lag=736.01 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    Change of 0.02 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(736.007999, dtype=float64), 'logtau': Array(4.82259503, dtype=float64), 'logamp': Array(0.134435, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(2.4424829, dtype=float64), 'logtau': Array(-0.07099179, dtype=float64), 'logamp': Array(0.08968339, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 10842.23411774035 
    And log height: -132.22... 
    log-evidence is ~-135.03 
    Seems to have converged at iteration 44 / 64 with tolerance 1.84e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=748.81 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    Change of 0.28 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(748.8063992, dtype=float64), 'logtau': Array(4.91972791, dtype=float64), 'logamp': Array(0.11249579, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(2.68286593, dtype=float64), 'logtau': Array(-0.0321116, dtype=float64), 'logamp': Array(0.07503237, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 11799.932566691949 
    And log height: -137.58... 
    log-evidence is ~-140.43 
    Seems to have converged at iteration 45 / 64 with tolerance 2.28e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=761.60 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    Change of 0.01 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(761.6047994, dtype=float64), 'logtau': Array(4.87503257, dtype=float64), 'logamp': Array(0.10397702, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(2.98749532, dtype=float64), 'logtau': Array(-0.04999738, dtype=float64), 'logamp': Array(0.06934579, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 13158.448298054658 
    And log height: -128.81... 
    log-evidence is ~-131.71 
    Seems to have converged at iteration 46 / 64 with tolerance 7.29e-06 
    ::::::::::::::::::::::: 
    Scanning at lag=774.40 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    22 
    23 
    24 
    25 
    Change of 0.10 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(774.4031996, dtype=float64), 'logtau': Array(4.94579815, dtype=float64), 'logamp': Array(0.09636429, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(3.40962531, dtype=float64), 'logtau': Array(-0.02168159, dtype=float64), 'logamp': Array(0.06426497, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 11282.322330289946 
    And log height: -144.23... 
    log-evidence is ~-147.05 
    Seems to have converged at iteration 47 / 64 with tolerance 4.77e-07 
    ::::::::::::::::::::::: 
    Scanning at lag=787.20 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    22 
    23 
    24 
    Change of 0.09 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(787.2015998, dtype=float64), 'logtau': Array(4.85678563, dtype=float64), 'logamp': Array(0.09258298, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(4.1191642, dtype=float64), 'logtau': Array(-0.05730142, dtype=float64), 'logamp': Array(0.06174159, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 12551.97876276971 
    And log height: -131.01... 
    log-evidence is ~-133.89 
    Seems to have converged at iteration 48 / 64 with tolerance 1.18e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=800.00 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    22 
    23 
    24 
    25 
    26 
    27 
    28 
    29 
    30 
    31 
    32 
    33 
    34 
    35 
    36 
    37 
    38 
    39 
    40 
    41 
    42 
    43 
    44 
    45 
    46 
    47 
    48 
    49 
    50 
    51 
    52 
    53 
    54 
    55 
    56 
    57 
    58 
    59 
    60 
    61 
    62 
    63 
    64 
    65 
    66 
    67 
    68 
    69 
    70 
    71 
    72 
    73 
    74 
    75 
    76 
    77 
    78 
    79 
    80 
    81 
    82 
    83 
    84 
    85 
    86 
    87 
    88 
    89 
    90 
    91 
    92 
    93 
    94 
    95 
    96 
    97 
    98 
    99 
    100 
    101 
    102 
    103 
    104 
    105 
    106 
    107 
    108 
    109 
    110 
    111 
    112 
    113 
    114 
    115 
    116 
    117 
    118 
    119 
    120 
    121 
    122 
    123 
    124 
    125 
    126 
    127 
    128 
    129 
    130 
    131 
    132 
    133 
    134 
    135 
    136 
    137 
    138 
    139 
    140 
    141 
    142 
    143 
    144 
    145 
    146 
    147 
    148 
    149 
    150 
    151 
    152 
    153 
    154 
    155 
    156 
    157 
    158 
    159 
    160 
    161 
    162 
    163 
    164 
    165 
    166 
    167 
    168 
    169 
    170 
    171 
    172 
    173 
    174 
    175 
    176 
    177 
    178 
    179 
    180 
    181 
    182 
    183 
    184 
    185 
    186 
    187 
    188 
    189 
    190 
    191 
    192 
    193 
    194 
    195 
    196 
    197 
    198 
    199 
    200 
    201 
    202 
    203 
    204 
    205 
    206 
    207 
    208 
    209 
    210 
    211 
    212 
    213 
    214 
    215 
    216 
    217 
    218 
    219 
    220 
    221 
    222 
    223 
    224 
    225 
    226 
    227 
    228 
    229 
    230 
    231 
    232 
    233 
    234 
    235 
    236 
    237 
    238 
    239 
    240 
    241 
    242 
    243 
    244 
    245 
    246 
    247 
    248 
    249 
    250 
    251 
    252 
    253 
    254 
    255 
    256 
    257 
    258 
    259 
    260 
    261 
    262 
    263 
    264 
    265 
    266 
    267 
    268 
    269 
    270 
    271 
    272 
    273 
    274 
    275 
    276 
    277 
    278 
    279 
    280 
    281 
    282 
    283 
    284 
    285 
    286 
    287 
    288 
    289 
    290 
    291 
    292 
    293 
    294 
    295 
    296 
    297 
    298 
    299 
    300 
    301 
    302 
    303 
    304 
    305 
    306 
    307 
    308 
    309 
    310 
    311 
    312 
    313 
    314 
    315 
    316 
    317 
    318 
    319 
    320 
    321 
    322 
    323 
    324 
    325 
    326 
    327 
    328 
    329 
    330 
    331 
    332 
    333 
    334 
    335 
    336 
    337 
    338 
    339 
    340 
    341 
    342 
    343 
    344 
    345 
    346 
    347 
    348 
    349 
    350 
    351 
    352 
    353 
    354 
    355 
    356 
    357 
    358 
    359 
    360 
    361 
    362 
    363 
    364 
    365 
    366 
    367 
    368 
    369 
    370 
    371 
    372 
    373 
    374 
    375 
    376 
    377 
    378 
    379 
    380 
    381 
    382 
    383 
    384 
    385 
    386 
    387 
    388 
    389 
    390 
    391 
    392 
    393 
    394 
    395 
    396 
    397 
    398 
    399 
    400 
    401 
    402 
    403 
    404 
    405 
    406 
    407 
    408 
    409 
    410 
    411 
    412 
    413 
    414 
    415 
    416 
    417 
    418 
    419 
    420 
    421 
    422 
    423 
    424 
    425 
    426 
    427 
    428 
    429 
    430 
    431 
    432 
    433 
    434 
    435 
    436 
    437 
    438 
    439 
    440 
    441 
    442 
    443 
    444 
    445 
    446 
    447 
    448 
    449 
    450 
    451 
    452 
    453 
    454 
    455 
    456 
    457 
    458 
    459 
    460 
    461 
    462 
    463 
    464 
    465 
    466 
    467 
    468 
    469 
    470 
    471 
    472 
    473 
    474 
    475 
    476 
    477 
    478 
    479 
    480 
    481 
    482 
    483 
    484 
    485 
    486 
    487 
    488 
    489 
    490 
    491 
    492 
    493 
    494 
    495 
    496 
    497 
    498 
    499 
    500 
    501 
    502 
    503 
    504 
    505 
    506 
    507 
    508 
    509 
    510 
    511 
    512 
    513 
    514 
    515 
    516 
    517 
    518 
    519 
    520 
    521 
    522 
    523 
    524 
    525 
    526 
    527 
    528 
    529 
    530 
    531 
    532 
    533 
    534 
    535 
    536 
    537 
    538 
    539 
    540 
    541 
    542 
    543 
    544 
    545 
    546 
    547 
    548 
    549 
    550 
    551 
    552 
    553 
    554 
    555 
    556 
    557 
    558 
    559 
    560 
    561 
    562 
    563 
    564 
    565 
    566 
    567 
    568 
    569 
    570 
    571 
    572 
    573 
    574 
    575 
    576 
    577 
    578 
    579 
    580 
    581 
    582 
    583 
    584 
    585 
    586 
    587 
    588 
    589 
    590 
    591 
    592 
    593 
    594 
    595 
    596 
    597 
    598 
    599 
    600 
    601 
    602 
    603 
    604 
    605 
    606 
    607 
    608 
    609 
    610 
    611 
    612 
    613 
    614 
    615 
    616 
    617 
    618 
    619 
    620 
    621 
    622 
    623 
    624 
    625 
    626 
    627 
    628 
    629 
    630 
    631 
    632 
    633 
    634 
    635 
    636 
    637 
    638 
    639 
    640 
    641 
    642 
    643 
    644 
    645 
    646 
    647 
    648 
    649 
    650 
    651 
    652 
    653 
    654 
    655 
    656 
    657 
    658 
    659 
    660 
    661 
    662 
    663 
    664 
    665 
    666 
    667 
    668 
    669 
    670 
    671 
    672 
    673 
    674 
    675 
    676 
    677 
    678 
    679 
    680 
    681 
    682 
    683 
    684 
    685 
    686 
    687 
    688 
    689 
    690 
    691 
    692 
    693 
    694 
    695 
    696 
    697 
    698 
    699 
    700 
    701 
    702 
    703 
    704 
    705 
    706 
    707 
    708 
    709 
    710 
    711 
    712 
    713 
    714 
    715 
    716 
    717 
    718 
    719 
    720 
    721 
    722 
    723 
    724 
    725 
    726 
    727 
    728 
    729 
    730 
    731 
    732 
    733 
    734 
    735 
    736 
    737 
    738 
    739 
    740 
    741 
    742 
    743 
    744 
    745 
    746 
    747 
    748 
    749 
    750 
    751 
    752 
    753 
    754 
    755 
    756 
    757 
    758 
    759 
    760 
    761 
    762 
    763 
    764 
    765 
    766 
    767 
    768 
    769 
    770 
    771 
    772 
    773 
    774 
    775 
    776 
    777 
    778 
    779 
    780 
    781 
    782 
    783 
    784 
    785 
    786 
    787 
    788 
    789 
    790 
    791 
    792 
    793 
    794 
    795 
    796 
    797 
    798 
    799 
    800 
    801 
    802 
    803 
    804 
    805 
    806 
    807 
    808 
    809 
    810 
    811 
    812 
    813 
    814 
    815 
    816 
    817 
    818 
    819 
    820 
    821 
    822 
    823 
    824 
    825 
    826 
    827 
    828 
    829 
    830 
    831 
    832 
    833 
    834 
    835 
    836 
    837 
    838 
    839 
    840 
    841 
    842 
    843 
    844 
    845 
    846 
    847 
    848 
    849 
    850 
    851 
    852 
    853 
    854 
    855 
    856 
    857 
    858 
    859 
    860 
    861 
    862 
    863 
    864 
    865 
    866 
    867 
    868 
    869 
    870 
    871 
    872 
    873 
    874 
    875 
    876 
    877 
    878 
    879 
    880 
    881 
    882 
    883 
    884 
    885 
    886 
    887 
    888 
    889 
    890 
    891 
    892 
    893 
    894 
    895 
    896 
    897 
    898 
    899 
    900 
    901 
    902 
    903 
    904 
    905 
    906 
    907 
    908 
    909 
    910 
    911 
    912 
    913 
    914 
    915 
    916 
    917 
    918 
    919 
    920 
    921 
    922 
    923 
    924 
    925 
    926 
    927 
    928 
    929 
    930 
    931 
    932 
    933 
    934 
    935 
    936 
    937 
    938 
    939 
    940 
    941 
    942 
    943 
    944 
    945 
    946 
    947 
    948 
    949 
    950 
    951 
    952 
    953 
    954 
    955 
    956 
    957 
    958 
    959 
    960 
    961 
    962 
    963 
    964 
    965 
    966 
    967 
    968 
    969 
    970 
    971 
    972 
    973 
    974 
    975 
    976 
    977 
    978 
    979 
    980 
    981 
    982 
    983 
    984 
    985 
    986 
    987 
    988 
    989 
    990 
    991 
    992 
    993 
    994 
    995 
    996 
    997 
    998 
    999 
    1000 
    1001 
    1002 
    1003 
    1004 
    1005 
    1006 
    1007 
    1008 
    1009 
    1010 
    1011 
    1012 
    1013 
    1014 
    1015 
    1016 
    1017 
    1018 
    1019 
    1020 
    1021 
    1022 
    1023 
    Change of 0.00 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(800., dtype=float64), 'logtau': Array(4.85024456, dtype=float64), 'logamp': Array(0.08921577, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(35.63818828, dtype=float64), 'logtau': Array(-0.0599201, dtype=float64), 'logamp': Array(0.05949472, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 11716.830207304018 
    And log height: -171.11... 
    log-evidence is ~-173.96 
    Seems to have converged at iteration 49 / 64 with tolerance 4.46e-01 
    ::::::::::::::::::::::: 
    Scanning at lag=160.08 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    Change of 3.51 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(160.07999, dtype=float64), 'logtau': Array(5.20029853, dtype=float64), 'logamp': Array(0.04284192, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(-1.38566956, dtype=float64), 'logtau': Array(0.08016231, dtype=float64), 'logamp': Array(0.02856322, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 10994.588667237482 
    And log height: -77.94... 
    log-evidence is ~-80.76 
    Seems to have converged at iteration 50 / 64 with tolerance 4.17e-06 
    ::::::::::::::::::::::: 
    Scanning at lag=147.28 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    22 
    23 
    24 
    Change of 0.04 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(147.2815898, dtype=float64), 'logtau': Array(5.1111427, dtype=float64), 'logamp': Array(0.02041769, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(-1.48879948, dtype=float64), 'logtau': Array(0.0444644, dtype=float64), 'logamp': Array(0.013612, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 10870.846415433101 
    And log height: -85.55... 
    log-evidence is ~-88.36 
    Seems to have converged at iteration 51 / 64 with tolerance 2.75e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=134.48 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    Change of 0.01 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(134.4831896, dtype=float64), 'logtau': Array(5.05945243, dtype=float64), 'logamp': Array(-0.0060417, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(-1.59912469, dtype=float64), 'logtau': Array(0.02378209, dtype=float64), 'logamp': Array(-0.00402781, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 10674.35354805318 
    And log height: -91.10... 
    log-evidence is ~-93.90 
    Seems to have converged at iteration 52 / 64 with tolerance 2.03e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=121.68 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    Change of 0.01 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(121.6847894, dtype=float64), 'logtau': Array(5.01728743, dtype=float64), 'logamp': Array(-0.01754055, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(-1.71817808, dtype=float64), 'logtau': Array(0.006915, dtype=float64), 'logamp': Array(-0.01169383, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 11993.742268868196 
    And log height: -82.29... 
    log-evidence is ~-85.15 
    Seems to have converged at iteration 53 / 64 with tolerance 5.17e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=108.89 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    Change of 0.01 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(108.8863892, dtype=float64), 'logtau': Array(4.96847217, dtype=float64), 'logamp': Array(-0.02901717, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(-1.84799919, dtype=float64), 'logtau': Array(-0.0126113, dtype=float64), 'logamp': Array(-0.01934538, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 11762.943420098933 
    And log height: -89.08... 
    log-evidence is ~-91.93 
    Seems to have converged at iteration 54 / 64 with tolerance 5.77e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=96.09 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    Change of 0.20 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(96.087989, dtype=float64), 'logtau': Array(4.83336155, dtype=float64), 'logamp': Array(-0.04081003, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(-1.99138904, dtype=float64), 'logtau': Array(-0.06668008, dtype=float64), 'logamp': Array(-0.02720837, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 11809.141723147337 
    And log height: -105.00... 
    log-evidence is ~-107.85 
    Seems to have converged at iteration 55 / 64 with tolerance 1.62e-04 
    ::::::::::::::::::::::: 
    Scanning at lag=83.29 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    22 
    23 
    24 
    25 
    Change of 1.60 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(83.2895888, dtype=float64), 'logtau': Array(4.45144795, dtype=float64), 'logamp': Array(-0.04363386, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(-2.15234831, dtype=float64), 'logtau': Array(-0.22030758, dtype=float64), 'logamp': Array(-0.02909129, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 11013.580119681643 
    And log height: -131.16... 
    log-evidence is ~-133.97 
    Seems to have converged at iteration 56 / 64 with tolerance 4.18e-07 
    ::::::::::::::::::::::: 
    Scanning at lag=70.49 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    Change of 0.03 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(70.4911886, dtype=float64), 'logtau': Array(4.37413334, dtype=float64), 'logamp': Array(-0.06195681, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(-2.33688373, dtype=float64), 'logtau': Array(-0.2516666, dtype=float64), 'logamp': Array(-0.04131042, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 10837.315118729648 
    And log height: -141.65... 
    log-evidence is ~-144.46 
    Seems to have converged at iteration 57 / 64 with tolerance 5.40e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=57.69 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    22 
    Change of 0.13 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(57.6927884, dtype=float64), 'logtau': Array(4.24190451, dtype=float64), 'logamp': Array(-0.0753153, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(-2.55463101, dtype=float64), 'logtau': Array(-0.30559443, dtype=float64), 'logamp': Array(-0.05022075, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 11588.496634703513 
    And log height: -145.40... 
    log-evidence is ~-148.24 
    Seems to have converged at iteration 58 / 64 with tolerance 4.56e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=44.89 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    22 
    23 
    Change of 1.34 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(44.8943882, dtype=float64), 'logtau': Array(3.85325924, dtype=float64), 'logamp': Array(-0.07962225, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(-2.82254482, dtype=float64), 'logtau': Array(-0.46700264, dtype=float64), 'logamp': Array(-0.05309397, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 12102.795391584421 
    And log height: -157.64... 
    log-evidence is ~-160.50 
    Seems to have converged at iteration 59 / 64 with tolerance 4.43e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=32.10 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    22 
    23 
    Change of 0.09 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(32.095988, dtype=float64), 'logtau': Array(3.92347613, dtype=float64), 'logamp': Array(-0.09640564, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(-3.1749337, dtype=float64), 'logtau': Array(-0.43745477, dtype=float64), 'logamp': Array(-0.06429256, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 10727.521875741424 
    And log height: -166.23... 
    log-evidence is ~-169.04 
    Seems to have converged at iteration 60 / 64 with tolerance 1.39e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=19.30 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    22 
    23 
    Change of 2.68 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(19.2975878, dtype=float64), 'logtau': Array(3.21098856, dtype=float64), 'logamp': Array(-0.06308739, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(-3.70021394, dtype=float64), 'logtau': Array(-0.74872649, dtype=float64), 'logamp': Array(-0.04206446, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 7197.432328241079 
    And log height: -202.99... 
    log-evidence is ~-205.59 
    Seems to have converged at iteration 61 / 64 with tolerance 1.11e-04 
    ::::::::::::::::::::::: 
    Scanning at lag=6.50 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    22 
    23 
    24 
    Change of 2.94 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(6.4991876, dtype=float64), 'logtau': Array(2.69656298, dtype=float64), 'logamp': Array(-0.03237177, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(-4.80477738, dtype=float64), 'logtau': Array(-0.99636707, dtype=float64), 'logamp': Array(-0.02158201, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 18261.812414643555 
    And log height: -200.86... 
    log-evidence is ~-203.93 
    Seems to have converged at iteration 62 / 64 with tolerance 6.56e-05 
    ::::::::::::::::::::::: 
    Scanning at lag=0.00 ... 
    0 
    1 
    2 
    3 
    4 
    5 
    6 
    7 
    8 
    9 
    10 
    11 
    12 
    13 
    14 
    15 
    16 
    17 
    18 
    19 
    20 
    21 
    22 
    23 
    24 
    25 
    26 
    27 
    28 
    29 
    30 
    31 
    32 
    33 
    34 
    35 
    36 
    37 
    38 
    39 
    40 
    41 
    42 
    43 
    44 
    45 
    46 
    47 
    48 
    49 
    50 
    51 
    52 
    53 
    54 
    55 
    56 
    57 
    58 
    59 
    60 
    61 
    62 
    63 
    64 
    65 
    66 
    67 
    68 
    69 
    70 
    71 
    72 
    73 
    74 
    75 
    76 
    77 
    78 
    79 
    80 
    81 
    82 
    83 
    84 
    85 
    86 
    87 
    88 
    89 
    90 
    91 
    92 
    93 
    94 
    95 
    96 
    97 
    98 
    99 
    100 
    101 
    102 
    103 
    104 
    105 
    106 
    107 
    108 
    109 
    110 
    111 
    112 
    113 
    114 
    115 
    116 
    117 
    118 
    119 
    120 
    121 
    122 
    123 
    124 
    125 
    126 
    127 
    128 
    129 
    130 
    131 
    132 
    133 
    134 
    135 
    136 
    137 
    138 
    139 
    140 
    141 
    142 
    143 
    144 
    145 
    146 
    147 
    148 
    149 
    150 
    151 
    152 
    153 
    154 
    155 
    156 
    157 
    158 
    159 
    160 
    161 
    162 
    163 
    164 
    165 
    166 
    167 
    168 
    169 
    170 
    171 
    172 
    173 
    174 
    175 
    176 
    177 
    178 
    179 
    180 
    181 
    182 
    183 
    184 
    185 
    186 
    187 
    188 
    189 
    190 
    191 
    192 
    193 
    194 
    195 
    196 
    197 
    198 
    199 
    200 
    201 
    202 
    203 
    204 
    205 
    206 
    207 
    208 
    209 
    210 
    211 
    212 
    213 
    214 
    215 
    216 
    217 
    218 
    219 
    220 
    221 
    222 
    223 
    224 
    225 
    226 
    227 
    228 
    229 
    230 
    231 
    232 
    233 
    234 
    235 
    236 
    237 
    238 
    239 
    240 
    241 
    242 
    243 
    244 
    245 
    246 
    247 
    248 
    249 
    250 
    251 
    252 
    253 
    254 
    255 
    256 
    257 
    258 
    259 
    260 
    261 
    262 
    263 
    264 
    265 
    266 
    267 
    268 
    269 
    270 
    271 
    272 
    273 
    274 
    275 
    276 
    277 
    278 
    279 
    280 
    281 
    282 
    283 
    284 
    285 
    286 
    287 
    288 
    289 
    290 
    291 
    292 
    293 
    294 
    295 
    296 
    297 
    298 
    299 
    300 
    301 
    302 
    303 
    304 
    305 
    306 
    307 
    308 
    309 
    310 
    311 
    312 
    313 
    314 
    315 
    316 
    317 
    318 
    319 
    320 
    321 
    322 
    323 
    324 
    325 
    326 
    327 
    328 
    329 
    330 
    331 
    332 
    333 
    334 
    335 
    336 
    337 
    338 
    339 
    340 
    341 
    342 
    343 
    344 
    345 
    346 
    347 
    348 
    349 
    350 
    351 
    352 
    353 
    354 
    355 
    356 
    357 
    358 
    359 
    360 
    361 
    362 
    363 
    364 
    365 
    366 
    367 
    368 
    369 
    370 
    371 
    372 
    373 
    374 
    375 
    376 
    377 
    378 
    379 
    380 
    381 
    382 
    383 
    384 
    385 
    386 
    387 
    388 
    389 
    390 
    391 
    392 
    393 
    394 
    395 
    396 
    397 
    398 
    399 
    400 
    401 
    402 
    403 
    404 
    405 
    406 
    407 
    408 
    409 
    410 
    411 
    412 
    413 
    414 
    415 
    416 
    417 
    418 
    419 
    420 
    421 
    422 
    423 
    424 
    425 
    426 
    427 
    428 
    429 
    430 
    431 
    432 
    433 
    434 
    435 
    436 
    437 
    438 
    439 
    440 
    441 
    442 
    443 
    444 
    445 
    446 
    447 
    448 
    449 
    450 
    451 
    452 
    453 
    454 
    455 
    456 
    457 
    458 
    459 
    460 
    461 
    462 
    463 
    464 
    465 
    466 
    467 
    468 
    469 
    470 
    471 
    472 
    473 
    474 
    475 
    476 
    477 
    478 
    479 
    480 
    481 
    482 
    483 
    484 
    485 
    486 
    487 
    488 
    489 
    490 
    491 
    492 
    493 
    494 
    495 
    496 
    497 
    498 
    499 
    500 
    501 
    502 
    503 
    504 
    505 
    506 
    507 
    508 
    509 
    510 
    511 
    512 
    513 
    514 
    515 
    516 
    517 
    518 
    519 
    520 
    521 
    522 
    523 
    524 
    525 
    526 
    527 
    528 
    529 
    530 
    531 
    532 
    533 
    534 
    535 
    536 
    537 
    538 
    539 
    540 
    541 
    542 
    543 
    544 
    545 
    546 
    547 
    548 
    549 
    550 
    551 
    552 
    553 
    554 
    555 
    556 
    557 
    558 
    559 
    560 
    561 
    562 
    563 
    564 
    565 
    566 
    567 
    568 
    569 
    570 
    571 
    572 
    573 
    574 
    575 
    576 
    577 
    578 
    579 
    580 
    581 
    582 
    583 
    584 
    585 
    586 
    587 
    588 
    589 
    590 
    591 
    592 
    593 
    594 
    595 
    596 
    597 
    598 
    599 
    600 
    601 
    602 
    603 
    604 
    605 
    606 
    607 
    608 
    609 
    610 
    611 
    612 
    613 
    614 
    615 
    616 
    617 
    618 
    619 
    620 
    621 
    622 
    623 
    624 
    625 
    626 
    627 
    628 
    629 
    630 
    631 
    632 
    633 
    634 
    635 
    636 
    637 
    638 
    639 
    640 
    641 
    642 
    643 
    644 
    645 
    646 
    647 
    648 
    649 
    650 
    651 
    652 
    653 
    654 
    655 
    656 
    657 
    658 
    659 
    660 
    661 
    662 
    663 
    664 
    665 
    666 
    667 
    668 
    669 
    670 
    671 
    672 
    673 
    674 
    675 
    676 
    677 
    678 
    679 
    680 
    681 
    682 
    683 
    684 
    685 
    686 
    687 
    688 
    689 
    690 
    691 
    692 
    693 
    694 
    695 
    696 
    697 
    698 
    699 
    700 
    701 
    702 
    703 
    704 
    705 
    706 
    707 
    708 
    709 
    710 
    711 
    712 
    713 
    714 
    715 
    716 
    717 
    718 
    719 
    720 
    721 
    722 
    723 
    724 
    725 
    726 
    727 
    728 
    729 
    730 
    731 
    732 
    733 
    734 
    735 
    736 
    737 
    738 
    739 
    740 
    741 
    742 
    743 
    744 
    745 
    746 
    747 
    748 
    749 
    750 
    751 
    752 
    753 
    754 
    755 
    756 
    757 
    758 
    759 
    760 
    761 
    762 
    763 
    764 
    765 
    766 
    767 
    768 
    769 
    770 
    771 
    772 
    773 
    774 
    775 
    776 
    777 
    778 
    779 
    780 
    781 
    782 
    783 
    784 
    785 
    786 
    787 
    788 
    789 
    790 
    791 
    792 
    793 
    794 
    795 
    796 
    797 
    798 
    799 
    800 
    801 
    802 
    803 
    804 
    805 
    806 
    807 
    808 
    809 
    810 
    811 
    812 
    813 
    814 
    815 
    816 
    817 
    818 
    819 
    820 
    821 
    822 
    823 
    824 
    825 
    826 
    827 
    828 
    829 
    830 
    831 
    832 
    833 
    834 
    835 
    836 
    837 
    838 
    839 
    840 
    841 
    842 
    843 
    844 
    845 
    846 
    847 
    848 
    849 
    850 
    851 
    852 
    853 
    854 
    855 
    856 
    857 
    858 
    859 
    860 
    861 
    862 
    863 
    864 
    865 
    866 
    867 
    868 
    869 
    870 
    871 
    872 
    873 
    874 
    875 
    876 
    877 
    878 
    879 
    880 
    881 
    882 
    883 
    884 
    885 
    886 
    887 
    888 
    889 
    890 
    891 
    892 
    893 
    894 
    895 
    896 
    897 
    898 
    899 
    900 
    901 
    902 
    903 
    904 
    905 
    906 
    907 
    908 
    909 
    910 
    911 
    912 
    913 
    914 
    915 
    916 
    917 
    918 
    919 
    920 
    921 
    922 
    923 
    924 
    925 
    926 
    927 
    928 
    929 
    930 
    931 
    932 
    933 
    934 
    935 
    936 
    937 
    938 
    939 
    940 
    941 
    942 
    943 
    944 
    945 
    946 
    947 
    948 
    949 
    950 
    951 
    952 
    953 
    954 
    955 
    956 
    957 
    958 
    959 
    960 
    961 
    962 
    963 
    964 
    965 
    966 
    967 
    968 
    969 
    970 
    971 
    972 
    973 
    974 
    975 
    976 
    977 
    978 
    979 
    980 
    981 
    982 
    983 
    984 
    985 
    986 
    987 
    988 
    989 
    990 
    991 
    992 
    993 
    994 
    995 
    996 
    997 
    998 
    999 
    1000 
    1001 
    1002 
    1003 
    1004 
    1005 
    1006 
    1007 
    1008 
    1009 
    1010 
    1011 
    1012 
    1013 
    1014 
    1015 
    1016 
    1017 
    1018 
    1019 
    1020 
    1021 
    1022 
    1023 
    Change of 0.00 against 100.00 
    ------------- 
    Laplace Evidence eval 
    Constrained params are: {'lag': Array(1.78005909e-305, dtype=float64), 'logtau': Array(2.69381531, dtype=float64), 'logamp': Array(-0.03500967, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    Un-Constrained params are: {'lag': Array(-708.39641853, dtype=float64), 'logtau': Array(-0.99776269, dtype=float64), 'logamp': Array(-0.02334084, dtype=float64), 'rel_amp': 1.0, 'mean': 0.0, 'rel_mean': 0.0} 
    With determinant: 14774.851974880268 
    And log height: -906.79... 
    log-evidence is ~-909.75 
    Seems to have converged at iteration 63 / 64 with tolerance 3.12e-01 
    Scanning Complete. Calculating laplace integrals... 
    Hessian Scan Fitting complete.
    -----------------------
    -----------------------
    


    Warning! LITMUS object built on pre-run fitting_procedure. May have unexpected behaviour. 

    



    
![png](output_11_9.png)
    



    
![png](output_11_10.png)
    


There's one immediately obvious difference between the two contours: the `JAVELIN`-like `meth_1` has summoned a bimodal distribution out of nowhere, while the hessian scan of `meth_2` has not.
